<?php if (! defined('BASEPATH')) exit('No direct script access allowed');
require_once dirname(__FILE__) . '/tcpdf/tcpdf.php';

class pdf_helper extends TCPDF{
	function __construct(){
		parent ::__construct();
	}
}
// defined('BASEPATH') OR exit('No direct script access allowed');
// function   ()
// {
//     require_once('tcpdf/config/tcpdf_config.php');
//     require_once('tcpdf/tcpdf.php');
// }

?>