
<?php
class stock_model extends CI_Model{

  public function AddStock(){ 
 $maxlength = 17;
  $chary = array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
                    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                    "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
  $return_str = "";
  for ( $x=0; $x<=$maxlength; $x++ ){
        $return_str .= $chary[rand(0, count($chary)-1)];
    }
 
   

  
  $year =$this->session->userdata['logged_in']['y_id'];
  
  $med=$this->input->post('med');
  $prix=$this->input->post('prix');
  $name=$this->input->post('name');
  $dateExp=$this->input->post('expiration');
  $dateEntrant=$this->input->post('dateentré');
  $QteEntrant=$this->input->post('Entrant');
  $Qtealert=$this->input->post('Qte');
  $vente=$this->input->post('vente');
  $total=$QteEntrant* $prix;
  $round=round($total,2);
  $statut='Disponible';

  $medE="SELECT s_id,s_qteE FROM stock WHERE m_id='$med'";
      $query=$this->db->query($medE);
      foreach ($query->result() as $key){
               # code...
      $sid=$key->s_id;
      $Pu=$key->s_qteE;
      $PT=$Pu+$QteEntrant;
      $PR=round($PT,2);

    $this->db->where("s_id", $sid);
    $this->db->set('s_qteE',$PR);
    $this->db->set('s_datex',$dateExp);
    $this->db->set('s_daten',$dateEntrant);
    $this->db->set('s_alert',$Qtealert);
    $this->db->set('s_prixU',$prix);
    $this->db->set('s_fournisseur',$name);
    $this->db->set('s_prixT',$round);
    $this->db->set('s_statut',$statut); 
    $this->db->set('s_vente',$vente);
    $this->db->set('s_aleatoire',$return_str);   
    $result= $this->db->update("Stock");

      $req=array('sv_qteE'=>$QteEntrant,
                 'sv_datex'=>$dateExp,
                 'sv_daten'=>$dateEntrant,
                 'sv_alert'=> $Qtealert,
                 'sv_prixU'=>$prix,
                 'sv_prixT'=>$round,
                 'sv_vente'=>$vente,
                 'sv_fournisseur'=>$name,
                 'sv_aleatoire'=>$return_str,
                 's_id'=> $sid,
                 'y_id'=>$year,
                 'm_id'=>$med);

      $exec=$this->db->insert('StockVirtual',$req);
      return $exec;
    
      }
  }

  public function AddStockM(){
  $id=$this->uri->segment(3);
  $maxlength = 17;
  $chary = array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
                    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                    "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
  $return_str = "";
  for ( $x=0; $x<=$maxlength; $x++ ){
        $return_str .= $chary[rand(0, count($chary)-1)];
    }


  $year =$this->session->userdata['logged_in']['y_id'];
  
  $med=$this->input->post('m_id');
  $prix=$this->input->post('prix');
  $name=$this->input->post('name');
  $dateExp=$this->input->post('expiration');
  $dateEntrant=$this->input->post('dateentré');
  $QteEntrant=$this->input->post('Entrant');
  $Qtealert=$this->input->post('Qte');
  $vente=$this->input->post('vente');
  $total=$QteEntrant* $prix;
  $round=round($total,2);
  $statut='Disponible';
  $statutwo='En manque';

  $medE="SELECT s_qteE,s_alert FROM stock WHERE s_id='$id'";
      $query=$this->db->query($medE);
      foreach ($query->result() as $key){
               # code...
      $alert=$key->s_alert;
      $Pu=$key->s_qteE;
      $PT=$Pu+$QteEntrant;
      $PR=round($PT,2);

      if( $PR < $alert){

    $this->db->where("s_id", $id);
    $this->db->set('s_qteE',$PR);
    $this->db->set('s_datex',$dateExp);
    $this->db->set('s_daten',$dateEntrant);
    $this->db->set('s_alert',$Qtealert);
    $this->db->set('s_prixU',$prix);
    $this->db->set('s_fournisseur',$name);
    $this->db->set('s_prixT',$round);
    $this->db->set('s_statut',$statutwo); 
    $this->db->set('s_vente',$vente);
    $this->db->set('s_aleatoire',$return_str);   
    $result= $this->db->update("Stock");

      $req=array('sv_qteE'=>$QteEntrant,
                 'sv_datex'=>$dateExp,
                 'sv_daten'=>$dateEntrant,
                 'sv_alert'=> $Qtealert,
                 'sv_prixU'=>$prix,
                 'sv_prixT'=>$round,
                 'sv_vente'=>$vente,
                 'sv_fournisseur'=>$name,
                 'sv_aleatoire'=>$return_str,
                 's_id'=> $id,
                 'y_id'=>$year,
                 'm_id'=>$med);

      $exec=$this->db->insert('StockVirtual',$req);
      return $exec;

      }else{

    $this->db->where("s_id", $id);
    $this->db->set('s_qteE',$PR);
    $this->db->set('s_datex',$dateExp);
    $this->db->set('s_daten',$dateEntrant);
    $this->db->set('s_alert',$Qtealert);
    $this->db->set('s_prixU',$prix);
    $this->db->set('s_fournisseur',$name);
    $this->db->set('s_prixT',$round);
    $this->db->set('s_statut',$statut); 
    $this->db->set('s_vente',$vente);
    $this->db->set('s_aleatoire',$return_str);   
    $result= $this->db->update("Stock");

      $req=array('sv_qteE'=>$QteEntrant,
                 'sv_datex'=>$dateExp,
                 'sv_daten'=>$dateEntrant,
                 'sv_alert'=> $Qtealert,
                 'sv_prixU'=>$prix,
                 'sv_prixT'=>$round,
                 'sv_vente'=>$vente,
                 'sv_fournisseur'=>$name,
                 'sv_aleatoire'=>$return_str,
                 's_id'=> $id,
                 'y_id'=>$year,
                 'm_id'=>$med);

      $exec=$this->db->insert('StockVirtual',$req);
      return $exec;
    

      }

      }


  }

  public function fetch_data($query){
  $statut="Disponible";
  $st="En manque";
  $this->db->select("*");
  $this->db->from(array('med','stock'));
  $this->db->where('med.m_id =stock.m_id');
  $this->db->order_by('med.m_name asc, m_name asc'); 
  {
   $this->db->like('med.m_name', $query);  
  }
  $this->db->order_by('stock.s_id', 'DESC');
  return $this->db->get();
  }

  Public function printSingle($id){
  $this->db->select("*");
  $this->db->from(array('med','stock'));
  $this->db->where('med.m_id =stock.m_id');
  $this->db->where('stock.s_id',$id);
  $this->db->order_by('med.m_name asc, m_name asc');
  return $this->db->get();
  }

  public function ShowStockPrint(){
  $this->db->select("*");
  $this->db->from(array('med','stock'));
  $this->db->where('med.m_id =stock.m_id');
  $this->db->order_by('med.m_name asc, m_name asc');
  return $this->db->get();
  }

  public function USD($query){
  $this->db->select('SUM(stock.s_prixU) AS VIR,SUM(stock.s_qteE) AS VIRR');
  $this->db->from(array('med','stock'));
  $this->db->where('med.m_id =stock.m_id');
  $this->db->order_by('med.m_name asc, m_name asc'); 
  if($query != ''){
    $this->db->like('med.m_name', $query); 
    }
    $this->db->order_by('stock.s_id', 'DESC');
    $Menu_Parent = $this->db->get();
    foreach ($Menu_Parent->result() as $key){
    # code...
    $sum=$key->VIR;
    $summ=$key->VIRR;
    $total= $sum*$summ;
    $abs=round($total,2);
    return $abs;
  }
}

  public function ShowStock($id){
  $this->db->select("*");
  $this->db->from(array('med','stock'));
  $this->db->where('med.m_id =stock.m_id');
  $this->db->where('stock.s_id',$id);
  return $this->db->get()->result();
  }

  public function EditStock(){
     $id=$this->uri->segment(3);
     $m_id=$this->input->post('m_id');
     $Qte=$this->input->post('Qte');
     $unitaire=$this->input->post('unitaire');
     $Dentrant=$this->input->post('Dentrant');
     $Dexp=$this->input->post('Dexp');
     $alerte=$this->input->post('alerte');
     $Fournisseur=$this->input->post('Fournisseur');
     $vente=$this->input->post('vente');
     $aleatoire=$this->input->post('aleatoire');
     $total=$Qte* $unitaire;
     $round=round($total,2);
    
     $statut='Disponible';
     $statutwo='En manque';

     
          if($Qte < $alerte){

     $query=array('s_qteE'=>$Qte,
                  's_datex'=>$Dexp,
                  's_daten'=>$Dentrant,
                  's_alert'=>$alerte,
                  's_prixU'=>$unitaire,
                  's_fournisseur'=>$Fournisseur,
                  's_vente'=> $vente,
                  's_statut'=>$statutwo,
                  's_prixT'=>$round,
                  'm_id'=>$m_id);

    $this->db->where("s_id", $id);  
    $result= $this->db->update("stock", $query);

    $idA="SELECT sv_id FROM stockvirtual WHERE s_id='$id' AND sv_aleatoire='$aleatoire'";
    $req=$this->db->query($idA);
    foreach ($req->result() as $row) {
    $val=$row->sv_id;

      $this->db->set('sv_qteE',$Qte);
      $this->db->set('sv_datex',$Dexp);
      $this->db->set('sv_daten',$Dentrant);
      $this->db->set('sv_alert',$alerte);
      $this->db->set('sv_prixU',$unitaire);
      $this->db->set('sv_prixT',$round);
      $this->db->set('sv_fournisseur',$Fournisseur);
      $this->db->set('sv_vente',$vente);
      $this->db->set('s_id',$id);
      $this->db->set('m_id',$m_id);
      $this->db->where('sv_id',$val);   
      $result= $this->db->update("stockvirtual");
      return $result;
     }

    }else{

     $query=array('s_qteE'=>$Qte,
                  's_datex'=>$Dexp,
                  's_daten'=>$Dentrant,
                  's_alert'=>$alerte,
                  's_statut'=>$statut,
                  's_prixU'=>$unitaire,
                  's_fournisseur'=>$Fournisseur,
                  's_vente'=> $vente,
                  's_prixT'=>$round,
                  'm_id'=>$m_id);

    $this->db->where("s_id", $id);  
    $result= $this->db->update("stock", $query);

    $idA="SELECT sv_id FROM stockvirtual WHERE s_id='$id' AND sv_aleatoire='$aleatoire'";
    $req=$this->db->query($idA);
    foreach ($req->result() as $row) {
    $val=$row->sv_id;

      $this->db->set('sv_qteE',$Qte);
      $this->db->set('sv_datex',$Dexp);
      $this->db->set('sv_daten',$Dentrant);
      $this->db->set('sv_alert',$alerte);
      $this->db->set('sv_prixU',$unitaire);
      $this->db->set('sv_prixT',$round);
      $this->db->set('sv_fournisseur',$Fournisseur);
      $this->db->set('sv_vente',$vente);
      $this->db->set('s_id',$id);
      $this->db->set('m_id',$m_id);
      $this->db->where('sv_id',$val);   
      $result= $this->db->update("stockvirtual");
      return $result;
     }
    }
  }

  public function delete($id){
      $statut='0';
      $this->db->where('s_id', $id);
      $this->db->set('s_qteE',$statut);
      $this->db->set('s_datex',$statut);
      $this->db->set('s_daten',$statut);
      $this->db->set('s_alert',$statut);
      $this->db->set('s_prixU',$statut);
      $this->db->set('s_prixT',$statut);
      $this->db->set('s_fournisseur',$statut);
      $this->db->set('s_vente',$statut);
      $this->db->set('s_statut',$statut);
      $result= $this->db->update("stock");
      return $result;
  
  }

  public function searchMed($id){

    $this->db->select('*');
    $this->db->from(array('med','stock'));
    $this->db->where('med.m_id=stock.m_id');
    $this->db->where('stock.s_id',$id);
    $Menu_Parent = $this->db->get();
    return $Menu_Parent;
    
  }

  }