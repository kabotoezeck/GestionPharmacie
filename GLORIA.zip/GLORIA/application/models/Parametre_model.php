
<?php
class Parametre_model extends CI_Model{

 public function Addyear(){
   $annee=$this->input->post('annee');

   $query=array('y_year'=>$annee);
   $this->db->insert('year',$query);
  }

   Public function showyear(){
    $this->db->select('*');
    $this->db->from('year');
    $Menu_Parent = $this->db->get();
    return $Menu_Parent->result();
  }

  Public function modifyYear(){
    $id=$this->input->post('y_id');
    $year=$this->input->post('y_year_edit');
    
    $query=array('y_year'=>$year);

    $this->db->where("y_id", $id);  
    $result= $this->db->update("year", $query); 
    return $result;
  }

  public function deleteYear($id){
    $this->db->where('y_id', $id);
    $result=$this->db->delete('year');
    return $result;

  }

  public function ShowCompt(){
    $this->db->select('*');
    $this->db->from('compt');
    $Menu_Parent = $this->db->get();
    return $Menu_Parent->result();
  }


  public function AddCompt(){
    $congo=$this->input->post('Congo');
    $dollars=$this->input->post('dollars');
    $taux=$dollars* $congo;
    $round=round($taux,2);
    $query=array('comp_franc'=>$congo,
                 'comp_dollars'=>$dollars,
                 'comp_taux'=>$round);
    $this->db->insert('compt',$query);
  }

  public function EditCompt($id){
   $franc=$this->input->post('franc_edit');
   $dollars=$this->input->post('dollars_edit');
   $taux=$dollars* $franc;
   $round=round($taux,2);

   $this->db->where("com_id", $id);
    $query=array('comp_franc'=>$franc,
                 'comp_dollars'=>$dollars,
                 'comp_taux'=>$round);

    $result= $this->db->update("compt", $query); 
    return $result;
  }

  public function deleteTaux($id){
    $this->db->where('com_id', $id);
    $result=$this->db->delete('compt');
    return $result;
  }

  }
