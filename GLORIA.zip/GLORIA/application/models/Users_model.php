
<?php
class Users_model extends CI_Model{

  public function AddUsers($photo){
   $name=$this->input->post('u_name');
   $username=$this->input->Post('u_username');
   $password=$this->input->post('u_password');
   $pswd= md5($_POST['u_password']);
   $role=$this->input->post('u_role');
   $genre=$this->input->post('u_genre');

      $query=array('u_nom'=>$name,
                   'u_username'=>$username,
                   'u_password'=>$pswd,
                   'u_role'=>$role,
                   'u_glo'=>$password,
                   'u_sexe'=>$genre,
                   'u_avatar'=>$photo);

      $this->db->insert('Users',$query);
  }


  public function showUser(){
    $this->db->select('*');
    $this->db->from('users');
    $Menu_Parent = $this->db->get();
    return $Menu_Parent->result();
  }

  public function Modify($photo){

  $id=$this->input->post('u_id_edit');
  $name=$this->input->post('u_name_edit');
  $username=$this->input->post('u_username_edit');
  $password=$this->input->post('u_password_edit');
  $pswd=md5($_POST['u_password_edit']);
  $role=$this->input->post('u_role_edit');
  $genre=$this->input->post('u_genre_edit');

  $query=array('u_nom'=>$name,
              'u_username'=>$username,
              'u_password'=>$pswd,
              'u_role'=>$role,
              'u_glo'=>$password,
              'u_sexe'=>$genre,
              'u_avatar'=>$photo);

  $this->db->where("u_id", $id);  
  $result= $this->db->update("Users", $query); 
  return $result;
  }

  public function statut(){
  $id = $this->input->post('u_id_actif');
  $status = $this->input->post('u_statut_actif');

 
  //check condition
  if($status == '1'){
    $user_status = '0';
  }
  else{
    $user_status = '1';
  }

  $data = array('u_statut' => $user_status );
  //Update status here
  $this->db->where("u_id", $id);  
  $result= $this->db->update("Users", $data); 
  return $result;
  }

  public function delete(){

    $id=$this->input->post('u_id_delete');
    $this->db->where('u_id', $id);
    $result=$this->db->delete('Users');
    return $result;
  }

  public function CountAllUsers(){
    $sql="SELECT COUNT(*) AS total FROM users";
    $return=$this->db->query($sql);
    foreach ($return->result() as $row){
    return $row->total ;
   } 
  }

  public function read_user_information($username,$password){

   
    $this->db->select('*');
    $this->db->from('users');
    $this->db->where('u_username',$username);
    $this->db->where('u_glo',$password);
    $this->db->where(array('u_role'=>'ADMIN'));
    $this->db->where(array('u_statut'=>'0'));
    $this->db->limit(1);
    $query = $this->db->get();
       if($query->num_rows() > 0){
       
          return $query->result();
      }else{
        return false;
      }
   }

   public function read_user_informationSimpleUser($username,$password){

   
    $this->db->select('*');
    $this->db->from('users');
    $this->db->where('u_username',$username);
    $this->db->where('u_glo',$password);
    $this->db->where(array('u_role'=>'AGENT'));
    $this->db->where(array('u_statut'=>'0'));
    $this->db->limit(1);
    $query = $this->db->get();
     if($query->num_rows() > 0){
        return $query->result();
      }else{
        return false;
      }
   }

   public function cheackYear($year){
     $this->db->select('*');
     $this->db->from('year');
     $this->db->where('y_id',$year);
     $this->db->limit(1);
     $query = $this->db->get();
     if($query->num_rows() > 0){
        return $query->result();
      }else{
        return false;
      }
   }

   function login($username, $password){  
           $this->db->where('u_username', $username);  
           $this->db->where('u_glo', $password);  
           $query = $this->db->get('users');  
           if($query->num_rows() > 0)  
           {  
                return true;  
           }  
           else  
           {  
                return false;       
           }    
    }
  
}