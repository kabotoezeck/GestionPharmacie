
<?php
class Depense_model extends CI_Model{

  public function rapportMonth(){

  $date=$this->input->post('dateentré');

  $this->db->select("*");
  $this->db->from(array('med','StockVirtual','year'));
  $this->db->where('med.m_id =StockVirtual.m_id');
  $this->db->where('year.y_id =StockVirtual.y_id');
  $this->db->where('StockVirtual.sv_daten',$date);
  return $this->db->get();
  }

  public function showtotal(){
  $date=$this->input->post('dateentré');
  $this->db->select('SUM(StockVirtual.sv_prixT) AS VIR');
  $this->db->from(array('med','StockVirtual','year'));
  $this->db->where('med.m_id =StockVirtual.m_id');
  $this->db->where('year.y_id =StockVirtual.y_id');
  $this->db->where('StockVirtual.sv_daten',$date);
  $Menu_Parent = $this->db->get();
  foreach ($Menu_Parent->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }
}

Public function USD(){
  $taux="SELECT comp_taux FROM compt";
  $req=$this->db->query($taux);
     foreach ($req->result() as $row) {
              $val=$row->comp_taux;
              $date=$this->input->post('dateentré');
  $this->db->select('SUM(StockVirtual.sv_prixT) AS VIR');
  $this->db->from(array('med','StockVirtual','year'));
  $this->db->where('med.m_id =StockVirtual.m_id');
  $this->db->where('year.y_id =StockVirtual.y_id');
  $this->db->where('StockVirtual.sv_daten',$date);
  $Menu_Parent = $this->db->get();
  foreach ($Menu_Parent->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $Taux=$total*$val;
    $roun=round($Taux,2);
    return  $roun;

   }   
 }
}

public function Getdate($date){

  $this->db->select("*");
  $this->db->from('charge');
  $this->db->where('ch_date',$date );
  return $this->db->get();

}

Public function AddCharge(){
   $montant=$this->input->post('Montant');
   $date=$this->input->post('depense');
   $desc=$this->input->post('desc');

   $req=array('ch_montant'=>$montant,
              'ch_date'=>$date,
              'ch_desc'=>$desc);

  $exec=$this->db->insert('charge',$req);
}

public function GetTotal($date){

  $this->db->select('SUM(ch_montant) AS VIR');
  $this->db->from('charge');
  $this->db->where('ch_date',$date );
  $Menu_Parent = $this->db->get();
  foreach ($Menu_Parent->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }
}

public function GetUSD($date){
 $taux="SELECT comp_taux FROM compt";
 $req=$this->db->query($taux);
     foreach ($req->result() as $row) {
              $val=$row->comp_taux;

  $this->db->select('SUM(ch_montant) AS VIR');
  $this->db->from('charge');
  $this->db->where('ch_date',$date );
  $Menu_Parent = $this->db->get();
  foreach ($Menu_Parent->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $Taux=$total*$val;
    $roun=round($Taux,2);
    return  $roun;

   }   
}
}

public function ShowCharge($id){
  $this->db->select("*");
  $this->db->from('charge');
  $this->db->where('ch_id',$id);
  return $this->db->get();

}

public function EditCharge($id){

   $montant=$this->input->post('Montant');
   $date=$this->input->post('date');
   $description=$this->input->post('desc');

   $this->db->where("ch_id", $id);
    $query=array('ch_montant'=>$montant,
                 'ch_date'=>$date,
                 'ch_desc'=>$description);

    $result= $this->db->update("charge", $query); 
    return $result;
}

public function delete($id){
  $this->db->where('ch_id', $id);
  $result=$this->db->delete('charge');
  return $result;
}

}

