
<?php
class Vente_model extends CI_Model{

  public function getProduits($searchTerm=""){
      // Fetch boats
     $st='0';
     $this->db->select('*');
     $this->db->from(array('stock','med'));
     $this->db->where('med.m_id=stock.m_id');
     $this->db->where('stock.s_statut !=',$st);
     $this->db->where("med.m_name like'%".$searchTerm."%' ");
     $fetched_records = $this->db->get();
     $query = $fetched_records->result_array();

     // Initialize Array with fetched data
     $data = array();
     foreach($query as $dta){
        $data[] = array("id"=>$dta['s_id'], "text"=>$dta['m_name']);
     }
     return $data;
   }

   public function searchQteE($produit){

     $query="SELECT stock.s_qteE FROM stock,med WHERE med.m_id=stock.m_id  AND stock.s_id='$produit'";
     $req=$this->db->query($query);
     foreach ($req->result() as $row) {
     $s_qteE=$row->s_qteE;
     return $s_qteE;

    }
   }

   public function searchCategorie($produit){

     $query="SELECT med.m_categorie FROM stock,med WHERE med.m_id=stock.m_id  AND stock.s_id='$produit'";
     $req=$this->db->query($query);
     foreach ($req->result() as $row) {
     $categorie=$row->m_categorie;
     return $categorie;

    }
   }

   public function searchName($produit){
     $query="SELECT med.m_name FROM stock,med WHERE med.m_id=stock.m_id  AND stock.s_id='$produit'";
     $req=$this->db->query($query);
     foreach ($req->result() as $row) {
     $name=$row->m_name;
     return $name;

    }
   }

  public function searchprix($produit){
    $query="SELECT stock.s_vente FROM stock,med WHERE med.m_id=stock.m_id  AND stock.s_id='$produit'";
     $req=$this->db->query($query);
     foreach ($req->result() as $row) {
     $prix=$row->s_vente;
     return $prix;

    }
  }

  public function searchstatut($produit){
    $query="SELECT stock.s_statut FROM stock,med WHERE med.m_id=stock.m_id  AND stock.s_id='$produit'";
     $req=$this->db->query($query);
     foreach ($req->result() as $row) {
     $statut=$row->s_statut;
     return $statut;

    }
  }

  public function searchAlert($produit){
    $query="SELECT stock.s_alert FROM stock,med WHERE med.m_id=stock.m_id  AND stock.s_id='$produit'";
     $req=$this->db->query($query);
     foreach ($req->result() as $row) {
     $alert=$row->s_alert;
     return $alert;

    }
  }

  public function paie($code){

  $query="SELECT * FROM vente,stock WHERE stock.s_id=vente.s_id AND vente.v_code='$code'";
  $req=$this->db->query($query);
  return $req->result();

  }

  public function totalpaie($code){

   $this->db->select('SUM(vente.v_total) AS VIR');
   $this->db->from('vente');
   $this->db->where('vente.v_code',$code);
   $menu= $this->db->get();
   foreach ($menu->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }
  }
  public function tot($code){

   $this->db->select('SUM(vente.v_dette) AS VIR');
   $this->db->from('vente');
   $this->db->where('vente.v_code',$code);
   $menu= $this->db->get();
   foreach ($menu->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }
  }

  public function nbreprduit($code){
  $sql="SELECT COUNT(*) AS total FROM vente  WHERE v_code='$code'";
  $return=$this->db->query($sql);
  foreach ($return->result() as $row){
  return $row->total ;
 }
  }

   public function getData(){
     $this->db->select('*');
     $this->db->from(array('stock','med','pannier'));
     $this->db->where('med.m_id=stock.m_id');
     $this->db->where('stock.s_id=pannier.s_id');
     $fetched_records = $this->db->get();
     return $fetched_records->result();
   }

   public function Add(){
     $produit=$this->input->post('produit');
     $req=array('s_id'=>$produit);
     $exec=$this->db->insert('pannier',$req);
   }

   Public function deletePannier($id){
    $this->db->where('pn_id', $id);
    $result=$this->db->delete('pannier');
    return $result;
   }

  public function reportDayALL($dateone,$type){
    $date=date('d-m-Y ', strtotime($dateone));

    if($type=='TOUS'){

    $this->db->select('*');
    $this->db->from(array('stock','med','vente'));
    $this->db->where('med.m_id=stock.m_id');
    $this->db->where('stock.s_id=vente.s_id');
    $this->db->where('vente.v_date',$date);
    $req=$this->db->get();
    return $req;

    }elseif($type=='CASH'){

    $this->db->select('*');
    $this->db->from(array('stock','med','vente'));
    $this->db->where('med.m_id=stock.m_id');
    $this->db->where('stock.s_id=vente.s_id');
    $this->db->where('vente.v_type',$type);
    $this->db->where('vente.v_date',$date);
    return $this->db->get();

    }else{
    $this->db->select('*');
    $this->db->from(array('stock','med','vente'));
    $this->db->where('med.m_id=stock.m_id');
    $this->db->where('stock.s_id=vente.s_id');
    $this->db->where('vente.v_type',$type);
    $this->db->where('vente.v_date',$date);
    return $this->db->get();
    }
  }

  public function GetTotalDay($dateone,$type){
   $date=date('d-m-Y ', strtotime($dateone));
   if($type=='TOUS'){

   $this->db->select('SUM(vente.v_total) AS VIR');
   $this->db->from(array('stock','med','vente'));
   $this->db->where('med.m_id=stock.m_id');
   $this->db->where('stock.s_id=vente.s_id');
   $this->db->where('vente.v_date',$date);
   $menu= $this->db->get();
   foreach ($menu->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }
  }elseif($type=='CASH'){

   $this->db->select('SUM(vente.v_total) AS VIR');
   $this->db->from(array('stock','med','vente'));
   $this->db->where('med.m_id=stock.m_id');
   $this->db->where('stock.s_id=vente.s_id');
   $this->db->where('vente.v_date',$date);
   $this->db->where('vente.v_type',$type);
   $menu= $this->db->get();
   foreach ($menu->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }

  }else{
     $this->db->select('SUM(vente.v_total) AS VIR');
     $this->db->from(array('stock','med','vente'));
     $this->db->where('med.m_id=stock.m_id');
     $this->db->where('stock.s_id=vente.s_id');
     $this->db->where('vente.v_date',$date);
     $this->db->where('vente.v_type',$type);
     $menu= $this->db->get();
     foreach ($menu->result() as $key) {
    # code...
     $k=$key->VIR;
     $total=$k;
     $round=round($total,2);
     return $round;
   }
  }

 }

 public function GetUSDDay($dateone,$type){

  $date=date('d-m-Y ', strtotime($dateone));
  $taux="SELECT comp_taux FROM compt";
  $req=$this->db->query($taux);
     foreach ($req->result() as $row) {
              $val=$row->comp_taux;
              if($type=='TOUS'){  

              $this->db->select('SUM(vente.v_total) AS VIR');
              $this->db->from(array('stock','med','vente'));
              $this->db->where('med.m_id=stock.m_id');
              $this->db->where('stock.s_id=vente.s_id');
              $this->db->where('vente.v_date',$date);
              $Menu_Parent = $this->db->get();
              foreach ($Menu_Parent->result() as $key) {
              # code...
              $k=$key->VIR;
              $total=$k;
              $Taux=$total*$val;
              $roun=round($Taux,2);
              return  $roun;

             }
             }elseif($type=='CASH'){

              $this->db->select('SUM(vente.v_total) AS VIR');
              $this->db->from(array('stock','med','vente'));
              $this->db->where('med.m_id=stock.m_id');
              $this->db->where('stock.s_id=vente.s_id');
              $this->db->where('vente.v_date',$date);
              $this->db->where('vente.v_type',$type);
              $Menu_Parent = $this->db->get();
              foreach ($Menu_Parent->result() as $key) {
              # code...
              $k=$key->VIR;
              $total=$k;
              $Taux=$total*$val;
              $roun=round($Taux,2);
              return  $roun;

             }
             }else{

              $this->db->select('SUM(vente.v_total) AS VIR');
              $this->db->from(array('stock','med','vente'));
              $this->db->where('med.m_id=stock.m_id');
              $this->db->where('stock.s_id=vente.s_id');
              $this->db->where('vente.v_date',$date);
              $this->db->where('vente.v_type',$type);
              $Menu_Parent = $this->db->get();
              foreach ($Menu_Parent->result() as $key) {
              # code...
              $k=$key->VIR;
              $total=$k;
              $Taux=$total*$val;
              $roun=round($Taux,2);
              return  $roun;
               }
             } 
          }
       }

  public function rapportMonth($dateone,$datetwo,$type){

    $dateO=date('d-m-Y ', strtotime($dateone));
    $dateT=date('d-m-Y ', strtotime($datetwo));
   if($type=='TOUS'){ 

    $this->db->select('*');
    $this->db->from(array('stock','med','vente'));
    $this->db->where('med.m_id=stock.m_id');
    $this->db->where('stock.s_id=vente.s_id');
    $this->db->where('vente.v_date >=',$dateO);
    $this->db->where('vente.v_date <=',$dateT);
    return $this->db->get();

    }elseif($type=='CASH'){

    $this->db->select('*');
    $this->db->from(array('stock','med','vente'));
    $this->db->where('med.m_id=stock.m_id');
    $this->db->where('stock.s_id=vente.s_id');
    $this->db->where('vente.v_date >=',$dateO);
    $this->db->where('vente.v_date <=',$dateT);
    $this->db->where('vente.v_type',$type);
    return $this->db->get();

    }else{
    $this->db->select('*');
    $this->db->from(array('stock','med','vente'));
    $this->db->where('med.m_id=stock.m_id');
    $this->db->where('stock.s_id=vente.s_id');
    $this->db->where('vente.v_date >=',$dateO);
    $this->db->where('vente.v_date <=',$dateT);
    $this->db->where('vente.v_type',$type);
    return $this->db->get();
    }
  }

public function GetTotal($dateone,$datetwo,$type){
    $dateO=date('d-m-Y ', strtotime($dateone));
    $dateT=date('d-m-Y ', strtotime($datetwo));
  if($type=='TOUS'){ 

   $this->db->select('SUM(vente.v_total) AS VIR');
   $this->db->from(array('stock','med','vente'));
   $this->db->where('med.m_id=stock.m_id');
   $this->db->where('stock.s_id=vente.s_id');
   $this->db->where('vente.v_date >=',$dateO);
   $this->db->where('vente.v_date <=',$dateT);
   $menu= $this->db->get();
   foreach ($menu->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }
 }elseif($type=='CASH'){

   $this->db->select('SUM(vente.v_total) AS VIR');
   $this->db->from(array('stock','med','vente'));
   $this->db->where('med.m_id=stock.m_id');
   $this->db->where('stock.s_id=vente.s_id');
   $this->db->where('vente.v_date >=',$dateO);
   $this->db->where('vente.v_date <=',$dateT);
   $this->db->where('vente.v_type',$type);
   $menu= $this->db->get();
   foreach ($menu->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }
 }else{

   $this->db->select('SUM(vente.v_total) AS VIR');
   $this->db->from(array('stock','med','vente'));
   $this->db->where('med.m_id=stock.m_id');
   $this->db->where('stock.s_id=vente.s_id');
   $this->db->where('vente.v_date >=',$dateO);
   $this->db->where('vente.v_date <=',$dateT);
   $this->db->where('vente.v_type',$type);
   $menu= $this->db->get();
   foreach ($menu->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }
 }
}

public function GetUSD($dateone,$datetwo,$type){
$dateO=date('d-m-Y ', strtotime($dateone));
$dateT=date('d-m-Y ', strtotime($datetwo));
$taux="SELECT comp_taux FROM compt";
$req=$this->db->query($taux);
     foreach ($req->result() as $row) {
              $val=$row->comp_taux;

  if($type=='TOUS'){  

  $this->db->select('SUM(vente.v_total) AS VIR');
  $this->db->from(array('stock','med','vente'));
  $this->db->where('med.m_id=stock.m_id');
  $this->db->where('stock.s_id=vente.s_id');
  $this->db->where('vente.v_date >=',$dateO);
  $this->db->where('vente.v_date <=',$dateT);
  $Menu_Parent = $this->db->get();
  foreach ($Menu_Parent->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $Taux=$total*$val;
    $roun=round($Taux,2);
    return  $roun;

     }
  }elseif ($type=='CASH') {
    # code...
  $this->db->select('SUM(vente.v_total) AS VIR');
  $this->db->from(array('stock','med','vente'));
  $this->db->where('med.m_id=stock.m_id');
  $this->db->where('stock.s_id=vente.s_id');
  $this->db->where('vente.v_date >=',$dateO);
  $this->db->where('vente.v_date <=',$dateT);
  $this->db->where('vente.v_type',$type);
  $Menu_Parent = $this->db->get();
  foreach ($Menu_Parent->result() as $key){
    # code...
    $k=$key->VIR;
    $total=$k;
    $Taux=$total*$val;
    $roun=round($Taux,2);
    return  $roun;

     }
  }else{

  $this->db->select('SUM(vente.v_total) AS VIR');
  $this->db->from(array('stock','med','vente'));
  $this->db->where('med.m_id=stock.m_id');
  $this->db->where('stock.s_id=vente.s_id');
  $this->db->where('vente.v_date >=',$dateO);
  $this->db->where('vente.v_date <=',$dateT);
  $this->db->where('vente.v_type',$type);
  $Menu_Parent = $this->db->get();
  foreach ($Menu_Parent->result() as $key){
    # code...
    $k=$key->VIR;
    $total=$k;
    $Taux=$total*$val;
    $roun=round($Taux,2);
    return  $roun;

     }
  }   
 }
}

public function searchBill($code){

  $this->db->select('*');
  $this->db->from(array('stock','med','vente'));
  $this->db->where('med.m_id=stock.m_id');
  $this->db->where('stock.s_id=vente.s_id');
  $this->db->where('vente.v_code',$code);
  $sql=$this->db->get();
  return $sql;
}

public function searchBilltotal($code){

$this->db->select('SUM(vente.v_total) AS VIR');
$this->db->from(array('stock','med','vente'));
$this->db->where('med.m_id=stock.m_id');
$this->db->where('stock.s_id=vente.s_id');
$this->db->where('vente.v_code',$code);

$menu= $this->db->get();
foreach ($menu->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $round=round($total,2);
    return $round;
   }
}

public function searchBillUSD($code){
$taux="SELECT comp_taux FROM compt";
$req=$this->db->query($taux);
     foreach ($req->result() as $row) {
              $val=$row->comp_taux;
             
  $this->db->select('SUM(vente.v_total) AS VIR');
  $this->db->from(array('stock','med','vente'));
  $this->db->where('med.m_id=stock.m_id');
  $this->db->where('stock.s_id=vente.s_id');
  $this->db->where('vente.v_code',$code);
  $Menu_Parent = $this->db->get();
  foreach ($Menu_Parent->result() as $key) {
    # code...
    $k=$key->VIR;
    $total=$k;
    $Taux=$total*$val;
    $roun=round($Taux,2);
    return  $roun;

   }   
 }

}

public function delete_Bill($code){
 
  $sql="SELECT * FROM vente,stock WHERE stock.s_id=vente.s_id AND vente.v_code='$code'";
  $query=$this->db->query($sql);
  
  

}


}