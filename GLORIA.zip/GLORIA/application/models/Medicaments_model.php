
<?php
class Medicaments_model extends CI_Model{

  public function AddMed(){
  $med=$this->input->post("med");
  $categorie=$this->input->post("Categorie");
  $zero="0";
  $date="0000-00-00";

      $query=array('m_name'=>$med,
                   'm_categorie'=>$categorie);

      $this->db->insert('med',$query);
      $med="SELECT m_id FROM med WHERE m_name='$med' AND m_categorie='$categorie'";
      $query=$this->db->query($med);
      foreach ($query->result() as $key) {
               # code...
              $mid=$key->m_id;
        $req=array('s_qteE'=>$zero,
                   's_alert'=>$zero,
                   's_prixU'=>$zero,
                   's_datex'=> $date,
                   's_daten'=>$date,
                   's_prixT'=>$zero,
                   's_vente'=>$zero,
                   's_statut'=>$zero,
                   'm_id'=>$mid);

        $exec=$this->db->insert('stock',$req);
      }
}

public function showMed(){
  $this->db->select('*');
  $this->db->from('med');
  $Menu_Parent = $this->db->get();
  return $Menu_Parent->result();
}

public function EditMed(){
$id=$this->input->post("m_id");
$name=$this->input->post("med_edit");
$categorie=$this->input->post("Categorie_edit");

 $query=array('m_name'=>$name,
              'm_categorie'=>$categorie);

 $this->db->where("m_id", $id);  
 $result= $this->db->update("med", $query); 
 return $result; 
}

public function deleteMed($id){
  $this->db->where('m_id', $id);
  $result=$this->db->delete('med');
  return $result;
 
}

public function CountAllMed(){
  $sql="SELECT COUNT(*) AS total FROM stock  WHERE s_statut='Disponible'";
  $return=$this->db->query($sql);
  foreach ($return->result() as $row){
  return $row->total ;
 }
}

public function countManque(){
  $sql="SELECT COUNT(*) AS total FROM stock  WHERE s_statut='En manque'";
  $return=$this->db->query($sql);
  foreach ($return->result() as $row){
  return $row->total ;
 }
}

public function getMed($searchTerm=""){
     // Fetch boats
     $this->db->select('*');
     $this->db->where("m_name like '%".$searchTerm."%' ");
     $fetched_records = $this->db->get('med');
     $query = $fetched_records->result_array();

     // Initialize Array with fetched data
     $data = array();
     foreach($query as $dta){
        $data[] = array("id"=>$dta['m_id'], "text"=>$dta['m_name']);
     }
     return $data;
  }

  public function Categorie($med){

  $idA="SELECT m_categorie FROM med WHERE m_id='$med'";
    $req=$this->db->query($idA);
    foreach ($req->result() as $row){
    $nm=$row->m_categorie;
    return $nm;

  }
}


//FIN DE LA FONCTION 
}
