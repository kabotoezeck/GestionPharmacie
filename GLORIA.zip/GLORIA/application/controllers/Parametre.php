<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parametre extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    public function __construct(){
		parent::__construct();
		$this->load->helper(array('form','url','file'));
		$this->load->library('form_validation');
		$this->load->model('Parametre_model');
        //$this->load->library('Pdf');
	}

	public function index(){

		if (isset($this->session->userdata['logged_in'])) {
			 $u_nom = ($this->session->userdata['logged_in']['u_nom']);
             $u_username = ($this->session->userdata['logged_in']['u_username']);
             $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
             $u_role = ($this->session->userdata['logged_in']['u_role']);
             $y_year = ($this->session->userdata['logged_in']['y_year']);

			} else {
			//header("location: logout");
			}

		$logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
		$data=array('title'=>'GLORIA | Paramètres',
					'photo'=>$logo,
					'info'=>$this->session->message,
					'u_nom' => $this->session->userdata['logged_in']['u_nom'],
					'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
					'y_year' => $this->session->userdata['logged_in']['y_year'],
					'u_role' => $this->session->userdata['logged_in']['u_role'],
					'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
					'footer1'=>' Katemoezeck@gmail.com./ KATEMO KABOTO EZECHIEL.');

		$this->load->view('ADMIN/PARAMETRES/head',$data);
		$this->load->view('ADMIN/SIDEBAR/header',$data);
		$this->load->view('ADMIN/SIDEBAR/sidebar',$data);
		$this->load->view('ADMIN/PARAMETRES/body',$data);
		$this->load->view('ADMIN/PARAMETRES/footer',$data);
	}

// FONCTION POUR AJOUTER UNE ANNEE
	public function Addyear(){

		$anne=$this->input->post('annee');
		// REGLE DES VALIDATIONS
		$message=array(array('field'=>'annee',
              'label'=>"année",
              'rules'=>'required|is_unique[year.y_year.'.$anne.']',
              'errors'=>array('required' => '<font color="red"><i class=" fa fa-exclamation-triangle"></i> <strong>Attention!</strong>  <small>le champ  %s doit être remplie.</small></font>',

           	 "is_unique"=>"<font color='red'><i class='fa fa-exclamation-triangle'></i> <strong>Attention! L' %s existe déjà.</strong></font>")));

		$this->form_validation->set_rules($message);
		if ($this->form_validation->run()){
			$data= $this->Parametre_model->Addyear();
			$array=array('success'=> '<div class="alert alert-success col-lg-3 col-md-3 col-sm-3 col-xs-12"style="font-size:15px;">
              				<button  type="button" class="close" data-dismiss="alert" arial-label="close">
             				<span arial-hidden="true">&times;</span>
                            </button><i class="fa fa-thumbs-up"></i> <strong> Enregistrement fait</strong>
                            </div>');
		}else{
			$array=array('error'=>TRUE,
                         'annee_error'=>form_error('annee'));
                      
		}
			echo json_encode($array);
	}

	// FONCTION POUR AFFICHER L'ANNNEE

	Public function showyear(){

	$data=$this->Parametre_model->showyear();
	echo json_encode($data);
	}

	// FONCTION POUR MODIFIER L'ANNEE

	Public function modify(){
		$id=$this->input->post('y_id');
	 	$year=$this->input->post('y_year_edit');
	 	if(empty($year)){
           $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
		                                      <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		                                      <span arial-hidden="true">&times;</span>
		                                      </button> <strong>Attention !</strong>
		                                   Remplir tout les champs !</div>');
        	                                  redirect('Parametre/index');
		}
		if($this->db->where('y_year', $year)->where('y_id !=', $id)->limit(1)->get('year')->num_rows()){ 
		   $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
		                                      <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		                                      <span arial-hidden="true">&times;</span>
		                                      </button> <strong>Attention ! Année existe déjà</strong>
		                                     </div>');
        	                                  redirect('Parametre/index');
		}
		$data= $this->Parametre_model->modifyYear();
		if($data==TRUE){
			$this->session->set_flashdata('message','<div class="alert alert-success col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
		                                      <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		                                      <span arial-hidden="true">&times;</span>
		                                      </button> <strong>succès !</strong>
		                                    Enregistrement Reussi</div>');
        	                                  redirect('Parametre/index');
		}	   
	}

	Public function delete(){

	   $username=$this->input->post('username');
	   $password=$this->input->post('password');
	   $id=$this->input->post('y_id_delete');
	   $role='ADMIN';

	   $result = $this->db->get_where('users', array('u_username'=>$username,
	   	                                             'u_role'=>$role,
                                                     'u_glo'=>$password));
      $inDatabase = (bool)$result->num_rows();
      if($inDatabase){

      	$data=$this->Parametre_model->deleteYear($id);
    	$array=array('success'=>'<strong>Attention!</strong>');
      }else{
      	$array=array('error'=>'<strong>Nom utilisateur et Mot de passe Incorrect </strong>');
      }
        echo json_encode($array); 
	}

	public function AddCompt(){
		$franc=$this->input->post('Congo');
		$dollars=$this->input->post('dollars');
		// REGLE DES VALIDATIONS

		$message=array(array('field'=>'Congo',
                             'label'=>'Reference En Franc',
                             'rules'=>'required',
                             'errors'=>array('required' => '<font color="red"><i class=" fa fa-exclamation-triangle"></i> <strong>Attention!</strong>  <small>le champ  %s doit être remplie.</small></font>')),

           
                     array('field'=>'dollars',
                           'label'=>'Reference En Dollars',
                           'rules'=>'required',
                           'errors'=>array('required' => '<font color="red"><i class=" fa fa-exclamation-triangle"></i> <strong>Attention!</strong>  <small>le champ  %s doit être remplie.</small></font>')));

		$this->form_validation->set_rules($message);
		if ($this->form_validation->run()){
			$data= $this->Parametre_model->AddCompt();
			$array=array('success'=> '<div class="alert alert-success col-lg-3 col-md-3 col-sm-3 col-xs-12"style="font-size:15px;">
              				<button  type="button" class="close" data-dismiss="alert" arial-label="close">
             				<span arial-hidden="true">&times;</span>
                            </button><i class="fa fa-thumbs-up"></i> <strong> Enregistrement fait</strong>
                            </div>');
		}else{
			$array=array('error'=>TRUE,
                         'dollars_error'=>form_error('dollars'),
                         'Congo_error'=>form_error('Congo'));
                      
		}
			echo json_encode($array);

	}

	public function ShowCompt(){

	$data=$this->Parametre_model->ShowCompt();
	echo json_encode($data);	
	}

	
    public  function EditCompt(){
	 $franc=$this->input->post('franc_edit');
	 $dollars=$this->input->post('dollars_edit');
	 $id=$this->input->post('com_id');
	 if(empty($franc)||empty($dollars)){
	 	$array=array('error'=>'Il faut remplir tout les champs');
	 }else{
	 	$data=$this->Parametre_model->EditCompt($id);
	 	$array=array('success'=>'Modification Reussi');
	 }
	 echo json_encode($array);
	}

	public function ResetTaux(){
	   $username=$this->input->post('username');
	   $password=$this->input->post('password');
	   $id=$this->input->post('comp_delete');
	   $role='ADMIN';

	   $result = $this->db->get_where('users', array('u_username'=>$username,
	   	                                             'u_role'=>$role,
                                                     'u_glo'=>$password));
      $inDatabase = (bool)$result->num_rows();
      if($inDatabase){

      	$data=$this->Parametre_model->deleteTaux($id);
    	$array=array('success'=>'<strong>Reussi!</strong>');
      }else{
      	$array=array('error'=>'<strong>Nom utilisateur et Mot de passe Incorrect </strong>');
      }
        echo json_encode($array); 
	}



	
}