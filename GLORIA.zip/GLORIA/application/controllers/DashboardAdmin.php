<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardAdmin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->helper(array('form','url','file'));
		$this->load->library('form_validation');
		$this->load->model('Users_model');
		//$this->load->model('Boat_model');
        //$this->load->model('test_model');
	}

	public function index()
	{
			if (isset($this->session->userdata['logged_in'])) {
			$u_nom = ($this->session->userdata['logged_in']['u_nom']);
			$u_username = ($this->session->userdata['logged_in']['u_username']);
			$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
			$u_role = ($this->session->userdata['logged_in']['u_role']);
			$y_year = ($this->session->userdata['logged_in']['y_year']);
			} else {
			//header("location: logout");
			}
		//$year=$this->input->post('y_id');
        //$result = $this->test_model->read_information($year);

        //$session_data = array('y_id' => $result[0]->y_id,
					          //'y_year' => $result[0]->y_year
							//);

		$logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
		$data=array('title'=>'GLORIA | Dashboard',
					'photo'=>$logo,
					'u_nom' => $this->session->userdata['logged_in']['u_nom'],
					'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
					'u_role' => $this->session->userdata['logged_in']['u_role'],
					'y_year' => $this->session->userdata['logged_in']['y_year'],
                    'query'=>$this->Users_model->CountAllUsers(),
                    //'quer'=>$this->Boat_model->CountAllBoat(),
					'footer'=>'Copyright © 2021 Pharmacie GLORIA v1.0.Tous les droits sont réservés. Katemoezeck@gmail.com',
					'footer1'=>'KATEMO KABOTO EZECHIEL.');


		
		//$this->session->set_userdata('year',$session_data);
		$this->load->view('ADMIN/SIDEBAR/head',$data);
		$this->load->view('ADMIN/SIDEBAR/header',$data);
		$this->load->view('ADMIN/SIDEBAR/sidebar',$data);
		$this->load->view('ADMIN/SIDEBAR/body',$data);
		$this->load->view('ADMIN/SIDEBAR/footer',$data);
	}
}
