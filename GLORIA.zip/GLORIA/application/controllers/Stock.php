<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stock extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->helper(array('form','url','file'));
		$this->load->library('form_validation');
		$this->load->model('stock_model');
    $this->load->model('Medicaments_model');
		$this->load->library('session');

        //$this->load->library('Pdf');
	}
	
	public function index(){


    if (isset($this->session->userdata['logged_in'])) {
        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);
        $y_id = ($this->session->userdata['logged_in']['y_id']);

      } else {
      //header("location: logout");
      }

	    $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
		  $data=array('title'=>'GLORIA | Stock',
					'photo'=>$logo,
					'info'=>$this->session->message,
                    'u_nom' => $this->session->userdata['logged_in']['u_nom'],
                    'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
                    'y_year' => $this->session->userdata['logged_in']['y_year'],
                    'u_role' => $this->session->userdata['logged_in']['u_role'],
                    'y_id' => $this->session->userdata['logged_in']['y_id'],

					'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
					'footer1'=>'KATEMO KABOTO EZECHIEL.');
   
		$this->load->view('ADMIN/STOCK/header',$data);
		$this->load->view('ADMIN/SIDEBAR/header',$data);
	    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
		$this->load->view('ADMIN/STOCK/body',$data);
		$this->load->view('ADMIN/STOCK/footer',$data);
	}

	public function Add(){

 
	$med=$this->input->post('med');
	$dateExp=$this->input->post('expiration');
	$dateEntrant=$this->input->post('dateentré');
	$QteEntrant=$this->input->post('Entrant');
	$Qtealert=$this->input->post('Qte');
  $prix=$this->input->post('prix');
  $name=$this->input->post('name');
  $vente=$this->input->post('vente');
	$zero='0';


	if(empty($dateExp)|| empty($dateEntrant)|| empty($QteEntrant)|| empty($Qtealert) || empty($prix) || empty($name) || empty($vente)){
	        $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
		        <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		        <span arial-hidden="true">&times;</span>
		        </button> <strong>Attention!</strong>
		        Remplir tout les champs !</div>');
        	    redirect('Stock/index');  

	}elseif ($QteEntrant < $zero || $Qtealert < $zero || $prix < $zero || $vente < $zero) {
			  $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
		        <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		        <span arial-hidden="true">&times;</span>
		        </button> <strong>Attention!</strong>
		        La quantité doit etre superieur à zero !</div>');
        	    redirect('Stock/index');
		   
		   
	}else{
		$data=$this->stock_model->AddStock();
		 $this->session->set_flashdata('message','<div class="alert alert-success col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
		        <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		        <span arial-hidden="true">&times;</span>
		        </button> <strong>Bravo!</strong>
		       Enregistrement Reussi!</div>');
        	    redirect('Stock/index');
		
	}
}

public function AddStockM(){

  $med=$this->input->post('med');
  $dateExp=$this->input->post('expiration');
  $dateEntrant=$this->input->post('dateentré');
  $QteEntrant=$this->input->post('Entrant');
  $Qtealert=$this->input->post('Qte');
  $prix=$this->input->post('prix');
  $name=$this->input->post('name');
  $vente=$this->input->post('vente');
  $zero='0';


  if(empty($dateExp)|| empty($dateEntrant)|| empty($QteEntrant)|| empty($Qtealert) || empty($prix) || empty($name) || empty($vente)){
          $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
            Remplir tout les champs !</div>');
              redirect('Stock/index');  

  }elseif ($QteEntrant < $zero || $Qtealert < $zero || $prix < $zero || $vente < $zero) {
        $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
            La quantité doit etre superieur à zero !</div>');
              redirect('Stock/index');
       
       
  }else{
    $data=$this->stock_model->AddStockM();
     $this->session->set_flashdata('message','<div class="alert alert-success col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
           Enregistrement Reussi!</div>');
              redirect('Stock/index');
    
  }
}

public function fetch(){

  	$base_url= base_url('Stock/EditerMedicament/');
    $Suppression= base_url('Stock/Suppression/');
    $print= base_url('Stock/printSingle/');
    $add= base_url('index.php/Stock/AjoutMed/');
   
	  $output = '';
	  $query = '';

	if($this->input->post('query'))
    {
    $query = $this->input->post('query');
    }
    $data = $this->stock_model->fetch_data($query);
    $usd=$this->stock_model->USD($query);
    $output .= '
    <div class="dt-responsive">
   
     <div style="height:300px;overflow:auto;">
     <P><strong>VALEUR DU STOCK EN USD </strong>: &nbsp;'.$usd.'</p>
      <table  class="table table-striped table-bordered nowrap" id="scr-vrt-dt">
         <thead class="thead-dark">
            <tr>
            
            
            <th style="text-align: center;"><small>#</small></th>
            <th style="text-align: center;"><small>Produits</small></th>
            <th style="text-align: center;"><small>Categories</small></th>
            <th style="text-align: center;"><small>Qte en Stock</small></th>
            <th style="text-align: center;"><small>Date Entrée</small></th>
            <th style="text-align: center;"><small>Date Expiration</small></th>
            <th  style="text-align: center;"><small>Qte Alerte</small></th>
            <th  style="text-align: center;"><small>Fournisseur</small></th>
            <th  style="text-align: center;"><small>Statut</small></th>
            <th  style="text-align: center;"><small>Actions</small></th>
           
            </tr>

        </thead> ';
        // var_dump($output);
        // exit();
    if($data->num_rows() > 0){
	
    $no=1;
    foreach($data->result() as $row){ 
            $st="0";
            $date=$row->s_daten; 
            $dateA=date("d-m-Y", strtotime($date));
            $status=$row->s_statut;
            $dateD=$row->s_datex; 
            $dateD=date("d-m-Y", strtotime($dateD));
            $statut=$row->s_statut;
            $condition='Disponible';

        if($status==$st){
    
        }else{

            if($statut==$condition){

            	$table='<td  style="text-align: center; background-color:green">'.$statut.'</td>';
            }else{
            	$table='<td  style="text-align: center; background-color:red">'.$statut.'</td>';
            }

       $output .=' 
       <tr>
       <td>'. $no++.'</td>
       <td  style="text-align: center;">'. $row->m_name .'</td>
       <td  style="text-align: center;">'. $row->m_categorie .'</td>
       <td  style="text-align: center;">'. $row->s_qteE.'</td>
       <td  style="text-align: center;">'.'le&nbsp; '. $dateA.'</td>
       <td  style="text-align: center;">'.'le&nbsp;'. $dateD.'</td>
       <td  style="text-align: center;">'. $row->s_alert.'</td>
       <td  style="text-align: center;">'. $row->s_fournisseur.'</td>'.$table.'</td>
       <td  style="text-align: center;">'.'<a href="' .$add.$row->s_id.'" ><i class="ik ik-plus-circle f-16 text-dark"></i></a>'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'<a href="' .$base_url.$row->s_id.'" ><i class="ik ik-edit f-16 text-info"></i></a>'.'&nbsp;'.'<a href="'.$print.$row->s_id.'" ><i class="ik ik-printer f-16 text-success"></i></a>'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'<a href="'.$Suppression.$row->s_id.'" ><i class="ik ik-trash-2 f-16 text-red"></i></a></td>
      </tr>
      ';
   }
  }
}
  else
  {
   $output .= '<tr>
       <td colspan="12">Désolé il y a pas des données suite à votre recherche! </td>
      </tr>';
  }
  $output .= '</table> </a>';
  echo $output;
	}

  Public function modify(){

     $username=$this->input->post('username');
     $password=$this->input->post('password');
     $role='ADMIN';

     $result = $this->db->get_where('users', array('u_username'=>$username,
                                                   'u_role'=>$role,
                                                   'u_glo'=>$password));
      $inDatabase = (bool)$result->num_rows();
      if($inDatabase){
        $id=$this->uri->segment(3);
    if (isset($this->session->userdata['logged_in'])) {
        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

      $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
      $data=array('title'=>'GLORIA | Modification',
                  'photo'=>$logo,
                  'info'=>$this->session->message,
                  'query'=>$this->stock_model->ShowStock($id),
                  'med'=>$this->Medicaments_model->showMed(),
                  'u_nom' => $this->session->userdata['logged_in']['u_nom'],
                  'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
                  'y_year' => $this->session->userdata['logged_in']['y_year'],
                  'u_role' => $this->session->userdata['logged_in']['u_role'],
                  'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
                  'footer1'=>'KATEMO KABOTO EZECHIEL.');
   
    $this->load->view('ADMIN/STOCK/header',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/STOCK/modify',$data);
    $this->load->view('ADMIN/STOCK/footer',$data);
       
      }else if(empty($username)||empty( $password)){

         $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
              Remplir tout les champs!</div>');
              redirect('Stock/index');
      }

      else{
         $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
              Nom utilisateur et Mot de passe Incorrect!!</div>');
              redirect('Stock/index');
      }
    // deuxieme
    
  }

  Public function AjoutMed(){
     $id=$this->uri->segment(3);

    if (isset($this->session->userdata['logged_in'])) {
        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

      $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
      $data=array('title'=>'GLORIA | Modification',
                  'photo'=>$logo,
                  'info'=>$this->session->message,
                  'u_nom' => $this->session->userdata['logged_in']['u_nom'],
                  'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
                  'y_year' => $this->session->userdata['logged_in']['y_year'],
                  'query'=>$this->stock_model->ShowStock($id),
                  'u_role' => $this->session->userdata['logged_in']['u_role'],
                  'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
                  'footer1'=>'KATEMO KABOTO EZECHIEL.');
   
    $this->load->view('ADMIN/STOCK/header',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/STOCK/add',$data);
    $this->load->view('ADMIN/STOCK/footer',$data);
  }

  public function EditStock(){
     $id=$this->uri->segment(3);
     $Qte=$this->input->post('Qte');
     $unitaire=$this->input->post('unitaire');
     $Dentrant=$this->input->post('Dentrant');
     $Dexp=$this->input->post('Dexp');
     $alerte=$this->input->post('alerte');
     $Fournisseur=$this->input->post('Fournisseur');
     $vente=$this->input->post('vente');
     $zero='0';

    

if(empty($Qte)|| empty($unitaire)|| empty($Dentrant)|| empty($Dexp) || empty($alerte) || empty($Fournisseur) || empty($vente)){
        $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
            Remplir tout les champs !</div>');
              redirect('Stock/index');  

    }elseif ($Qte < $zero || $alerte < $zero || $unitaire < $zero || $vente < $zero) {

             $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
            La quantité doit etre superieur à zero !</div>');
              redirect('Stock/index');
       
       
    }else{

       $data=$this->stock_model->EditStock();
       $this->session->set_flashdata('message','<div class="alert alert-success col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
           Modification Reussi!</div>');
              redirect('Stock/index');
       }
   
  }



  public function delete(){

    $id=$this->uri->segment(3);
   
     $username=$this->input->post('username');
     $password=$this->input->post('password');
     $role='ADMIN';

     $result = $this->db->get_where('users', array('u_username'=>$username,
                                                   'u_role'=>$role,
                                                   'u_glo'=>$password));
      $inDatabase = (bool)$result->num_rows();
      if($inDatabase){

        $data=$this->stock_model->delete($id);
        $this->session->set_flashdata('message','<div class="alert alert-success col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
            Suppression Reussie !</div>');
              redirect('Stock/index');
      }else if(empty($username)||empty( $password)){

         $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
              Remplir tout les champs!</div>');
              redirect('Stock/index');
      }

      else{
         $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
              Nom utilisateur et Mot de passe Incorrect!!</div>');
              redirect('Stock/index');
      }
  }

   public function Suppression(){

   $id=$this->uri->segment(3);

    if (isset($this->session->userdata['logged_in'])) {
        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

      $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
      $data=array('title'=>'GLORIA | Suppression',
                  'photo'=>$logo,
                  'info'=>$this->session->message,
                  'query'=>$this->stock_model->ShowStock($id),
                  'u_nom' => $this->session->userdata['logged_in']['u_nom'],
                  'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
                  'y_year' => $this->session->userdata['logged_in']['y_year'],
                  'u_role' => $this->session->userdata['logged_in']['u_role'],
                  'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
                  'footer1'=>'KATEMO KABOTO EZECHIEL.');
   
    $this->load->view('ADMIN/STOCK/header',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/STOCK/delete',$data);
    $this->load->view('ADMIN/STOCK/footer',$data);
 }

 Public function EditerMedicament(){
     $id=$this->uri->segment(3);

    if (isset($this->session->userdata['logged_in'])) {
        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

      $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
      $data=array('title'=>'GLORIA | Modification',
                  'photo'=>$logo,
                  'info'=>$this->session->message,
                  'query'=>$this->stock_model->ShowStock($id),
                  'u_nom' => $this->session->userdata['logged_in']['u_nom'],
                  'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
                  'y_year' => $this->session->userdata['logged_in']['y_year'],
                  'u_role' => $this->session->userdata['logged_in']['u_role'],
                  'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
                  'footer1'=>'KATEMO KABOTO EZECHIEL.');
   
    $this->load->view('ADMIN/STOCK/header',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/STOCK/EditerMedicament',$data);
    $this->load->view('ADMIN/STOCK/footer',$data);

 }

 public function searchMed(){
  $id=$this->input->post('med');
  $output = '';
  $data = $this->stock_model->searchMed($id);
  $output .= '
    
   
     
      <table >
         <thead >
            <tr>
            <th style="text-align: center;"><font size="25%">QUANTITE DISPONIBLE</font></th>
            <th style="text-align: center;"><font size="25%">CATEGORIE</font></th>
            <th style="text-align: center;"><font size="25%">PRIX</font></th>
            </tr>

        </thead> ';
  
    foreach($data->result() as $row){ 
   
       $output .=' 
       <tr>
       <td  style="text-align: center;"><font size="30%">'. $row->s_qteE .'</font></td>
       <td  style="text-align: center;"><font size="30%">'. $row->m_categorie .'</font></td>
       <td  style="text-align: center;"><font size="30%">'. $row->s_prixU.'</font></td>
       </tr>
       </table>

  <style type="text/css">
     table{
     border-collapse: collapse;
     align:center;
     margin-left:0px;
     }
    table,th, td{
    border: 1px solid black;
    padding: 15px;
   }
  </style>
      ';
   }
  
  echo  json_encode($output);

 }

 public function printAll(){

     $data=array('data'=>$this->stock_model->ShowStockPrint());

    $this->load->library('pdf');
    $html = $this->load->view('ADMIN/STOCK/printAll',$data,true);
    $this->pdf->createPDF($html, 'mypdf', false);

 }

  public function printSingle(){
     $id=$this->uri->segment(3);
     
     $data=array('data'=>$this->stock_model->printSingle($id));

    $this->load->library('pdf');
    $html = $this->load->view('ADMIN/STOCK/printSingle',$data,true);
    $this->pdf->createPDF($html, 'mypdf', false);

 }



// FIN DE LA CLASSE
}




