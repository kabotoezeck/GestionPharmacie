<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Medicaments extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->helper(array('form','url','file'));
		$this->load->library('form_validation');
		$this->load->model('Medicaments_model');

        //$this->load->library('Pdf');
	}
	
	public function index(){


    if (isset($this->session->userdata['logged_in'])) {

        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }


		$logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
		$data=array('title'=>'GLORIA | Medicaments',
					'photo'=>$logo,
					'info'=>$this->session->message,
          'u_nom' => $this->session->userdata['logged_in']['u_nom'],
          'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
          'y_year' => $this->session->userdata['logged_in']['y_year'],
          'u_role' => $this->session->userdata['logged_in']['u_role'],
					'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
					'footer1'=>'KATEMO KABOTO EZECHIEL.');
    
   
		$this->load->view('ADMIN/USERS/head',$data);
		$this->load->view('ADMIN/SIDEBAR/header',$data);
	  $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
		$this->load->view('ADMIN/USERS/body',$data);
		$this->load->view('ADMIN/USERS/footer',$data);
	}

	public function AddMed(){

	$med=$this->input->post("med");
	$categorie=$this->input->post("Categorie");

	$result = $this->db->get_where('med', array('m_name'=>$med,
                                                'm_categorie'=>$categorie));
             $inDatabase = (bool)$result->num_rows();

             if ($inDatabase==true){ 
             	$array=array('exist'=>'ces donnees existent deja');
             }elseif (empty($med) || empty($categorie)) {
             	# code...
             	$array=array('empty'=>'aucun champs ne doit rester vide');
             }else{
             	$data= $this->Medicaments_model->AddMed();
             	$array=array('success'=>'Enregistrement reussi');
	        }
	           echo json_encode($array);
         }

public function showMed(){ 
$data= $this->Medicaments_model->showMed();
echo json_encode($data);
        
}

public function EditMed(){

$id=$this->input->post("m_id");
$name=$this->input->post("med_edit");
$categorie=$this->input->post("Categorie_edit");

$result = $this->db->where('m_name',$name)->where('m_categorie',$categorie)->where('m_id !=',$id)->limit(1)->get('med');

          $inDatabase = (bool)$result->num_rows();
          if ($inDatabase==true){
           $array=array('exist'=>'ces donnees existent deja');

          }elseif (empty($name) || empty($categorie)) {
             	# code...
             	$array=array('empty'=>'aucun champs ne doit rester vide');
          }else{
             	$data= $this->Medicaments_model->EditMed();
             	$array=array('success'=>'Enregistrement reussi');
	        }
	           echo json_encode($array);


   }

 public function delete(){ 

     $username=$this->input->post('username');
	   $password=$this->input->post('password');
	   $id=$this->input->post('m_id_delete');
	   $role='ADMIN';

	   $result = $this->db->get_where('users', array('u_username'=>$username,
	   	                                             'u_role'=>$role,
                                                   'u_glo'=>$password));
      $inDatabase = (bool)$result->num_rows();
      if($inDatabase){

      	$data=$this->Medicaments_model->deleteMed($id);
    	$array=array('success'=>'<strong>Reussi!</strong>');
      }else{
      	$array=array('error'=>'<strong>Nom utilisateur et Mot de passe Incorrect </strong>');
      }
        echo json_encode($array); 
 }

public function stock(){

 if (isset($this->session->userdata['logged_in'])) {

        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }


		$logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
		$data=array('title'=>'GLORIA | Medicaments',
					      'photo'=>$logo,
					      'info'=>$this->session->message,
                'u_nom' => $this->session->userdata['logged_in']['u_nom'],
                'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
                'y_year' => $this->session->userdata['logged_in']['y_year'],
                'u_role' => $this->session->userdata['logged_in']['u_role'],
					      'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
					      'footer1'=>'KATEMO KABOTO EZECHIEL.');
    
   
		$this->load->view('ADMIN/STOCK/header',$data);
		$this->load->view('ADMIN/SIDEBAR/header',$data);
	  $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
		$this->load->view('ADMIN/STOCK/body',$data);
		$this->load->view('ADMIN/STOCK/footer',$data);
 }

 public function getMed(){
 	 // Search term
      $searchTerm = $this->input->post('searchTerm');

      // Get boats
      $response = $this->Medicaments_model->getMed($searchTerm);
      echo json_encode($response);
 }

 public function Categorie(){
 	 $med= $this->input->post('med');
 	 $response = $this->Medicaments_model->Categorie($med);
     echo json_encode($response);
 }

 public function CountAllMed(){
   $data=$this->Medicaments_model->CountAllMed();
   echo json_encode($data);
 }

 public function countManque(){
   $data=$this->Medicaments_model->countManque();
   echo json_encode($data);
 }


// FIN DE LA FONCTION PRINCIPALE
}