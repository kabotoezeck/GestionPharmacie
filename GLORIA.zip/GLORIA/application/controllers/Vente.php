<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vente extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    public function __construct(){
		parent::__construct();
		$this->load->helper(array('form','url','file'));
    $this->load->model('stock_model');
		$this->load->library('form_validation');
		$this->load->model('Vente_model');
    $this->load->library("cart");
 
   
	}

	public function index(){

		if (isset($this->session->userdata['logged_in'])) {
			 $u_nom = ($this->session->userdata['logged_in']['u_nom']);
             $u_username = ($this->session->userdata['logged_in']['u_username']);
             $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
             $u_role = ($this->session->userdata['logged_in']['u_role']);
             $y_year = ($this->session->userdata['logged_in']['y_year']);

			} else {
			//header("location: logout");
			}

		$logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
		$data=array('title'=>'GLORIA | Paramètres',
					'photo'=>$logo,
					'info'=>$this->session->message,
					'u_nom' => $this->session->userdata['logged_in']['u_nom'],
					'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
					'y_year' => $this->session->userdata['logged_in']['y_year'],
					'u_role' => $this->session->userdata['logged_in']['u_role'],
					'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
					'footer1'=>' Katemoezeck@gmail.com./ KATEMO KABOTO EZECHIEL.');


		$this->load->view('ADMIN/VENTE/head',$data);
		$this->load->view('ADMIN/SIDEBAR/header',$data);
		$this->load->view('ADMIN/SIDEBAR/sidebar',$data);
		$this->load->view('ADMIN/VENTE/body',$data);
		$this->load->view('ADMIN/VENTE/footer',$data);
    $this->clear();
	}

	public function getProduits(){
	 // Search term
      $searchTerm = $this->input->post('searchTerm');

      // Get boats
      $response = $this->Vente_model->getProduits($searchTerm);
      echo json_encode($response);
	}

	public function searchCategorie(){
	$produit=$this->input->post('produit');
	$data=$this->Vente_model->searchCategorie($produit);
	echo json_encode($data);
  }

  public function searchprix(){
  	$produit=$this->input->post('produit');
	$data=$this->Vente_model->searchprix($produit);
	echo json_encode($data);
  }

  public function searchName(){
  $produit=$this->input->post('produit');
	$data=$this->Vente_model->searchName($produit);
	echo json_encode($data);
  }

  public function searchQteE(){
  $produit=$this->input->post('produit');
  $data=$this->Vente_model->searchQteE($produit);
  echo json_encode($data);
  }

  public function searchAlert(){
  $produit=$this->input->post('produit');
  $data=$this->Vente_model->searchAlert($produit);
  echo json_encode($data);
  }

  public function searchstatut(){
  $produit=$this->input->post('produit');
  $data=$this->Vente_model->searchstatut($produit);
  echo json_encode($data);
  }

  public function getData(){
  $data=$this->Vente_model->getData();
  echo  json_encode($data);
  }

  Public function Add(){
  	$data=$this->Vente_model->Add();
  	echo json_encode($data);
  }

  

 Public function add_to_cart(){

  $id=$this->input->post('produit');
  $qte=$this->input->post('qte');
  $type=$this->input->post('type');
  $nameclient=$this->input->post('nameclient');
  $tel=$this->input->post('tel');
  $date=date('d-m-Y');
 
  

  $query="SELECT s_qteE FROM stock WHERE s_id='$id'";
  $res=$this->db->query($query);
  foreach ($res->result() as $key ) {
    # code...
    $val=$key->s_qteE;
    if($qte > $val){
      echo "<font color='red'><i class='fa fa-exclamation-triangle'></i> <strong>Attention! la Quantité de ce produit n'est pas disponible dans le stock!</strong> </font>";
    }else{
      $this->load->library("cart");

  $data = array(
         'id' => $this->input->post('produit'), 
         'name' => $this->input->post('name'), 
         'price' =>$this->input->post('prix'),
         'entry' =>$this->input->post('s_qte'),
         's_alert' =>$this->input->post('s_alert'),
         's_statut' =>$this->input->post('s_statut'), 
         'qty' => $this->input->post('qte'),
         'client'=>$this->input->post('nameclient'),
         'type'=>$this->input->post('type'),
         'date'=>$date,
         );



       $this->cart->insert($data);
       echo $this->view();
      
    }
  }
  
      
 }

 function load()
 {
  echo $this->view();
 }

 function remove()
 {
  $this->load->library("cart");
  $row_id = $_POST["row_id"];
  $data = array(
   'rowid'  => $row_id,
   'qty'  => 0
  );
  $this->cart->update($data);
  echo $this->view();
 }

 function clear()
 {
  $this->load->library("cart");
  $this->cart->destroy();
  echo $this->view();
 }


 function view()
 {
  $this->load->library("cart");
  $output = '';
  $output .= '
  
  <h3>Pannier de Vente</h3><br />
  <div class="table-responsive">
   <div align="right">
    <button type="button" id="clear_cart" class="btn btn-warning">Effacer le Pannier</button>
   </div>
   <br />
   <table class="table table-bordered">
    <tr>
     <th width="40%"><strong>Produits</strong></th>
     <th width="15%"><strong>Qte en Stock</strong></th>
     <th width="15%"><strong>Qte Achat</strong></th>
     <th width="40%"><strong>Prix Unitaire</strong></th>
     <th width="15%"><strong>Total</strong></th>
     <th width="15%"><strong>Action</strong></th>
    </tr>

  ';
  $count = 0;
  foreach($this->cart->contents() as $items)
  {
 
   $count++;
   $output .= '
   <tr> 
    <td>'.$items["name"].'</td>
    <td>'.$items['entry'].'</td>
    <td>'.$items["qty"].'</td>
    <td>'.$items["price"].'</td>
    <td>'.$items["subtotal"].'</td>
    <td><button type="button" name="remove" class="btn btn-danger btn-xs remove_inventory" id="'.$items["rowid"].'">Annuler</button></td>
   </tr>
   ';

  }
  $taux="SELECT comp_taux FROM compt";
  $req=$this->db->query($taux);
     foreach ($req->result() as $row) {
              $val=$row->comp_taux;
              $Taux=$this->cart->total()*$val;
              $roun=round($Taux,2);
              
          }
  $output .= '
   <tr>
    <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL  EN USD</td>
    <td class="bg-success" style="color:white;font-weight:bold;">'.$this->cart->total(). '&nbsp USD'.'</td>
    <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL  EN CDF</td>
    <td class="bg-success" colspan="4" style="color:white;font-weight:bold;">'.$roun. '&nbsp CDF'.'</td>
   
    
   </tr>
  </table>
     <div align="center">
    <button type="button" id="buy" class="btn btn-primary">Vente</button>
   </div>
  </div>

  ';

  if($count == 0)
  {
   $output = '<h3 align="center">Le Pannier est Vide!</h3>';
  }
 
  return $output;

 }
 public function pos(){

  $Qte="";
  $qty="";
  $output ="";
  $updateArray = array();
  $dataToSave=array();
  $statut='En manque';
  $val='0';
  $year =$this->session->userdata['logged_in']['y_id'];
  $nom="";
  $date="";
  $roun="";
  $type='';
  $subtotal='';

  $maxlength = 17;
  $chary = array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z","0", "1", "2", "3", "4", "5", "6", "7", "8", "9","A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");

  $return_str = "";
  for ( $x=0; $x<=$maxlength; $x++ ){
        $return_str .= $chary[rand(0, count($chary)-1)];
    }
  // fin de la fonction
  foreach($this->cart->contents() as $items)
    {

       $Qte=$items['entry'];
       $qty=$items['qty'];
       $alert=$items['s_alert'];
       $st=$items['s_statut'];
       $total= $Qte- $qty;

       if($total<=$alert){
          $updateArray[]= array('s_id'=>$items['id'],
                              's_qteE' =>$total,
                              's_statut'=>$statut);

          $array=array('success'=>'Enregistrement Reussi');

          }else{
          $updateArray[]= array('s_id'=>$items['id'],
                                's_qteE' =>$total);

          $array=array('success'=>'Enregistrement Reussi');
        } 

       $dataToSave[]= array(
         'v_qte' => $items['qty'],
         'v_total'=>$items['subtotal'],
         'y_id' =>$year,
         's_id' => $items['id'],
         'v_code'=>$return_str,
         'v_type'=>$items['type'],
         'v_date'=>$items['date'],
         'v_name'=>$items['client']);
 
     }
      // condition pour testé si le quantité est superieur au stock
     if($Qte<$qty){

         $output =array('message'=>'Désole');
         echo json_encode($output);

       }else{

   $this->db->update_batch('stock',$updateArray, 's_id');
   $this->db->insert_batch('vente',$dataToSave);
 
   $this->cart->contents();
   $this->cart->total();
   foreach ($this->cart->contents() as $key ) {
     # code...
            $nom=$key['client'];
            $date=$key['date'];
            $type=$key['type'];
            $qty=$key['qty'];
            $name=$key['name'];
            $price=$key['price'];
            $subtotal=$key['subtotal'];

            $taux="SELECT comp_taux FROM compt";
            $req=$this->db->query($taux);
    foreach ($req->result() as $row) {
            $val=$row->comp_taux;
            $Taux=$this->cart->total()*$val;
            $roun=round($Taux,2);
            }
          }

            $data=array('number'=>$this->convert_number($roun),
                        'total'=>$roun,
                        'cart'=>$this->cart->contents(),
                        'code'=> $return_str,
                        'client'=>$nom,
                        'date'=>$date,
                        'taux'=>$val,
                        'type'=>$type,
                        'subtotal'=>$this->cart->total());

            $this->load->library('pdf');
            $html =$this->load->view('ADMIN/VENTE/pdfreport',$data,true);
            $this->pdf->createPDF($html, 'mypdf', false);
    

 

    }

 }

 Public function printAndBuy(){
  $Qte="";
  $qty="";
  $output ="";
  $updateArray = array();
  $dataToSaveOne=array();
  $dataToSaveTwo=array();
  $statut='En manque';
  $val='0';
  $pay="";
  $year =$this->session->userdata['logged_in']['y_id'];
  // fonction pour les valeurs aleatoires
  // $maxlength = 17;
  // $chary = array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z","0", "1", "2", "3", "4", "5", "6", "7", "8", "9","A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");

  // $return_str = "";
  // for ( $x=0; $x<=$maxlength; $x++ ){
  //       $return_str .= $chary[rand(0, count($chary)-1)];
  //   }
    $return_str = 'GLO-'.date('u').rand(10, 99);
  // fin de la fonction

  foreach($this->cart->contents() as $items)
    {

       $Qte=$items['entry'];
       $qty=$items['qty'];
       $alert=$items['s_alert'];
       $st=$items['s_statut'];
       $pay=$items['type'];
       $total= $Qte- $qty;

       if($total<=$alert){
          $updateArray[]= array('s_id'=>$items['id'],
                              's_qteE' =>$total,
                              's_statut'=>$statut);

          $array=array('success'=>'Enregistrement Reussi');

          }else{
          $updateArray[]= array('s_id'=>$items['id'],
                                's_qteE' =>$total);

          $array=array('success'=>'Enregistrement Reussi');
        } 

       $dataToSaveOne[]= array(
         'v_qte' => $items['qty'],
         'v_total'=>$items['subtotal'],
         'y_id' =>$year,
         's_id' => $items['id'],
         'v_code'=>$return_str,
         'v_type'=>$items['type'],
         'v_date'=>$items['date'],
         'v_dette'=>$items['subtotal'],
         'v_name'=>$items['client']);

       $dataToSaveTwo[]= array(
         'v_qte' => $items['qty'],
         'v_total'=>$items['subtotal'],
         'y_id' =>$year,
         's_id' => $items['id'],
         'v_code'=>$return_str,
         'v_type'=>$items['type'],
         'v_date'=>$items['date'],
         'v_dette'=>$val,
         'v_name'=>$items['client']);
        
         

     }
  // condition pour testé si le quantité est superieur au stock
     if($Qte<$qty){

         $output =array('message'=>'Désole');
        return $output;

       }else{
         $this->db->update_batch('stock',$updateArray, 's_id');
      if($pay=="DETTE"){
         $this->db->insert_batch('vente',$dataToSaveTwo);
        }else{
          $this->db->insert_batch('vente',$dataToSaveOne);
        }

  
 
 
   $this->cart->contents();
   $this->cart->total();
   foreach ($this->cart->contents() as $key ) {
     # code...
            $nom=$key['client'];
            $date=$key['date'];
            $type=$key['type'];
            $qty=$key['qty'];
            $name=$key['name'];
            $price=$key['price'];
            $subtotal=$key['subtotal'];

            $taux="SELECT comp_taux FROM compt";
            $req=$this->db->query($taux);
    foreach ($req->result() as $row) {
            $val=$row->comp_taux;
            $Taux=$this->cart->total()*$val;
            $roun=round($Taux,2);
            }
          }
    $this->convert_number($roun); 

  $output.="<style>
* {
    font-size: 9px;
    font-family: 'Times New Roman';
}

td,
th,
tr,
table {
    border-top: 1px solid black;
    border-collapse: collapse;
}

td.description,
th.description {
    width: 95px;
    max-width: 95px;
}

td.quantity
th.quantity {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}


td.prix,
th.prix {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

td.price,
th.price {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

.centered {
    text-align: center;
    align-content: center;
}

.ticket {
    width: 155px;
    max-width: 155px;
}

img {
    max-width: inherit;
    width: inherit;
}

@media print {
    .hidden-print,
    .hidden-print * {
        display: none !important;
    }
}
</style>";

   $output .="<html lang='en'>
            <head>
              <meta http-equiv='X-UA-Compatible' content='ie=edge'>
              <link rel='stylesheet' href='style.css'>
              <title>IMPRESSION</title>
            </head>
            <body>
             <div class='ticket'>
             <p class='centered'>ETS GLORIA<br>
             PHARMACIE GLORIA</p> 
             <p >UVIRA-KALIMABENGE
             <br>TEL: +243 812125633
             <br> +243 994931850
             <br>RCCM:CD/UVIRA/RCCM/19-A-577
             <br>ID.Nat.441/04/3666</p>
             <hr>
             <p  class='centered'><strong>Facture N° : &nbsp;</strong>".$return_str."
             <br><strong>Nom du client : &nbsp;</strong>".$nom."
             <br><strong>Date d'impression : &nbsp;</strong>". $date."
             <br><strong>Taux  : &nbsp;</strong>". $val."
             <br><strong>".$type."</strong></p>";

            

    $output.="

              <table class='table table-striped table-bordered nowrap' id='scr-vrt-dt'>
                <thead>
                    <tr> 
                        <th class='description'>Désignation.</th>
                        <th class='quantity'>Qte</th>
                        <th class='prix'>P.U</th>
                        <th class='price'>P.T</th>
                    </tr>
                </thead>
                <tbody>";

  foreach ($this->cart->contents() as $key ) {
     # code...
           
            $nom=$key['client'];
            $date=$key['date'];
            $type=$key['type'];
            $qty=$key['qty'];
            $name=$key['name'];
            $price=$key['price'];
            $subtotal=$key['subtotal'];

   $output .="
                     <tr>
                        <td class='description'>".$key["name"]."</td>
                        <td class='quantity'>".$key["qty"]."</td>
                        <td class='prix'>".$key["price"]."</td>
                        <td class='price'>".$key["subtotal"]."</td>
                    </tr>  
           "; 
    }       
  $output .="<tr>
             <td  colspan='2' ><strong>Total en USD : &nbsp;</strong></td>
             <td colspan='2'>".$this->cart->total()."</td>
             </tr>
             <tr>
             <td  colspan='2' ><strong>Total en CDF : &nbsp;</strong></td>
             <td colspan='2'>".$roun."</td>
            </tr>
          </table>
          ";
   }
$output .="<p ><strong>Montant en lettres CDF : &nbsp;</strong>".$this->convert_number($roun)."</p>
           <p><strong>CHERS CLIENTS S.V.P VEUILLEZ VERIFIER VOS PRODUITS A LA LIVRAISON PAS DE RECLAMATIONS APRES</strong></p>
           </div>
           </body>
           <html>";
  $this->cart->destroy();
  $this->view();
  echo $output;
 }

 public function printPDF(){


  $Qte="";
  $qty="";
  $output ="";
  $updateArray = array();
  $dataToSave=array();
  $statut='En manque';
  $val='0';
  $year =$this->session->userdata['logged_in']['y_id'];
  // fonction pour les valeurs aleatoires
  $maxlength = 17;
  $chary = array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z","0", "1", "2", "3", "4", "5", "6", "7", "8", "9","A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");

  $return_str = "";
  for ( $x=0; $x<=$maxlength; $x++ ){
        $return_str .= $chary[rand(0, count($chary)-1)];
    }
  // fin de la fonction

  foreach($this->cart->contents() as $items)
    {

       $Qte=$items['entry'];
       $qty=$items['qty'];
       $alert=$items['s_alert'];
       $st=$items['s_statut'];
       $total= $Qte- $qty;

       if($total<=$alert){
          $updateArray[]= array('s_id'=>$items['id'],
                              's_qteE' =>$total,
                              's_statut'=>$statut);

          $array=array('success'=>'Enregistrement Reussi');

          }else{
          $updateArray[]= array('s_id'=>$items['id'],
                                's_qteE' =>$total);

          $array=array('success'=>'Enregistrement Reussi');
        } 

       $dataToSave[]= array(
         'v_qte' => $items['qty'],
         'v_total'=>$items['subtotal'],
         'y_id' =>$year,
         's_id' => $items['id'],
         'v_code'=>$return_str,
         'v_type'=>$items['type'],
         'v_date'=>$items['date'],
         'v_name'=>$items['client']);
       
               
              

     }
  // condition pour testé si le quantité est superieur au stock
     if($Qte<$qty){

         $output =array('message'=>'Désole');
         echo json_encode($output);

       }else{

        $this->db->update_batch('stock',$updateArray, 's_id');
        $this->db->insert_batch('vente',$dataToSave);
          $taux="SELECT comp_taux FROM compt";
            $req=$this->db->query($taux);
    foreach ($req->result() as $row) {
            $val=$row->comp_taux;
            $Taux=$this->cart->total()*$val;
            $roun=round($Taux,2);
            }

   
  
     $data=array('data'=>$this->cart->contents(),
                 'total'=>$this->cart->total(),
                 'code'=>$return_str,
                 'franc'=> $roun,
                 'taux'=> $val,
                 'nmbre'=> $this->convert_number($roun));



    //$this->load->library('pdf');
  $this->load->view('ADMIN/VENTE/print',$data);
   // $this->pdf->createPDF($html, 'mypdf', false);


    }
   echo  json_encode($output);

 }
 


function convert_number($number) {
    if (($number < 0) || ($number > 999999999)) {
      throw new Exception("Number is out of range");
    }

    $Gn = floor($number / 1000000);
    /* Millions (giga) */
    $number -= $Gn * 1000000;
    $kn = floor($number / 1000);
    /* Thousands (kilo) */
    $number -= $kn * 1000;
    $Hn = floor($number / 100);
    /* Hundreds (hecto) */
    $number -= $Hn * 100;
    $Dn = floor($number / 10);
    /* Tens (deca) */
    $n = $number % 10;
    /* Ones */

    $res = "";

    if ($Gn) {
      $res .= $this->convert_number($Gn) .  "Million";
    }

    if ($kn) {
      $res .= (empty($res) ? "" : " ") .$this->convert_number($kn) . " Mille";
    }

    if ($Hn) {
      $res .= (empty($res) ? "" : " ") .$this->convert_number($Hn) . " Cent";
    }

    $ones = array("" , "Un" , "Deux" , "Trois" , "Quatre" , "Cinq" , "Six" , "Sept" , "Huit" , "Neuf" , "Dix" , "Onze " , "Douze" , "Treize" , "Quatorze" , "Quinze" , "Seize" , "Dix-sept" , "Dix-huit" , "Dix-neuf");
    $tens = array( "" , "" , "Vingt" , "Trente" , " Quarante" , "Cinquante" , "Soixante" , "Septente" , "Quatre-vingt" , "Nonente" );

    if ($Dn || $n) {
      if (!empty($res)) {
        $res .= "  ";
      }

      if ($Dn < 2) {
         $res .= $ones[$Dn * 10 + $n];
      } else {
        $res .= $tens[$Dn];

        if ($n) {
          $res .= "-" . $ones[$n];
        }
      }
    }

    if (empty($res)) {
      $res = "zero";
    }

  $points = substr(number_format($number,2),-2,2);
   if($points > 0){
   $Dn = floor($points / 10);
  /* Tens (deca) */
  $n = $points % 10;
  /* Ones */    
  if ($Dn || $n) {
    if (!empty($res)) {
      $res .= " et ";
    }
    if ($Dn < 2) {
      $res .= $ones[$Dn * 10 + $n];
    } else {
      $res .= $tens[$Dn];
      if ($n) {
        $res .= "-" . $ones[$n];
      }
    }
    $res .= " Centime";
  }          
}
    return $res;
  }

public function Rapport(){
  if (isset($this->session->userdata['logged_in'])) {
            $u_nom = ($this->session->userdata['logged_in']['u_nom']);
            $u_username = ($this->session->userdata['logged_in']['u_username']);
            $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
            $u_role = ($this->session->userdata['logged_in']['u_role']);
            $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

    $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
    $data=array('title'=>'GLORIA | Paramètres',
          'photo'=>$logo,
          'info'=>$this->session->message,
          'u_nom' => $this->session->userdata['logged_in']['u_nom'],
          'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
          'y_year' => $this->session->userdata['logged_in']['y_year'],
          'u_role' => $this->session->userdata['logged_in']['u_role'],
          'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
          'footer1'=>' Katemoezeck@gmail.com./ KATEMO KABOTO EZECHIEL.');

    $this->load->view('ADMIN/VENTE/head',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/VENTE/rapport',$data);
    $this->load->view('ADMIN/VENTE/footer',$data);
}


public function rapportMonth(){
  $type=$this->input->post('categorie');
  $dateone=$this->input->post('dateone');
  $datetwo=$this->input->post('datetwo');
  $output = '';
  $total=$this->Vente_model->GetTotal($dateone,$datetwo,$type);
  $usd=$this->Vente_model->GetUSD($dateone,$datetwo,$type);
  $data = $this->Vente_model->rapportMonth($dateone,$datetwo,$type);
  $output .= '
    <div class="dt-responsive">
   
     <div style="height:300px;overflow:auto;">
      <table  class="table table-striped table-bordered nowrap" id="scr-vrt-dt">
         <thead class="thead-dark">
            <tr>
            
            
            <th style="text-align: center;"><small>#</small></th>
            <th style="text-align: center;"><small>Produits</small></th>
            <th style="text-align: center;"><small>Categories</small></th>
            <th style="text-align: center;"><small>Qtes Vendues</small></th>
            <th style="text-align: center;"><small>Montant</small></th>
            <th style="text-align: center;"><small>Type</small></th>
            <th style="text-align: center;"><small>Date Ajout</small></th>
          
           
            </tr>

        </thead> ';
   if($data->num_rows() > 0){
    $no=1;
    foreach($data->result() as $row){ 

            $dt=$row->v_create; 
            $date=date('d-m-Y à H:i:s ', strtotime($dt));
          
       $output .=' 
       <tr>
       <td>'. $no++.'</td>
       <td  style="text-align: center;">'. $row->m_name .'</td>
       <td  style="text-align: center;">'. $row->m_categorie .'</td>
       <td  style="text-align: center;">'. $row->v_qte.'</td>
       <td  style="text-align: center;">'. $row->v_total.'</td>
       <td  style="text-align: center;">'. $row->v_type.'</td>
       <td  style="text-align: center;">'.'le&nbsp; '.$date.'</td>
      </tr>
      ';
   }
  }else
  {
   $output .= '<tr>
       <td colspan="12">Désolé il y a pas des données suite à votre recherche! </td>
      </tr>';
  }
   $output .= ' <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL GLOBAL EN USD</td>
 

   <td class="bg-success" colspan="3" style="color:white;font-weight:bold;">'.$total. '&nbsp USD'.'</td>
   <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL GLOBAL EN CDF</td>
   <td class="bg-success" colspan="3" style="color:white;font-weight:bold;">'.$usd. '&nbsp CDF'.'</td>
   </table> </a>';
  echo $output;
}

public function search(){
   if (isset($this->session->userdata['logged_in'])) {
            $u_nom = ($this->session->userdata['logged_in']['u_nom']);
            $u_username = ($this->session->userdata['logged_in']['u_username']);
            $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
            $u_role = ($this->session->userdata['logged_in']['u_role']);
            $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

    $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
    $data=array('title'=>'GLORIA | RECHERCHE',
                'photo'=>$logo,
                'info'=>$this->session->message,
                'u_nom' => $this->session->userdata['logged_in']['u_nom'],
                'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
                'y_year' => $this->session->userdata['logged_in']['y_year'],
                'u_role' => $this->session->userdata['logged_in']['u_role'],
                'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
                'footer1'=>' Katemoezeck@gmail.com./ KATEMO KABOTO EZECHIEL.');

    $this->load->view('ADMIN/VENTE/head',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/VENTE/recherhe_facture',$data);
    $this->load->view('ADMIN/VENTE/footer',$data);
}

public function searchBill(){
  $code=$this->input->post('search_bill');
  $data=$this->Vente_model->searchBill($code);
  $total=$this->Vente_model->searchBilltotal($code);
  $usd=$this->Vente_model->searchBillUSD($code);
  $delete= base_url('Vente/delete_Bill/');
  $dette= base_url('Vente/paie/');
  $u_role=$this->session->userdata['logged_in']['u_role'];
  
  $output = '';
  $output .= '
    <div class="dt-responsive">
     <div style="height:300px;overflow:auto;">
      <table  class="table table-striped table-bordered nowrap" id="scr-vrt-dt">
         <thead class="thead-dark">
            <tr>
            
            
            <th style="text-align: center;"><small>#</small></th>
            <th style="text-align: center;"><small>Produits</small></th>
            <th style="text-align: center;"><small>Categories</small></th>
            <th style="text-align: center;"><small>Qtes Vendues</small></th>
            <th style="text-align: center;"><small>Montant Payé</small></th>
            <th style="text-align: center;"><small>Nom du client</small></th>
            <th style="text-align: center;"><small>statut</small></th>
            <th style="text-align: center;"><small>Date Ajout</small></th>
          
           
            </tr>

        </thead> ';
        if($data->num_rows() > 0){
           $no=1;
           foreach($data->result() as $row){ 

            $dt=$row->v_create; 
            $date=date('d-m-Y à H:i:s ', strtotime($dt));
          
             $output .=' 
             <tr>
             <td>'. $no++.'</td>
             <td  style="text-align: center;">'. $row->m_name .'</td>
             <td  style="text-align: center;">'. $row->m_categorie .'</td>
             <td  style="text-align: center;">'. $row->v_qte.'</td>
             <td  style="text-align: center;">'. $row->v_total.'</td>
             <td  style="text-align: center;">'. $row->v_name.'</td>
             <td  style="text-align: center;">'. $row->v_type.'</td>
             <td  style="text-align: center;">'.'le&nbsp; '.$date.'</td>
            </tr>
            ';
           }
         }else{

         $output .= '<tr>
                    <td colspan="12">Désolé il y a pas des données suite à votre recherche! </td>
                    </tr>';
        }

        $output .= '<td class="bg-dark" style="color:white;font-weight:bold;">TOTAL GLOBAL EN USD</td>
                    <td class="bg-success" colspan="3" style="color:white;font-weight:bold;">'.$total. '&nbsp USD'.'</td>
                    <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL GLOBAL EN CDF</td>
                    <td class="bg-success" colspan="3" style="color:white;font-weight:bold;">'.$usd. '&nbsp CDF'.'</td>
                    </table> </a>';
                    ?>
                    <?php 
                    if($u_role=="ADMIN"){

                    $output .=
                    '<div align="center">
                     <div class="modal-footer">
                     <a href="'.$delete.$code.'"  type="submit"  class="btn btn-danger">Supprimer la facture</a>
                     <a href="'.$dette.$code.'" type="button" class="btn btn-secondary">Payer la dette</a>
                     </div>
                     </div>';
                  };

                      
           echo $output;
}

public function paieBill(){

   $code=$this->uri->segment(3);
   $pye=$this->input->post('paie');
   $cod=$this->input->post('code');
   $statut='CASH';
   $montant=$this->input->post('unitaire');
   $qty=$this->input->post('Qte');
   $zero="0";
   $conditionOne=$qty-$pye;
   $conditionTwo=$montant-$pye;
   $roundOne=round($conditionOne,2);
   $roundTwo=round($conditionTwo,2);
   $updateArray=array();
   $id=array();

    $sql="SELECT v_id FROM vente WHERE  vente.v_code='$cod'";
    $query=$this->db->query($sql);
       foreach ($query->result() as $key) {
          # code...
     $id[]=$key->v_id;
    
   }
 

   if($qty==$zero){

        if(empty($pye)){
     $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Désolé!</strong>
             Il faut remplir tous les champs!</div>');
              redirect('vente/search');
  }else{
 
      if($roundTwo == $zero){

        for($x = 0; $x < sizeof($id); $x++){

  
            $updateArray[] = array(
           'v_id'=>$id[$x],
           'v_dette' =>$zero,
           'v_type' => $statut);
  }        


          $this->db->update_batch('vente',$updateArray,'v_id');
          $this->session->set_flashdata('message','<div class="alert alert-success col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
             Action reussie!</div>');
              redirect('vente/search');

      }elseif($montant < $pye){

         $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Désolé!</strong>
            le Montant est superieur au Solde!</div>');
              redirect('vente/search');
      }else{


         $updateArray[]= array('v_dette'=>$roundTwo,
                               'v_id'=> $code);

        
          $this->db->update_batch('vente',$updateArray, 'v_id');
          $this->session->set_flashdata('message','<div class="alert alert-success col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
             Action reussie!</div>');
              redirect('vente/search');

      }
   }
 }else{

    if(empty($pye)){
     $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Désolé!</strong>
             Il faut remplir tous les champs!</div>');
              redirect('vente/search');
  }else{
 
      if($roundOne == $zero){

        for($x = 0; $x < sizeof($id); $x++){

  
            $updateArray[] = array(
           'v_id'=>$id[$x],
           'v_dette' =>$zero,
           'v_type' => $statut);
  }        


          $this->db->update_batch('vente',$updateArray,'v_id');
          $this->session->set_flashdata('message','<div class="alert alert-success col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
             Action reussie!</div>');
              redirect('vente/search');

      }elseif($qty < $pye){

         $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Désolé!</strong>
            le Montant est superieur au Solde!</div>');
              redirect('vente/search');
      }else{


         $updateArray[]= array('v_dette'=>$roundOne,
                               'v_id'=> $code);

        
          $this->db->update_batch('vente',$updateArray, 'v_id');
          $this->session->set_flashdata('message','<div class="alert alert-success col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
             Action reussie!</div>');
              redirect('vente/search');

      }
   }

 }



  

}

public function delete_Bill(){
  $code=$this->uri->segment(3);
  $statutone='En manque';
  $statutTwo='Disponible';
  $sql="SELECT * FROM vente,stock WHERE stock.s_id=vente.s_id AND vente.v_code='$code'";
  $query=$this->db->query($sql);

   if($query->num_rows() > 0){
    foreach ($query->result() as $key) {
          # code...
     $stock=$key->s_qteE;
     $vente=$key->v_qte;
     $total=$stock+$vente;
     $id=$key->s_id;
     $alert=$key->s_alert;

     if($total > $alert){
        $updateArray[]= array('s_qteE'=>$total,
                              's_id'=>$id,
                              's_statut'=> $statutTwo);
     }else{
       $updateArray[]= array('s_qteE'=>$total,
                              's_id'=>$id,
                              's_statut'=> $statutone);
     }

    
    $updateArray[]= array('s_qteE'=>$total,
                           's_id'=>$id);

  }
   $this->db->update_batch('stock',$updateArray, 's_id');
   $this->db->where('v_code', $code);   
   $result=$this->db->delete('vente');

      $this->session->set_flashdata('message','<div class="alert alert-success col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
            Suppression Reussie !</div>');
              redirect('vente/search');
  }else{

    $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Désolé!</strong>
           Il ya pas des données à supprimer !</div>');
              redirect('vente/search');
  }
}

public function paie(){
  $code=$this->uri->segment(3);
  $sql="SELECT * FROM vente,stock WHERE stock.s_id=vente.s_id AND vente.v_code='$code'";
  $query=$this->db->query($sql);

   if($query->num_rows() > 0){ 


 

 if (isset($this->session->userdata['logged_in'])) {
            $u_nom = ($this->session->userdata['logged_in']['u_nom']);
            $u_username = ($this->session->userdata['logged_in']['u_username']);
            $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
            $u_role = ($this->session->userdata['logged_in']['u_role']);
            $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

    $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
    $data=array('title'=>'GLORIA | Dette',
          'photo'=>$logo,
          'info'=>$this->session->message,
          'sql'=>$this->Vente_model->paie($code),
          'total'=>$this->Vente_model->totalpaie($code),
          'tot'=>$this->Vente_model->tot($code),
          'nbr'=>$this->Vente_model->nbreprduit($code),
          'u_nom' => $this->session->userdata['logged_in']['u_nom'],
          'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
          'y_year' => $this->session->userdata['logged_in']['y_year'],
          'u_role' => $this->session->userdata['logged_in']['u_role'],
          'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
          'footer1'=>' Katemoezeck@gmail.com./ KATEMO KABOTO EZECHIEL.');

    $this->load->view('ADMIN/VENTE/head',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/VENTE/dette',$data);
    $this->load->view('ADMIN/VENTE/footer',$data);


     }else{

    $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Désolé!</strong>
           Il ya pas des données à Payer !</div>');
              redirect('vente/search');
  }

}

public function ReportDay(){

  if (isset($this->session->userdata['logged_in'])) {
            $u_nom = ($this->session->userdata['logged_in']['u_nom']);
            $u_username = ($this->session->userdata['logged_in']['u_username']);
            $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
            $u_role = ($this->session->userdata['logged_in']['u_role']);
            $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

    $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
    $data=array('title'=>'GLORIA | Paramètres',
          'photo'=>$logo,
          'info'=>$this->session->message,
          'u_nom' => $this->session->userdata['logged_in']['u_nom'],
          'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
          'y_year' => $this->session->userdata['logged_in']['y_year'],
          'u_role' => $this->session->userdata['logged_in']['u_role'],
          'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
          'footer1'=>' Katemoezeck@gmail.com./ KATEMO KABOTO EZECHIEL.');

    $this->load->view('ADMIN/VENTE/head',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/VENTE/ReportDay',$data);
    $this->load->view('ADMIN/VENTE/footer',$data);
}

public function reportDayALL(){
  $type=$this->input->post('categorie');
  $dateone=$this->input->post('dateone');

  $output = '';
  $total=$this->Vente_model->GetTotalDay($dateone,$type);
  $usd=$this->Vente_model->GetUSDDay($dateone,$type);
  $data = $this->Vente_model->reportDayALL($dateone,$type);
  $output .= '
    <div class="dt-responsive">
   
     <div style="height:300px;overflow:auto;">
      <table  class="table table-striped table-bordered nowrap" id="scr-vrt-dt">
         <thead class="thead-dark">
            <tr>
            
            
            <th style="text-align: center;"><small>#</small></th>
            <th style="text-align: center;"><small>Produits</small></th>
            <th style="text-align: center;"><small>Categories</small></th>
            <th style="text-align: center;"><small>Qtes Vendues</small></th>
            <th style="text-align: center;"><small>Montant</small></th>
            <th style="text-align: center;"><small>Type</small></th>
            <th style="text-align: center;"><small>Date Ajout</small></th>
          
           
            </tr>

        </thead> ';
   if($data->num_rows() > 0){
    $no=1;
    foreach($data->result() as $row){ 

            $dt=$row->v_create; 
            $date=date('d-m-Y à H:i:s ', strtotime($dt));
          
       $output .=' 
       <tr>
       <td>'. $no++.'</td>
       <td  style="text-align: center;">'. $row->m_name .'</td>
       <td  style="text-align: center;">'. $row->m_categorie .'</td>
       <td  style="text-align: center;">'. $row->v_qte.'</td>
       <td  style="text-align: center;">'. $row->v_total.'</td>
       <td  style="text-align: center;">'. $row->v_type.'</td>
       <td  style="text-align: center;">'.'le&nbsp; '.$date.'</td>
      </tr>
      ';
   }
  }else
  {
   $output .= '<tr>
       <td colspan="12">Désolé il y a pas des données suite à votre recherche! </td>
      </tr>';
  }
   $output .= ' <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL GLOBAL EN USD</td>
 

   <td class="bg-success" colspan="3" style="color:white;font-weight:bold;">'.$total. '&nbsp USD'.'</td>
   <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL GLOBAL EN CDF</td>
   <td class="bg-success" colspan="3" style="color:white;font-weight:bold;">'.$usd. '&nbsp CDF'.'</td>
   </table> </a>';
  echo $output;

}

}
