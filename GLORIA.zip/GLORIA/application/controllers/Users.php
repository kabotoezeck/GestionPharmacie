<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->helper(array('form','url','file'));
		$this->load->library('form_validation');
		$this->load->model('Users_model');

        //$this->load->library('Pdf');
	}
	
	public function index(){


    if (isset($this->session->userdata['logged_in'])) {

        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }
       

		$logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
		$data=array('title'=>'GLORIA | Utilisateur',
					'photo'=>$logo,
					'info'=>$this->session->message,
          'u_nom' => $this->session->userdata['logged_in']['u_nom'],
          'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
          'y_year' => $this->session->userdata['logged_in']['y_year'],
          'u_role' => $this->session->userdata['logged_in']['u_role'],
					'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
					'footer1'=>'KATEMO KABOTO EZECHIEL.');
    
   
		$this->load->view('ADMIN/USERS/head',$data);
		$this->load->view('ADMIN/SIDEBAR/header',$data);
	  $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
		$this->load->view('ADMIN/USERS/body',$data);
		$this->load->view('ADMIN/USERS/footer',$data);
	}

	public function AddUsers(){

		$name=$this->input->post('u_name');
		$username=$this->input->Post('u_username');
		$password=$this->input->post('c');
		$role=$this->input->post('u_role');
		$genre=$this->input->post('u_genre');

	
		// REGLE DES VALIDATIONS

		$message=array(array('field'=>'u_name',
              'label'=>'Nom',
              'rules'=>'required',
              'errors'=>array('required' => '<font color="red"><i class=" fa fa-exclamation-triangle"></i> <strong>Attention!</strong>  <small>le champ  %s doit être remplie.</small></font>')),

              array('field'=>'u_username',
              'label'=>"Nom d'Utilisateur",
              'rules'=>'required|is_unique[Users.u_username.'.$username.']',
              'errors'=>array('required' => '<font color="red"><i class=" fa fa-exclamation-triangle"></i> <strong>Attention!</strong>  <small>le champ  %s doit être remplie.</small></font>',

           	 "is_unique"=>"<font color='red'><i class='fa fa-exclamation-triangle'></i> <strong>Attention!</strong> <small>le %s existe déjà.</small></font>")),

              array('field'=>'u_password',
              'label'=>'Mot de passe',
              'rules'=>'required',
              'errors'=>array('required' => '<font color="red"><i class=" fa fa-exclamation-triangle"></i> <strong>Attention!</strong>  <small>le champ  %s doit être remplie.</small></font>')),

              array('field'=>'u_genre',
              'label'=>'Genre',
              'rules'=>'required',
              'errors'=>array('required' => '<font color="red"><i class=" fa fa-exclamation-triangle"></i> <strong>Attention!</strong>  <small>le champ  %s doit être remplie.</small></font>')),

              array('field'=>'u_role',
              'label'=>'Rôle',
              'rules'=>'required',
              'errors'=>array('required' => '<font color="red"><i class=" fa fa-exclamation-triangle"></i> <strong>Attention!</strong>  <small>le champ  %s doit être remplie.</small></font>')));

              //CHEMIN POUR LES AVATARS

              $MAN= base_url("assets/h.png");
      		    $WOMEN= base_url("assets/f.png");

            $this->form_validation->set_rules($message);
      		 	
      		 if ($this->form_validation->run()){
      		 	
      		 	if($genre=='Homme'){

                       $data= $this->Users_model->AddUsers($MAN);
                       $array=array('success'=> '<div class="alert alert-success col-lg-3 col-md-3 col-sm-3 col-xs-12"style="font-size:15px;">
              				<button  type="button" class="close" data-dismiss="alert" arial-label="close">
             				<span arial-hidden="true">&times;</span>
                            </button><i class="fa fa-thumbs-up"></i> <strong> Enregistrement fait</strong>
                            </Successiv>');

      			}if($genre=='Femme'){
      				 $data= $this->Users_model->AddUsers($WOMEN);
                     $array=array('success'=> '<div class="alert alert-success col-lg-3 col-md-3 col-sm-3 col-xs-12"style="font-size:15px;">
              				<button  type="button" class="close" data-dismiss="alert" arial-label="close">
             				<span arial-hidden="true">&times;</span>
                            </button><i class="fa fa-thumbs-up"></i> <strong> Enregistrement fait</strong>
                            </Successiv>');
      			}
      		    }else{

      				 $array=array('error'=>TRUE,
                      			  'u_name_error'=>form_error('u_name'),
                                  'u_username_error'=>form_error('u_username'),
                                  'u_password_error'=>form_error('u_password'),
                            'u_role_error'=>form_error('u_role'),
                            'u_genre_error'=>form_error('u_genre'));
      			}
      			 echo json_encode($array);
      		}
      		// FONCTION POUR AFFICHER LES UTILISATEURS

    public function showUser(){

    	$data= $this->Users_model->showUser();
        echo json_encode($data); 
    }

// fonction pour la modification des donnnees
public function modifier(){

        $id=$this->input->post('u_id_edit');
        $name= $this->input->post('u_name_edit');
        $username=$this->input->post('u_username_edit');
        $role=$this->input->post('u_role_edit');
        $password=$this->input->post('u_password_edit');
        $sexe=$this->input->post('u_genre_edit');

          //CHEMIN POUR LES AVATARS

        $MAN= base_url("assets/h.png");
        $WOMEN= base_url("assets/f.png");


       if(empty($name) OR empty($username) OR empty($password) OR empty($role) OR empty($sexe)){
			$this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
		                                      <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		                                      <span arial-hidden="true">&times;</span>
		                                      </button> <strong>Attention!</strong>
		                                   Remplir tout les champs !</div>');
        	                                  redirect('Users/index');
		}
		
		if( $this->db->where('u_username', $username)->where('u_id !=', $id)->limit(1)->get('users')->num_rows()){ 
			$this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
		                                      <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		                                      <span arial-hidden="true">&times;</span>
		                                      </button> <strong>Attention !</strong>
		                                     le nom Utilisateur existe déjà</div>');
        	                                  redirect('Users/index');
		}
       if($sexe=='Homme'){
          $data= $this->Users_model->Modify($MAN);       
      }if($sexe=='Femme'){
      	  $data= $this->Users_model->Modify($WOMEN);
      	}  
      	$this->session->set_flashdata('message','<div class="alert alert-success col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
		                                      <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		                                      <span arial-hidden="true">&times;</span>
		                                      </button> <strong>succès !</strong>
		                                    Enregistrement Reussi</div>');
        	                                  redirect('Users/index'); 
    }

    public function statut(){

    $data=$this->Users_model->statut();
    echo json_encode($data);

    }

    public function delete(){

    $data=$this->Users_model->delete();
    echo json_encode($data);
    }

     public function CountAllUsers(){

    $data=$this->Users_model->CountAllUsers();
    echo json_encode($data);
    }
          
}
