<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Depenses extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    public function __construct(){
		parent::__construct();
		$this->load->helper(array('form','url','file'));
		$this->load->library('form_validation');
		$this->load->model('Depense_model');
        //$this->load->library('Pdf');
	}

	public function index(){

		if (isset($this->session->userdata['logged_in'])) {
			 $u_nom = ($this->session->userdata['logged_in']['u_nom']);
             $u_username = ($this->session->userdata['logged_in']['u_username']);
             $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
             $u_role = ($this->session->userdata['logged_in']['u_role']);
             $y_year = ($this->session->userdata['logged_in']['y_year']);

			} else {
			//header("location: logout");
			}

		$logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
		$data=array('title'=>'GLORIA | Paramètres',
					'photo'=>$logo,
					'info'=>$this->session->message,
					'u_nom' => $this->session->userdata['logged_in']['u_nom'],
					'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
					'y_year' => $this->session->userdata['logged_in']['y_year'],
					'u_role' => $this->session->userdata['logged_in']['u_role'],
					'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
					'footer1'=>' Katemoezeck@gmail.com./ KATEMO KABOTO EZECHIEL.');

		$this->load->view('ADMIN/DEPENSES/head',$data);
		$this->load->view('ADMIN/SIDEBAR/header',$data);
		$this->load->view('ADMIN/SIDEBAR/sidebar',$data);
		$this->load->view('ADMIN/DEPENSES/body',$data);
		$this->load->view('ADMIN/DEPENSES/footer',$data);
	}

	public function rapportMonth(){

	$data=$this->Depense_model->rapportMonth();
	$total=$this->Depense_model->showtotal();
  $usd=$this->Depense_model->USD();
    $output = '';
	  
    $output .= '
    <div class="dt-responsive">
   
     <div style="height:500px;overflow:auto;">
      <table  class="table table-striped table-bordered nowrap" id="scr-vrt-dt">
         <thead class="thead-dark">
            <tr>
            <th>#</th>
            <th style="text-align: center;"><small>Produits</small></th>
            <th style="text-align: center;"><small>Categories<small></th>
            <th style="text-align: center;"><small>Quantité des Produits</small></th>
            <th style="text-align: center;"><small>Nom du Fournisseur</small></th>
            <th style="text-align: center;"><small>Date Entrée</small></th>
            <th style="text-align: center;"><small>Prix Unitaire USD</small></th>
            <th style="text-align: center;"><small>Prix de Vente</small></th>
            <th style="text-align: center;"><small>Prix Total </small></th>
            
            </tr>
        </thead> ';
    
  if($data->num_rows() > 0)
  {
	
   $no=1;

   foreach($data->result() as $row)
  { 
  	       $dte=$row->sv_daten;
           $date=date('d-m-Y ', strtotime($dte));

  	$output .=' 
       <tr>
       <td>'. $no++.'</td>
       <td  style="text-align: center;">'.$row->m_name .'</td>
       <td  style="text-align: center;">'.$row->m_categorie.'</td>
       <td  style="text-align: center;">'.$row->sv_qteE.'</td>
       <td  style="text-align: center;">'.$row->sv_fournisseur.'</td>
       <td  style="text-align: center;">'.'Le &nbsp;'.$date.'</td>
       <td  style="text-align: center;">'.$row->sv_prixU.'</td>
       <td  style="text-align: center;">'.$row->sv_vente.'</td>
       <td  style="text-align: center;">'.$row->sv_prixT.'</td>

       
     
 
      </tr>
      ';
}
}
  else
  {
   $output .= '<tr>
       <td colspan="12">Désolé il y a pas des données suite à votre recherche! </td>
      </tr>';
  }
  
  $output .= ' <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL GLOBAL  USD</td>
 

   <td class="bg-success" colspan="3" style="color:white;font-weight:bold;">'.$total. '&nbsp USD'.'</td>
   <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL  EN CDF</td>
    <td class="bg-success" colspan="4" style="color:white;font-weight:bold;">'.$usd. '&nbsp CDF'.'</td>
   </table> </a>';
  echo  json_encode($output);
	}



  public function AddCharge(){

     $montant=$this->input->post('Montant');
     $date=$this->input->post('depense');
     $desc=$this->input->post('desc');
     $zero="0";
     if(empty($montant) || empty($date) || empty($desc)){
      $array=array('empty'=>'aucun champs ne doit rester vide');
     }else if($montant < $zero){
      $array=array('sup'=>'Le montant doit superieur à zero');
     }else{
      $data=$this->Depense_model->AddCharge();
      $array=array('success'=>'<strong>Reussi!</strong>');
     }
     echo  json_encode($array);
  }

    public function Getdate(){
    $date=$this->input->post('date');
    $data=$this->Depense_model->Getdate($date);
    $total=$this->Depense_model->GetTotal($date);
    $usd=$this->Depense_model->GetUSD($date);
    $base_url= base_url('Depenses/modify/');
    $delete= base_url('Depenses/delete/');
   
    $output = '';
    
    $output .= '
    <div class="dt-responsive">
   
     <div style="height:500px;overflow:auto;">
      <table  class="table table-striped table-bordered nowrap" id="scr-vrt-dt">
         <thead class="thead-dark">
            <tr>
            <th>#</th>
            <th style="text-align: center;"><small>Date</small></th>
            <th style="text-align: center;"><small>Montant En USD<small></th>
            <th style="text-align: center;"><small>Motif</small></th>
            <th style="text-align: center;"><small>Date Ajout</small></th>
            <th style="text-align: center;"><small>Actions</small></th>
            </tr>
        </thead> ';
    
  if($data->num_rows() > 0)
  {
  
   $no=1;

   foreach($data->result() as $row)
  { 
           $dte=$row->ch_date;
           $dt=$row->ch_create;
           $date=date('d-m-Y ', strtotime($dte));
           $dat=date('d-m-Y à H:i:s ', strtotime($dt));

    $output .=' 
       <tr>
       <td>'. $no++.'</td>
       <td  style="text-align: center;">'.'Le &nbsp;'.$date.'</td>
       <td  style="text-align: center;">'.$row->ch_montant.'</td>
       <td  style="text-align: center;">'.$row->ch_desc.'</td>
       <td  style="text-align: center;">'.'Le &nbsp;'.$dat.'</td>
       <td  style="text-align: center;">'.'<a href="' .$base_url.$row->ch_id.'" ><i class="ik ik-edit f-16 text-info"></i></a>'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'&nbsp;'.'<a href="'.$delete.$row->ch_id.'" ><i class="ik ik-trash-2 f-16 text-red"></i></a></td>
 
      </tr>
      ';
}
}
  else
  {
   $output .= '<tr>
       <td colspan="12">Désolé il y a pas des données suite à votre recherche! </td>
      </tr>';
  }
  
  $output .= ' <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL GLOBAL EN USD</td>
 

   <td class="bg-success" colspan="3" style="color:white;font-weight:bold;">'.$total. '&nbsp USD'.'</td>
   <td class="bg-dark" style="color:white;font-weight:bold;">TOTAL GLOBAL EN CDF</td>
   <td class="bg-success" colspan="3" style="color:white;font-weight:bold;">'.$usd. '&nbsp CDF'.'</td>
   </table> </a>';
  echo  json_encode($output);
  }

  public function modify(){
     $id=$this->uri->segment(3);

    if (isset($this->session->userdata['logged_in'])) {
        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

      $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
      $data=array('title'=>'GLORIA | Modification',
                  'photo'=>$logo,
                  'info'=>$this->session->message,
                  'query'=>$this->Depense_model->ShowCharge($id),
                  'u_nom' => $this->session->userdata['logged_in']['u_nom'],
                  'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
                  'y_year' => $this->session->userdata['logged_in']['y_year'],
                  'u_role' => $this->session->userdata['logged_in']['u_role'],
                  'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
                  'footer1'=>'KATEMO KABOTO EZECHIEL.');
   
    $this->load->view('ADMIN/DEPENSES/head',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/DEPENSES/modify',$data);
    $this->load->view('ADMIN/DEPENSES/footer',$data);
  }

  public function EditCharge(){

     $id=$this->uri->segment(3);
     $montant=$this->input->post('Montant');
     $date=$this->input->post('date');
     $description=$this->input->post('desc');
     $zero='0';

    

     if(empty($montant)|| empty($date)|| empty($description)){
        $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
            Remplir tout les champs !</div>');
              redirect('Depenses/index');  

    }elseif ($montant < $zero) {

             $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
            Le montant doit etre superieur à zero !</div>');
              redirect('Depenses/index');
       
       
    }else{

       $data=$this->Depense_model->EditCharge($id);
       $this->session->set_flashdata('message','<div class="alert alert-success col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
           Modification Reussi!</div>');
              redirect('Depenses/index');
       }
  }

 public function delete(){

   $id=$this->uri->segment(3);

    if (isset($this->session->userdata['logged_in'])) {
        $u_nom = ($this->session->userdata['logged_in']['u_nom']);
        $u_username = ($this->session->userdata['logged_in']['u_username']);
        $u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
        $u_role = ($this->session->userdata['logged_in']['u_role']);
        $y_year = ($this->session->userdata['logged_in']['y_year']);

      } else {
      //header("location: logout");
      }

      $logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';
      $data=array('title'=>'GLORIA | Suppression',
                  'photo'=>$logo,
                  'info'=>$this->session->message,
                  'query'=>$this->Depense_model->ShowCharge($id),
                  'u_nom' => $this->session->userdata['logged_in']['u_nom'],
                  'u_avatar' =>$this->session->userdata['logged_in']['u_avatar'],
                  'y_year' => $this->session->userdata['logged_in']['y_year'],
                  'u_role' => $this->session->userdata['logged_in']['u_role'],
                  'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
                  'footer1'=>'KATEMO KABOTO EZECHIEL.');
   
    $this->load->view('ADMIN/DEPENSES/head',$data);
    $this->load->view('ADMIN/SIDEBAR/header',$data);
    $this->load->view('ADMIN/SIDEBAR/sidebar',$data);
    $this->load->view('ADMIN/DEPENSES/delete',$data);
    $this->load->view('ADMIN/DEPENSES/footer',$data);
 }

 Public function deleteOVER(){
     $id=$this->uri->segment(3);
   
     $username=$this->input->post('username');
     $password=$this->input->post('password');
     $role='ADMIN';

     $result = $this->db->get_where('users', array('u_username'=>$username,
                                                   'u_role'=>$role,
                                                   'u_glo'=>$password));
      $inDatabase = (bool)$result->num_rows();
      if($inDatabase){

        $data=$this->Depense_model->delete($id);
        $this->session->set_flashdata('message','<div class="alert alert-success col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Bravo!</strong>
            Suppression Reussie !</div>');
              redirect('Depenses/index');
      }else if(empty($username)||empty( $password)){

         $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-4 col-md-4 col-sm-4 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
              Remplir tout les champs!</div>');
              redirect('Depenses/index');
      }

      else{
         $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-6 col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
            <button  type="button" class="close" data-dismiss="alert" arial-label="close">
            <span arial-hidden="true">&times;</span>
            </button> <strong>Attention!</strong>
              Nom utilisateur et Mot de passe Incorrect!!</div>');
              redirect('Depenses/index');
      }
       
 }

 public function printAll(){
  $date=$this->input->post('dateprint');



  $data=array('data'=>$this->Depense_model->Getdate($date),
              'date'=>$date,
              'total'=>$this->Depense_model->GetTotal($date));
 
    $this->load->library('pdf');
    $html = $this->load->view('ADMIN/DEPENSES/printSingle',$data,true);
    $this->pdf->createPDF($html, 'mypdf', false);

 }
// FIN DE LA FONCTION
}