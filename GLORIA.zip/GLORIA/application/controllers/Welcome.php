<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	 public function __construct(){
		parent::__construct();
		$this->load->helper(array('form','url','file'));
		$this->load->library('form_validation');
		$this->load->model('Parametre_model');
		$this->load->model('Users_model');

       
	}

	public function index()
	{


		$data=array('title'=>'GLORIA | Login',
	                'year'=>$this->Parametre_model->showyear(),
	                'info'=>$this->session->message,);

		$this->load->view('LOGIN/head',$data);
		$this->load->view('LOGIN/body',$data);
		$this->load->view('LOGIN/footer');
	}


	public function usercheack(){



		$username=$this->input->post('username');
		$password=$this->input->post('password');
		$year=$this->input->post('y_id');


		$data=$this->Users_model->login($username,$password);
		$logo= '<img style="width:195px; height: 195px;" src="'.base_url("assets/side.png").'">';

		if(empty($username) OR empty($password) OR empty($year)){
		$this->session->set_flashdata('message','<div class="alert alert-danger col-lg-12 col-md-12 col-sm-12 col-xs-12" style="font-size: 15px;">
		    <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		     <span arial-hidden="true">&times;</span>
		     </button> <strong>Attention!</strong>
		      Remplir tout les champs !</div>');
        	  redirect('Welcome/index');
		}
		// si les resultats sont differents de faux
	   if($data == true){

	   	  $result = $this->Users_model->read_user_information($username,$password);
		  $cheack =$this->Users_model->read_user_informationSimpleUser($username,$password);
		  $cheackYear =$this->Users_model->cheackYear($year);


		//affichage des interfaces administrateur
	    if ($result != false) {
	    	$session_data = array(
                    'photo'=>$logo,
					'u_nom' =>$result[0]->u_nom,
					'u_avatar'=>$result[0]->u_avatar,
					'u_role' =>$result[0]->u_role,
					'y_year' =>$cheackYear[0]->y_year,
					'y_id' => $cheackYear[0]->y_id,
					'u_username'=>$result[0]->u_username,
					'query'=>$this->Users_model->CountAllUsers(),
					'title'=>'GLORIA | Dashboard',
					'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
					'footer1'=>'KATEMO KABOTO EZECHIEL. Katemoezeck@gmail.com.'
					);


	       $this->session->set_userdata('logged_in',$session_data);
	       $this->load->view('ADMIN/SIDEBAR/head',$session_data);
		   $this->load->view('ADMIN/SIDEBAR/header',$session_data);
		   $this->load->view('ADMIN/SIDEBAR/sidebar',$session_data);
		   $this->load->view('ADMIN/SIDEBAR/body',$session_data);
		   $this->load->view('ADMIN/SIDEBAR/footer',$session_data);
	   }if($cheack != false) {

	    	$session_data = array(
                    'photo'=>$logo,
					'u_nom' =>$cheack[0]->u_nom,
					'u_role' =>$cheack[0]->u_role,
					'u_avatar'=>$cheack[0]->u_avatar,
					'y_year' =>$cheackYear[0]->y_year,
					'y_id' => $cheackYear[0]->y_id,
					'u_username'=>$cheack[0]->u_username,
					'query'=>$this->Users_model->CountAllUsers(),
					'title'=>'GLORIA | Dashboard',
					'footer'=>'Copyright © 2021 PHARMACIE GLORIA v1.0.Tous les droits sont réservés.',
					'footer1'=>'KATEMO KABOTO EZECHIEL. Katemoezeck@gmail.com.'
					);

	       $this->session->set_userdata('logged_in',$session_data);
	       $this->load->view('ADMIN/SIDEBAR/head',$session_data);
		   $this->load->view('ADMIN/SIDEBAR/header',$session_data);
		   $this->load->view('ADMIN/SIDEBAR/sidebar',$session_data);
		   $this->load->view('ADMIN/SIDEBAR/body',$session_data);
		   $this->load->view('ADMIN/SIDEBAR/footer',$session_data);
	    }	
	  
      }else{
	  	   $this->session->set_flashdata('message','<div class="alert alert-danger col-lg-12 col-md-12 col-sm-12 col-xs-12" style="font-size: 15px;">
		                                <button  type="button" class="close" data-dismiss="alert" arial-label="close">
		                                      <span arial-hidden="true">&times;</span>
		                                      </button> <strong>Désolé !</strong>
		                                   Vous avez remplie des mauvais Identifiants Veuillez réessayer !</div>');
        	                                  redirect('Welcome/index');
	  }
	 
	}	
}
