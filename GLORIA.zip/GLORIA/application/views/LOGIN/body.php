<?php
if($this->session->userdata('u_username') != ''){
header("location: http://localhost/GLORIA/Welcome/index");
} 
?>
        <div class="auth-wrapper">
            <div class="container-fluid h-100">
                <div class="row flex-row h-100 bg-white">
                    <div class="col-xl-8 col-lg-6 col-md-5 p-0 d-md-block d-lg-block d-sm-none d-none">
                       
                             
                              <div class="lavalite-bg" style="background-image: url('<?php echo base_url()?>assets/pharma.png')">
                            
                            <div class="lavalite-overlay"></div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-7 my-auto p-0">
                        <div class="authentication-form mx-auto">
                            <div class="logo-centered" style="margin-left:5px; margin-top: -150px;">
                              <img src="<?php echo base_url()?>assets/pharma.png"  width="350px" height="300px" alt="">
                            </div>
                            <h5 style=" margin-top: -100px;">Se connecter dans LA PHARMACIE</h5>
                            <p>Heureux de vous revoir encore!</p>
                            <form action="<?php echo base_url()?>Welcome/usercheack" method="POST">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="username" id='username' placeholder="Nom d'Utilisateur">
                                    <i class="ik ik-user"></i>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control"  name='password' id='password' placeholder="Mot de passe">
                                    <i class="ik ik-lock"></i>
                                </div>
                                <div class="form-group">
                                    <label>Selectionnez l'année de Compte</label>
                                    <select class="form-control" id="y_id" name="y_id">
                                         <?php  foreach($year as $row) :?>
                                        <option  value="<?php echo$row->y_id?>"><?php echo$row->y_year?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="sign-btn text-center">
                                    <button class="btn btn-theme">Se connecter</button>
                                </div>
                            </form>

                            <?php echo $info;?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div> 