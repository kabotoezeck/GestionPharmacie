<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
                           
 <div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-inbox bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Fiche de Paiement Dette</h5>
                                            <span>Cette page permet de payer les dettes des produits</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>index.php/welcome/DASHBOARD"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">Pharmacie GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Page de Paiement</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                         <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                   <!--   <?php echo $info;?> -->
 
                        <div class="col-lg-6">   
                            <div class="card">
                                <div class="card-header d-block" style="background-color:firebrick; ">
                                  <h3  style="color:white">Page de Paiement</h3>
                                       
                             </div>

                     <!-- MODAL POUR MODIFIER  -->
                      <?php 
                     
                       foreach($sql as  $value) :?>
                           <?php endforeach; ?> 
                                    
                            <form class="forms-sample" action="<?php echo base_url();?>vente/paieBill/<?php echo $value->v_id;?>"  method="POST">

                                     <div class="modal-body">
                                       
                                      <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                            <label for="exampleInputUsername1">Nombre des Produits</label>
                                            <input type="text" class="form-control" name="Qte" value="<?php echo $nbr?>" readonly>
                                            </div>
                                          </div>
                                      </div>

                                        <div class="row">

                                          <div class="col-lg-6">
                                            <div class="form-group">
                                            <label for="exampleInputUsername1">N° de la Facture</label>
                                            <input type="text" class="form-control" name="Qte" value="<?php echo $value->v_code?>" readonly>
                                            </div>
                                          </div>

                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">Montant Total à Payer</label>
                                                <input type="text" class="form-control" name="unitaire" value="<?php echo $total?>" >
                                                </div>
                                            </div>  

                                      </div>

                                        <div class="row">

                                           <div class="col-lg-6">
                                            <div class="form-group">
                                            <label for="exampleInputUsername1">Solde</label>
                                            <input type="text" class="form-control" name="Qte" value="<?php echo $tot?>" readonly>
                                            </div>
                                          </div>

                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">Montant payer</label>
                                                <input type="text" class="form-control" name='paie' >
                                                <input type="hidden" name="code"  value="<?php echo $value->v_code?>">
                                            </div>
                                          </div>

                                        </div>

                                       
                                       
                                    </div>

                                    <div class="modal-footer">
                                        <a  href="<?php echo base_url()?>vente/search" type="button" class="btn btn-secondary" data-dismiss="modal">Retour</a>
                                        <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Payer</button>
                                    </div>
                                 </form>
                                </div>
                           </div>
                                </div>
                            </div>
                            <!-- FIN DU MODAL -->
                            