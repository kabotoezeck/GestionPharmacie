<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
<div class="main-content">
    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-search  bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Recherche avancé de la facture</h5>
                                            <span>Cette page permet de chercher le numero de la facture</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>DashboardAdmin/index"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Recherche Facture</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                         <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                        <?php echo $info; ?>
                        

              <div class="col-md-12">
                <form id="search">
                  <div class="row">
                    <div class="col-lg-6">
                     <div class="form-group">
                        <div class="input-group">
                          <input type="text" name="search_bill" id="search_bill" placeholder="Recherche du numero de la facture" class="form-control"/>
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-4">
                   <button type="submit" class="btn btn-success"> <i class="fas fa-search"></i>Recherche</button>
                  </div>
                </div>
              </form>
              </br>
            </br>

            <div id="result"></div>

        
    </div>
</div>
</div>
