<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
<div class="main-content">
    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-dollar-sign bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Gestion des Ventes</h5>
                                            <span>Page des Depenses permettant de voir toutes les Opérations des Ventes</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>DashboardAdmin/index"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Ventes</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                         <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                        <?php echo $info; ?>
                        
                          <div class="row">
                            <div class="col-md-8">
                                <div class="card">
                                  <div class="card-header bg-dark">
                                   <form  id="submitSearch">
                                 <div class="row"> 
                                 <div class="col-lg-8"> 
                                <div class="search_bar_header">
                                 <div class="typeahead__container">
                                     <div class="typeahead__field">
                                         <div class="typeahead__query " >
                                          <label style="color:white;">Recherche par Identifiant </label>
                                             <input type="search" name="add_autocomplete" class="form-control search_input " id="add-autocomplete" placeholder="Recherche des produits par Code" autocomplete="off" style="border-radius:10px; width:250px" />

                                            <!--  <input type="hidden" name="autocomplete" class="form-control" id="field-autocomplete" style="border-radius:10px;">
                                             <div class="search_btn">
                                             <i class="fa fa-search"></i>
                                             </div> -->
                                         </div>
                                     </div>
                                 </div>
                             </div>
                              </div>
                              <div class="col-lg-4">
                              <label style="color:white;">Recherche</label>
                              <button type="submit" class="btn btn-primary mr-2">Recherche</button>
                              </div>
                             </div>
                             
                                  </form>
                               </div>
                              <div class="card-body">
                                    
                               
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="card" style="min-height: 422px;">
                                  
                                    <div class="card-header bg-dark" style="color:white">Pannier de Vente</div>
                                    
                                    <div class="card-body">
                                     
                               
                                </div>
                             </div>
                           
                        </div>

                

      


           
    </div>
</div>


  <!-- deuxieme fonction -->


<!DOCTYPE html>
<html>
 <head>
  <title>Webslesson Tutorial | Autocomplete Textbox using Bootstrap Typehead with Ajax PHP</title>
  
 </head>
 <body>
  <br /><br />
  <div class="container" style="width:600px;">
   <h2 align="center">Autocomplete Textbox using Bootstrap Typeahead with Ajax PHP</h2>
   <br /><br />
   <label>Search Country</label>
   <input type="text" name="country" id="country" class="form-control input-lg" autocomplete="off" placeholder="Type Country Name" />
  </div>
 </body>
</html>

<script>
$(document).ready(function(){
 
 $('#country').typeahead({
  source: function(query, result)
  {
   $.ajax({
    url:"fetch.php",
    method:"POST",
    data:{query:query},
    dataType:"json",
    success:function(data)
    {
     result($.map(data, function(item){
      return item;
     }));
    }
   })
  }
 });
 
});
</script>