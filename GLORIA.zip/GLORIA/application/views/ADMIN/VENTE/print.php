<STYLE>
* {
    font-size: 9px;
    font-family: 'Times New Roman';
}

td,
th,
tr,
table {
    border-top: 1px solid black;
    border-collapse: collapse;
}

td.description,
th.description {
    width: 95px;
    max-width: 95px;
}

td.quantity
th.quantity {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}


td.prix,
th.prix {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

td.price,
th.price {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

.centered {
    text-align: center;
    align-content: center;
}

.ticket {
    width: 155px;
    max-width: 155px;
}

img {
    max-width: inherit;
    width: inherit;
}

@media print {
    .hidden-print,
    .hidden-print * {
        display: none !important;
    }
}
</STYLE>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>IMPRESSION</title>
    </head>
    <body>
         <?php 
         $nom="";
         $date="";
         $type="";
         foreach($data as $items){
                $nom=$items["client"];
                $date=$items["date"];
                $type=$items["type"];  
        }

     ?>

        <div class="ticket">
           
            <h1><b>ETS GLORIA</b></h1>
             <h3><b>PHARMACIE GLORIA</b></h3> 
             <p class='centered'>UVIRA-KALIMABENGE
             <br>TEL: +243 812125633
             <br> +243 994931850
             <br>RCCM:CD/UVIRA/RCCM/19-A-577
             <br>ID.Nat.441/04/3666</p>
             <hr>
             <p  class='centered'><strong>Facture N° : &nbsp;</strong>".<?php echo $code; ?>."
             <br><strong>Nom du client : &nbsp;</strong>".<?php echo $nom; ?>."
             <br><strong>Date d'impression : &nbsp;</strong>".<?php echo $date; ?>."
             <br><strong>Taux  : &nbsp;</strong>".<?php echo $taux ?>."
             <br><strong>".<?php echo $type ?>."</strong></p>
            
            <table>
                <thead>
                    <tr> 
                        <th class="description">Désignation.</th>
                        <th class="quantity">Qte</th>
                        <th class="prix">P.U</th>
                        <th class="price">P.T</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($data as $items):?>
                    <tr>
                        <td class="description"><?php echo $items["name"];?></td>
                        <td class="quantity"><?php echo $items["qty"];?></td>
                        <td class="prix"><?php echo $items["price"];?></td>
                        <td class="price"><?php echo $items["subtotal"];?></td>
                    </tr>
                <?php endforeach; ?>
              <tr>
             <td  colspan="2"><strong>Total en USD</strong></td>
             <td colspan="2"><strong><?php echo $total?></strong> </td>
            </tr>
     <tr>
    <td colspan="2" ><strong>Total en CDF</strong></td>
    <td  colspan="2" ><strong><?php echo $franc?></strong></td>
   </tr>
 </tbody>
</table>
     <p ><strong>Montant en lettres CDF : &nbsp;</strong><?php echo $nmbre;?></p>
    <p ><strong>CHERS CLIENTS S.V.P VEUILLEZ VERIFIER VOS PRODUITS A LA LIVRAISON PAS DE RECLAMATIONS APRES</strong></p>
        
    <p class="centered">Merci pour votre fidelité!
                <br>Ets Gloria</p>
</div>
 <div class="modal-footer">
   
   <button type="button" onclick="myFunction()"  class="hidden-print">Print</button>
  <a  href="<?php echo base_url()?>vente/index" type="button" class="hidden-print">Retour</a>

   
</div>
       
        <script src="script.js">

        function myFunction() {
            var y=document.getElementById("ticket");
              var rest=document.body.innerHTML;
              var print=document.getElementById("ticket").innerHTML;
              document.body.innerHTML=print;
              
              window.print();
       }
        </script>
    </body>
</html>