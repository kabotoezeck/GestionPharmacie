<!DOCTYPE html> 
<html> 
<head> 
    <meta content="width=device-width, initial-scale=1.0" name="viewport"> 
    <meta charset="utf-8"> 
    <title>Facture</title>
     
        <link rel="icon" href="<?php  echo base_url('assets/log.png')?>"  type="image/x-icon" />
        <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800" rel="stylesheet">
        <link rel="stylesheet" href="<?php  echo base_url()?>assets/plugins/select2/dist/css/select2.min.css"> 
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/bootstrap/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/fontawesome-free/css/all.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/icon-kit/dist/css/iconkit.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/ionicons/dist/css/ionicons.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/jvectormap/jquery-jvectormap.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/tempusdominus-bootstrap-4/build/css/tempusdominus-bootstrap-4.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/weather-icons/css/weather-icons.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/c3/c3.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/owl.carousel/dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/owl.carousel/dist/assets/owl.theme.default.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/dist/css/theme.min.css">
        <script src="<?php echo base_url()?>assets/src/js/vendor/modernizr-2.8.3.min.js"></script>
          <!-- SweetAlert2 -->
        <link rel="stylesheet" href="<?php echo base_url();?>/assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
        <link rel="stylesheet" href="<?php  echo base_url()?>assets/plugins/select2/dist/css/select2.min.css">
          <!-- Toastr -->
        <link rel="stylesheet" href="<?php echo base_url();?>/assets/plugins/toastr/toastr.min.css">
          <script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/src/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
        <script src="<?php echo base_url()?>assets/plugins/popper.js/dist/umd/popper.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/screenfull/dist/screenfull.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/jquery-jvectormap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/tests/assets/jquery-jvectormap-world-mill-en.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/moment/moment.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/select2/dist/js/select2.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/d3/dist/d3.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/c3/c3.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/tables.js"></script>
        <script src="<?php echo base_url()?>assets/js/widgets.js"></script>
        <script src="<?php echo base_url()?>assets/js/charts.js"></script>
        <script src="<?php echo base_url()?>assets/dist/js/theme.min.js"></script>
         <script src="<?php echo base_url()?>assets/plugins/select2/dist/js/select2.min.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <!-- SweetAlert2 -->
        <script src="<?php echo base_url();?>/assets/plugins/sweetalert2/sweetalert2.min.js"></script>

        <!-- fiche pour typehead -->
         <link href="<?php echo base_url();?>/assets/jquery-typeahead/dist/jquery.typeahead.min.css" rel="stylesheet" />
        <script src="<?php echo base_url();?>/assets/jquery-typeahead/dist/jquery.typeahead.min.js" type="text/javascript"></script>
        <!-- Toastr -->
        <script src="<?php echo base_url();?>/assets/plugins/toastr/toastr.min.js"></script>
        <script src="<?php echo base_url();?>/assets/sweetalert2.all.min.js"></script>
</head> 
<body> 
<h1 class="text-center bg-info"><font size="5">ETS GLORIA</h1>
<h3 class="text-center bg-info"><font size="5">PHARMACIE GLORIA</h3> 
<p>UVIRA-KALIMABENGE</p>
<b>Tél:</b> +243 812125633
+243 994931850
<b>RCCM:</b>CD/UVIRA/RCCM/19-A-577
<b>ID.Nat.</b>441/04/3666
 
<hr>

<p ><strong>Facture N° : &nbsp;</strong><?php echo $code;?></p>
<p ><strong>Nom du client : &nbsp;</strong><?php echo $client;?></p>
<p><strong>Date d'impression : &nbsp;</strong><?php echo $date;?></p>
<p><strong>Taux  : &nbsp;</strong><?php echo $taux;?></p>
<p><strong><?php echo $type;?></strong></p>
<br>
<br>
<table  class="table table-bordered" width="90%"> 
    <thead> 
        <tr > 
            <th style="width:160px;">Désign.</th>
            <th >Qte</th>
            <th >P.U </th> 
            <th>P.T</th>

        </tr> 
    </thead>
    
    <tbody>
      <?php foreach($cart as $items):?>
        <tr>
            <td><?php echo $items["name"];?></td>
            <td><?php echo $items["qty"];?></td> 
            <td><?php echo $items["price"];?></td> 
            <td  ><?php echo $items["subtotal"];?></td> 
        </tr>
         <?php endforeach; ?>
  
    <tr>
    <td  colspan="2"><strong>Total en USD</strong></td>
    <td colspan="2"><strong><?php echo $subtotal?></strong> </td>
    </tr>

    <tr>
    <td colspan="2" ><strong>Total en CDF</strong></td>
    <td  colspan="2" ><strong><?php echo $total?></strong></td>
   </tr>
<tbody>
       
</table>
<p ><strong>Montant en lettres CDF : &nbsp;</strong><?php echo $number;?></p>
<p ><strong>CHERS CLIENTS S.V.P VEUILLEZ VERIFIER VOS PRODUITS A LA LIVRAISON PAS DE RECLAMATIONS APRES</strong></p>
</font>
</body>

      

</html>