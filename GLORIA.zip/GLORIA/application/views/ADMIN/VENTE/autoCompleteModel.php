
<?php
class Vente_model extends CI_Model{

  public function getGlobalSearch($data)
{

    $this->db->select(array('stock.s_id', 'med.m_name', 'med.m_categorie'));
    $this->db->from(array('stock','med'));
    $this->db->where('med.m_id=stock.m_id');
    $this->db->like('med.m_name', $data);
    $country = $this->db->get()->result_array();
    return $country;
}


  }