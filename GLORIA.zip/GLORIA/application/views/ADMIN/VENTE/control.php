Public function add_to_cart(){

 $select=$this->input->post('s_id');
 $query="SELECT s_prixU FROM stock,pannier WHERE stock.s_id=pannier.s_id AND stock.s_id='$select'";
 $req=$this->db->query($query);
  foreach ($req->result() as $row) {
           $val=$row->s_prixU;

           $data = array(
			            'id' => $this->input->post('s_id'), 
			            'name' => $this->input->post('m_name'), 
			            'price' =>$val, 
			            'qty' => $this->input->post('qte'));
         
        $this->cart->insert($data);
		echo $this->show_cart(); 

    }
		
 }

 function show_cart(){ 
		$output = '';
		$no = 0;
		foreach ($this->cart->contents() as $Produits) {
			$no++;
			$output .='
				<tr>
					<td><small>'.$Produits['name'].'</small></td>
					<td><small>'.($Produits['price']).'</small></td>
					<td><small>'.$Produits['qty'].'</small></td>
					<td><small>'.($Produits['subtotal']).'</small></td>
					<td><small><button type="button" id="'.$Produits['rowid'].'" class="romove_cart btn btn-danger btn-sm">Annuler</button></small></td>
				</tr>
			';
		}
		$output .= '
			<tr>
				<th colspan="3">Total</th>
				<th colspan="2">'.'USD '.number_format($this->cart->total()).'</th>
			</tr>
		';
		echo json_encode($output) ;
	}
     function load_cart(){ 
		echo $this->show_cart();
	}

	function delete_cart(){ 
		$data = array(
			'rowid' => $this->input->post('row_id'), 
			'qty' => 0, 
		);
		$this->cart->update($data);
		echo $this->show_cart();
	}
