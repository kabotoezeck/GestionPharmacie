<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
<div class="main-content">
    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-dollar-sign bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Gestion des Ventes</h5>
                                            <span>Page des Depenses permettant de voir toutes les Opérations des Ventes</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>DashboardAdmin/index"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Ventes</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                         <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                        <?php echo $info; ?>
                        
                          <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                <div class="card-header bg-dark">
                                 <form  id="submitSearch">
                                 <div class="row"> 
                                 
                                    <div class="col-lg-4">
                                    <label style="color:white">Selectionnez les Produits</label>
                                      <div class="form-group">
                                        <select  id="produit" name="produit" class="form-control" style="width:250px;">
                                        <option value='0'>-- Sélectionnez le Produit --</option>
                                        </select>
                                        </div>
                                    </div>

                                     <div class="col-lg-2">
                                      <label style="color:white">Categorie</label>
                                     <div class="form-group">
                                        <input type="text" name="categorie" id="categorie" class="form-control" readonly="">  
                                         <input type="hidden" name="name" id="name" class="form-control">
                                         <input type="hidden" name="s_qte" id="s_qte" class="form-control">
                                         <input type="hidden" name="s_alert" id="s_alert" class="form-control">
                                         <input type="hidden" name="s_statut" id="s_statut" class="form-control">
                                         </div>
                                    </div>
                                     <?php if($u_role=='ADMIN'){
                                          echo'
                                           <div class="col-lg-2">
                                            <label style="color:white">Prix Unitaire</label>
                                            <div class="form-group">
                                           <input type="text" name="prix" id="prix" class="form-control" >
                                           </div>
                                           </div>';
                                          }else{
                                          echo'
                                           <div class="col-lg-2">
                                           <label style="color:white">Prix Unitaire</label>
                                            <div class="form-group">
                                           <input type="text" name="prix" id="prix" class="form-control" readonly="">
                                           </div>
                                           </div>';
                                        }?>

                                    
                                      <div class="col-lg-2">
                                      <label style="color:white">Qtes Achat</label>
                                       <div class="form-group">
                                        <input type="number" name="qte" id="qte" class="form-control" placeholder="Qte Achat">
                                        </div>
                                    </div>

                                     <?php if($u_role=='ADMIN'){
                                          echo'<div class="col-md-2">
                                               <label style="color:white">Type de Vente</label>
                                               <div class="form-group">
                                               <select class="form-control" id="type"  name="type">
                                                    <option hidden="">---Type---</option>
                                                    <option value="CASH">CASH</option>
                                                    <option value="DETTE">DETTE</option>
                                               </select>
                                              </div>
                                            </div>';
                                          }else{
                                          echo'<div class="col-md-2">
                                               <label style="color:white">Type de Vente</label>
                                               <div class="form-group">
                                               <select class="form-control" id="type"  name="type">
                                                    <option hidden="">---Type---</option>
                                                    <option value="CASH">CASH</option>
                                               </select>
                                              </div>
                                            </div>';
                                        }?>

                                    
                                </div>
                                <div class="row">
                                 <div class="col-lg-3">
                                      <label style="color:white">Nom du client</label>
                                       <div class="form-group">
                                        <input type="text" name="nameclient" id="nameclient" class="form-control" placeholder="Nom du client">
                                        </div>
                                    </div>
                                 <div class="col-lg-2">
                                 <label style="color:white"> Ajouter</label>
                                      <div class="form-group">
                                      <button type="submit" class="btn btn-primary mr-2 ik ik-plus-circle">Ajouter</button>
                                      </div>
                                    </div>
                                </div>
                              </form>
                              </div>
                                  <div class="card-body">
                                    <div id="cart_details">
                                      <h3 align="center">Cart is Empty</h3>
                                      </div>
                                    </div>
                                </div>
                            </div>
                            </div>

                            <div id="result"></div> 
                            
                         </div>
                      </div>

