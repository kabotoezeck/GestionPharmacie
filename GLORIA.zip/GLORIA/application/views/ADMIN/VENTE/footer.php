 <footer class="footer">
                    <div class="w-100 clearfix">
                        <span class="text-center text-sm-left d-md-inline-block"><?php echo $footer ?></span>
                        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Réaliser <i class="fa fa-heart text-danger"></i> par <a href="http://lavalite.org/" class="text-dark" target="_blank"><?php echo $footer1 ?></a></span>
                    </div>
                </footer>
                
            </div>
        </div>
        

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/src/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
        <script src="<?php echo base_url()?>assets/plugins/popper.js/dist/umd/popper.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/screenfull/dist/screenfull.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/jquery-jvectormap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/tests/assets/jquery-jvectormap-world-mill-en.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/moment/moment.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/select2/dist/js/select2.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/d3/dist/d3.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/c3/c3.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/tables.js"></script>
        <script src="<?php echo base_url()?>assets/js/widgets.js"></script>
        <script src="<?php echo base_url()?>assets/js/charts.js"></script>
        <script src="<?php echo base_url()?>assets/dist/js/theme.min.js"></script>
         <script src="<?php echo base_url()?>assets/plugins/select2/dist/js/select2.min.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <!-- SweetAlert2 -->
        <script src="<?php echo base_url();?>/assets/plugins/sweetalert2/sweetalert2.min.js"></script>

        <!-- fiche pour typehead -->
         <link href="<?php echo base_url();?>/assets/jquery-typeahead/dist/jquery.typeahead.min.css" rel="stylesheet" />
        <script src="<?php echo base_url();?>/assets/jquery-typeahead/dist/jquery.typeahead.min.js" type="text/javascript"></script>
        <!-- Toastr -->
        <script src="<?php echo base_url();?>/assets/plugins/toastr/toastr.min.js"></script>
        <script src="<?php echo base_url();?>/assets/sweetalert2.all.min.js"></script>
        <script src="<?php echo base_url();?>/assets/ticket/Impresora.js"></script>
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>

<script>
$(document).ready(function(){
// LA FONCTION PERMETTANT DE CHERCHER LE BATEAU PAR SELECTION
    $("#produit").select2({
         ajax: { 
           url:'<?php echo base_url();?>Vente/getProduits',
           type: "post",
           dataType: 'json',
           delay: 250,
           data: function (params) {
              return {
                searchTerm: params.term // search term
              };
           },
           processResults: function (response) {
              return {
                 results: response
              };
           },
           cache: true
         }
     });

     $('#produit').change(function(){
        var produit = $('#produit').val();
        $.ajax({
            method:'POST',
            url:"<?php echo site_url('Vente/searchCategorie')?>",
            dataType : "JSON",
            data:{produit:produit},
            success:function(data)
            {
                
              $('[name="categorie"]').val(data);
                
            }
        });
    });

      $('#produit').change(function(){
        var produit = $('#produit').val();
        $.ajax({
            method:'POST',
            url:"<?php echo site_url('Vente/searchName')?>",
            dataType : "JSON",
            data:{produit:produit},
            success:function(data)
            {
                
              $('[name="name"]').val(data);
                
            }
        });
    });

      $('#produit').change(function(){
        var produit = $('#produit').val();
        $.ajax({
            method:'POST',
            url:"<?php echo site_url('Vente/searchprix')?>",
            dataType : "JSON",
            data:{produit:produit},
            success:function(data)
            {
                
              $('[name="prix"]').val(data);
                
            }
        });
    });

     $('#produit').change(function(){
        var produit = $('#produit').val();
        $.ajax({
            method:'POST',
            url:"<?php echo site_url('Vente/searchAlert')?>",
            dataType : "JSON",
            data:{produit:produit},
            success:function(data)
            {
                
              $('[name="s_alert"]').val(data);
                
            }
        });
    });

    $('#produit').change(function(){
        var produit = $('#produit').val();
        $.ajax({
            method:'POST',
            url:"<?php echo site_url('Vente/searchQteE')?>",
            dataType : "JSON",
            data:{produit:produit},
            success:function(data)
            {
                
              $('[name="s_qte"]').val(data);
                
            }
        });
    });

     $('#produit').change(function(){
        var produit = $('#produit').val();
        $.ajax({
            method:'POST',
            url:"<?php echo site_url('Vente/searchstatut')?>",
            dataType : "JSON",
            data:{produit:produit},
            success:function(data)
            {
                
              $('[name="s_statut"]').val(data);
                
            }
        });
    });


 
    // FIN DE LA FONCTION
   });

</script>

<script type="text/javascript">
    // FONCTION QUI PERMET D'AFFICHER LES DONNES DANS LA TABLE
$(document).ready(function(){
$('#submitSearch').submit(function(e){
  e.preventDefault();
  var produit = $('#produit').val();
  var name = $('#name').val();
  var prix = $('#prix').val();
  var qte = $('#qte').val();
  var s_qte = $('#s_qte').val();
  var s_alert = $('#s_alert').val();
  var s_statut = $('#s_statut').val();
  var type = $('#type').val();
  var nameclient = $('#nameclient').val();
 

   if(qte != '' && qte > 0){
   $.ajax({
    url:"<?php echo base_url(); ?>Vente/add_to_cart",
    method:"POST",
    data:{produit:produit, name:name, prix:prix, qte:qte,s_qte:s_qte,s_alert:s_alert,s_statut:s_statut,type:type,nameclient:nameclient},
    success:function(data){
   
        $('#cart_details').html(data);
        $('#' + produit).val('');
        
    }
   });
  }
  else
  {
    Swal.fire('Enregistrement Echoué!',
              'Veuillez entrer la Quantité Achat SVP!',
              'error')
  }
 });

  $('#cart_details').load("<?php echo base_url(); ?>Vente/load");
    $(document).on('click', '.remove_inventory', function(){
    var row_id = $(this).attr("id");
      if(confirm("Voulez-vous supprimer le Produit dans le Pannier?")){
          $.ajax({
            url:"<?php echo base_url(); ?>Vente/remove",
            method:"POST",
            data:{row_id:row_id},
            success:function(data){
            //alert("Product removed from Cart");
            Swal.fire('le Produit est supprimé Dans le Pannier avec succès!',
                      '<a href>Merci !</a>',
                      'success')
            $('#cart_details').html(data);
            }
            });
            }else{
            return false;
            }
            });

            $(document).on('click', '#clear_cart', function(){
            if(confirm("Voulez-vous supprimer le Produit dans le Pannier?")){
            $.ajax({
            url:"<?php echo base_url(); ?>Vente/clear",
            success:function(data){
            Swal.fire('le Produit est supprimé Dans le Pannier avec succès!',
                      '<a href>Merci !</a>',
                      'success')
            //alert("Your cart has been clear...");
            $('#cart_details').html(data);
            }
            });
            }
            else{
            return false;
            }
            });

            $(document).on('click', '#buy', function(){
            if(confirm("veuillez confirmer cette Action SVP!")){
           
            $.ajax({
            url:"<?php echo base_url(); ?>Vente/printAndBuy ",
            method:"POST",
            success:function(data){


              if(data.message){
                Swal.fire("Enregistrement Echoué!",
                          "la Quantité d'Achat est superieur au stock SVP!",
                          "error")
              }else{ 

              //window.location.href ="<?php echo base_url(); ?>Vente/printPDF "+ data
 
              $('#result').html(data);
              var y=document.getElementById("result");
              var rest=document.body.innerHTML;
              var print=document.getElementById("result").innerHTML;
              document.body.innerHTML=print;
              
              window.print();
             // document.body.innerHTML=rest;
              //return window.location.reload();
               }
             }

            });
            }
            else{
            return false;
            }
            });
            
    $('#month').submit(function(e){
    e.preventDefault();
    var fd = new FormData(document.getElementById("month"));
    $.ajax({
          url:'<?php echo base_url();?>Vente/rapportMonth',
          type:"post",
          data:new FormData(this), //this is formData
          processData:false,
          contentType:false,
          cache:false,
          async:false,
          success: function(data){ 
           $('#result').html(data);
          }
      });
   });

     $('#reportDay').submit(function(e){

    e.preventDefault();
    var fd = new FormData(document.getElementById("reportDay"));
    $.ajax({
          url:'<?php echo base_url();?>Vente/reportDayALL',
          type:"post",
          data:new FormData(this), //this is formData
          processData:false,
          contentType:false,
          cache:false,
          async:false,
          success: function(data){ 
           $('#resultday').html(data);
          }
      });
   });


   $('#search').submit(function(e){
    e.preventDefault();
    var fd = new FormData(document.getElementById("search"));
    $.ajax({
          url:'<?php echo base_url();?>Vente/searchBill',
          type:"post",
          data:new FormData(this), //this is formData
          processData:false,
          contentType:false,
          cache:false,
          async:false,
          success: function(data){ 
           $('#result').html(data);
          }
      });
   });


    $(document).on('click', '#buyER', function(){
            if(confirm("veuillez confirmer cette Action SVP!")){
           
            window.location.href = '<?php echo base_url();?>Vente/printPDF';

            }
            else{
            return false;
            }
            });
 
   // FIN DE LA FONCTION
   });
</script>
</body>
</html>
