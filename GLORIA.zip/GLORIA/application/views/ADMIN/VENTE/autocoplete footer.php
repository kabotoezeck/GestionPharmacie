 <footer class="footer">
                    <div class="w-100 clearfix">
                        <span class="text-center text-sm-left d-md-inline-block"><?php echo $footer ?></span>
                        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Réaliser <i class="fa fa-heart text-danger"></i> par <a href="http://lavalite.org/" class="text-dark" target="_blank"><?php echo $footer1 ?></a></span>
                    </div>
                </footer>
                
            </div>
        </div>
        

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/src/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
        <script src="<?php echo base_url()?>assets/plugins/popper.js/dist/umd/popper.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/screenfull/dist/screenfull.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/jquery-jvectormap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/tests/assets/jquery-jvectormap-world-mill-en.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/moment/moment.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/select2/dist/js/select2.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/d3/dist/d3.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/c3/c3.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/tables.js"></script>
        <script src="<?php echo base_url()?>assets/js/widgets.js"></script>
        <script src="<?php echo base_url()?>assets/js/charts.js"></script>
        <script src="<?php echo base_url()?>assets/dist/js/theme.min.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <!-- SweetAlert2 -->
        <script src="<?php echo base_url();?>/assets/plugins/sweetalert2/sweetalert2.min.js"></script>

        <!-- fiche pour typehead -->
         <link href="<?php echo base_url();?>/assets/jquery-typeahead/dist/jquery.typeahead.min.css" rel="stylesheet" />
        <script src="<?php echo base_url();?>/assets/jquery-typeahead/dist/jquery.typeahead.min.js" type="text/javascript"></script>
        <!-- Toastr -->
        <script src="<?php echo base_url();?>/assets/plugins/toastr/toastr.min.js"></script>
        <script src="<?php echo base_url();?>/assets/sweetalert2.all.min.js"></script>
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
i
<script>
$(document).ready(function () {
    var baseurl = "<?php echo base_url() ?>";
    if (jQuery('input#add-autocomplete').length > 0) {

        $.typeahead({
            input: '#add-autocomplete',
            minLength: 1,
            order: "asc",
            maxItem: 12,
            dynamic: true,
            filter: false,
            delay: 500,
            template: function (query, item) {

                return '<span>'+item.package_id+'</span> <span>'+item.package_name+'</span> <span>'+item.package_categorie+'</span>'

            },
            emptyTemplate: "desolé pas de resultat pour {{query}}",
            source: {
                packages: {
                    display: "package_id",
                    ajax: function (query) {
                        return {
                            type: "POST",
                            url: baseurl + "vente/fetch",
                            path: "data.packages",
                            data: {
                                query: "{{query}}"
                            },
                            callback: {
                                done: function (data) {
                                    return data;
                                }
                            }
                        }
                    }
                },
            },
            callback: {
                onClick: function (node, a, item, event) {
                    // onclick do something
                }
            },
            debug: true
        });
    }
});


    $('#submitSearch').change(function(e){   
 //$('#autocomplete').change(function(){
        var add_autocomplete = $('#add_autocomplete').val();
        alert(autocomplete)
                  e.preventDefault(); 
                  $.ajax({
                     url:'<?php echo base_url();?>Users/statut',
                     type:"post",
                     data:new FormData(this), //this is formData
                     processData:false,
                     contentType:false,
                     cache:false,
                     async:false,
                      success: function(data){
                         
                      Swal.fire(
                            'Vous avez changé le statut avec succès!',
                            '<a href>Merci !</a>',
                            'success'
                      )
                      $('[name="u_id_actif"]').val("");
                      $('[name="u_statut_actif"]').val("");
                      $('#Modal_statut').modal('hide');
                      show_users(); 
                      
                      
                   }
             });
          });


    $(document).ready(function(){
        $('#autocomplete').change(function(){
        var autocomplete = $('#autocomplete').val();
        alert(autocomplete)
        $.ajax({
            method:'POST',
            url:"<?php echo site_url('Medicaments/Categorie')?>",
            dataType : "JSON",
            data:{med:med},
            success:function(data)
            {
                
              $('[name="Categorie"]').val(data);
                
            }
        });
    });
 });
</script>


    </body>
</html>
