<script type="text/javascript">
  $('#cart_details').load("<?php echo base_url(); ?>Vente/load");
    $(document).on('click', '.remove_inventory', function(){
    var row_id = $(this).attr("id");
      if(confirm("Voulez-vous supprimer le Produit dans le Pannier?")){
          $.ajax({
            url:"<?php echo base_url(); ?>Vente/remove",
            method:"POST",
            data:{row_id:row_id},
            success:function(data){
            //alert("Product removed from Cart");
            Swal.fire('le Produit est supprimé Dans le Pannier avec succès!',
                      '<a href>Merci !</a>',
                      'success')
            $('#cart_details').html(data);
            }
            });
            }else{
            return false;
            }
            });

            $(document).on('click', '#clear_cart', function(){
            if(confirm("Voulez-vous supprimer le Produit dans le Pannier?")){
            $.ajax({
            url:"<?php echo base_url(); ?>Vente/clear",
            success:function(data){
            Swal.fire('le Produit est supprimé Dans le Pannier avec succès!',
                      '<a href>Merci !</a>',
                      'success')
            //alert("Your cart has been clear...");
            $('#cart_details').html(data);
            }
            });
            }
            else{
            return false;
            }
            });

            $(document).on('click', '#buy', function(){
            if(confirm("veuillez confirmer cette Action SVP!")){
            $.ajax({
            url:"<?php echo base_url(); ?>Vente/printPDF ",
            dataType : "JSON",
            success:function(data){

              if(data.message){
                Swal.fire("Enregistrement Echoué!",
                          "la Quantité d'Achat est superieur au stock SVP!",
                          "error")
              }else{ 
  
              // $('#result').html(data);
              // var y=document.getElementById("result");
              // var rest=document.body.innerHTML;
              // var print=document.getElementById("result").innerHTML;
              // document.body.innerHTML=print;
              // window.print();
              // document.body.innerHTML=rest;
              //return window.location.reload();
               }
             }

            });
            }
            else{
            return false;
            }
            });
            </script>