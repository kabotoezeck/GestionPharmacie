public function fetch(){
	$json = array();
    $status = true;
    $query = $this->input->post('query');

    $result = $this->Vente_model->getGlobalSearch($query);

    if (!empty($result)) {
        foreach ($result as $key => $element) {
            $json[] = array(
                'package_id' => $element['s_id'],
                'package_name' => $element['m_name'],
                'package_categorie' => $element['m_categorie'],
            );
        }
    } else {
        $status = false;
    }

    $this->output->set_header('Content-Type: application/json');
    echo json_encode(array(
        "status" => $status,
        "error"  => null,
        "data"   => array(
        "packages" => $json,
        )
    ));
	}