 <footer class="footer">
                    <div class="w-100 clearfix">
                        <span class="text-center text-sm-left d-md-inline-block"><?php echo $footer ?></span>
                        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Réaliser <i class="fa fa-heart text-danger"></i> par <a href="http://lavalite.org/" class="text-dark" target="_blank"><?php echo $footer1 ?></a></span>
                    </div>
                </footer>
                
            </div>
        </div>
        

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/src/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
        <script src="<?php echo base_url()?>assets/plugins/popper.js/dist/umd/popper.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/screenfull/dist/screenfull.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/jquery-jvectormap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/tests/assets/jquery-jvectormap-world-mill-en.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/moment/moment.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/select2/dist/js/select2.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/d3/dist/d3.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/c3/c3.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/tables.js"></script>
        <script src="<?php echo base_url()?>assets/js/widgets.js"></script>
        <script src="<?php echo base_url()?>assets/js/charts.js"></script>
        <script src="<?php echo base_url()?>assets/dist/js/theme.min.js"></script>
         <script src="<?php echo base_url()?>assets/plugins/select2/dist/js/select2.min.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <!-- SweetAlert2 -->
        <script src="<?php echo base_url();?>/assets/plugins/sweetalert2/sweetalert2.min.js"></script>

        <!-- fiche pour typehead -->
         <link href="<?php echo base_url();?>/assets/jquery-typeahead/dist/jquery.typeahead.min.css" rel="stylesheet" />
        <script src="<?php echo base_url();?>/assets/jquery-typeahead/dist/jquery.typeahead.min.js" type="text/javascript"></script>
        <!-- Toastr -->
        <script src="<?php echo base_url();?>/assets/plugins/toastr/toastr.min.js"></script>
        <script src="<?php echo base_url();?>/assets/sweetalert2.all.min.js"></script>
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>

<script>
$(document).ready(function(){
// LA FONCTION PERMETTANT DE CHERCHER LE BATEAU PAR SELECTION
    $("#produit").select2({
         ajax: { 
           url:'<?php echo base_url();?>Vente/getProduits',
           type: "post",
           dataType: 'json',
           delay: 250,
           data: function (params) {
              return {
                searchTerm: params.term // search term
              };
           },
           processResults: function (response) {
              return {
                 results: response
              };
           },
           cache: true
         }
     });

     $('#produit').change(function(){
        var produit = $('#produit').val();
        $.ajax({
            method:'POST',
            url:"<?php echo site_url('Vente/searchCategorie')?>",
            dataType : "JSON",
            data:{produit:produit},
            success:function(data)
            {
                
              $('[name="categorie"]').val(data);
                
            }
        });
    });


 
    // FIN DE LA FONCTION
   });

</script>

<script type="text/javascript">
    // FONCTION QUI PERMET D'AFFICHER LES DONNES DANS LA TABLE
$(document).ready(function(){
  show_pannier();
  $('#table').DataTable();
        //FONCTION QUI PERMET D'AFFICHER LES DONNEES DANS LA TABLE
    function show_pannier(){

        $.ajax({
            type  : 'ajax',
            url   : '<?php echo site_url('Vente/getData')?>',
            async : false,
            dataType : 'json',
            success : function(data){
                var html = '';
                var i;
                for(i=0; i<data.length; i++){    
                    var a=1+i;
                    html += '<tr>'+'<td>'+a+'</td>'+
                            '<td>'+data[i].m_name+'</td>'+
                            '<td>'+data[i].m_categorie+'</td>'+
                            '<td>'+data[i].s_prixU+'</td>'+
                            '<td><input type="text" name="qte" id="qte" class="form-control"></td>'+
                            '<td><input type="text" name="red" id="red" class="form-control"></td>'+
                            '<td style="text-align:center;">'+

              '<a href="javascript:void(0);" class="ik ik-refresh-ccw f-16 text-dark  item_edit" data-pn_id="'+data[i]. pn_id+'"></a>'+' '+

            '&nbsp;<a href="javascript:void(0);" class="ik ik-plus-circle f-16 text-success  btn-xs item_delete" data-s_id="'+data[i].s_id+'" data-s_prixT="'+data[i].s_prixU+'" data-m_name="'+data[i].m_name+'" ></a>'+
                                '</td>'+
                            '</tr>';
                }
                $('#show').html(html);
                
            }
        }); 
      }

      // <!-- AJOUT DANS LE TABLEAU-->
  $('#submitSearch').submit(function(e){
      e.preventDefault();
      var fd = new FormData(document.getElementById("submitSearch"));
        
          $.ajax({
                    url:'<?php echo base_url();?>Vente/Add',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                    success: function(data){
                     show_pannier();   
                   }
             });
           });

    //MODAL POUR SUPPRIMER 
         $('#show').on('click','.item_edit',function(){
            var pn_id = $(this).data('pn_id');
            var s_prixU = $(this).data('s_prixU');
             $.ajax({
            method:'POST',
            url:"<?php echo site_url('Vente/deletePannier')?>",
            dataType : "JSON",
            data:{pn_id:pn_id},
            success:function(data)
            {
             show_pannier(); 
            }
        });  
        });




         //MODAL POUR METTRE DANS LE PANNIER 
         $('#show').on('click','.item_delete',function(){

            var s_id = $(this).data('s_id');
            var m_name = $(this).data('m_name');
            var s_prixU = $(this).data('s_prixU');
            var qte = $('#qte').val();
            //var s_id      = $('#' + s_id).val();

             $.ajax({
             method:'POST',
             url : "<?php echo site_url('Vente/add_to_cart');?>",
             dataType : "JSON",
             data : {s_id: s_id, m_name: m_name, s_prixU: s_prixU, qte: qte},
            success:function(data)
            {
             $('#detail_cart').html(data);
            }
        });  
        });

        $('#detail_cart').load("<?php echo site_url('Vente/load_cart');?>");

        $(document).on('click','.romove_cart',function(){
        var row_id=$(this).attr("id"); 
        $.ajax({
        url : "<?php echo site_url('Vente/delete_cart');?>",
        method : "POST",
         dataType : "JSON",
        data : {row_id : row_id},
        success :function(data){
          $('#detail_cart').html(data);
        }
      });
    });

   // FIN DE LA FONCTION
   });
</script>
</body>
</html>
