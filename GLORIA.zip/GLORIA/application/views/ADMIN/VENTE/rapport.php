<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
                           
 <div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-pie-chart  bg-blue"></i>
                                    
                                        <div class="d-inline">
                                            <h5>VOIR LE RAPPORT HEBDOMADAIRE, MENSUEL , ANNUEL PAR DATE</h5>
                                            <span>Cette page permet de filtrer le Rapport de Vente par Date</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>index.php/welcome/DASHBOARD"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Rapport de Vente</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>

                        <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                        <?php echo $info; ?>
                     
                  
                            <span> 
                                <form class="forms-sample" id="month">
                                    <div class="row">
                                      <div class="col-md-3">
                                      <label>Date du debut</label>
                                            <div class="form-group">
                                            <input type="date" name="dateone" id="dateone"  class="form-control"/>
                                            </div>
                                        </div>

                                         <div class="col-md-3">
                                          <label>Date de la Fin</label>
                                            <div class="form-group">
                                            <input type="date" name="datetwo" id="datetwo"  class="form-control"/>
                                            </div>
                                        </div>

                                     <div class="col-md-2">
                                      <label>Type de Vente</label>
                                            <div class="form-group">
                                            <select class="form-control" id="categorie"  name="categorie">
                                                    <option hidden="">---Type---</option>
                                                    <option value="DETTE">DETTE</option>
                                                    <option value="CASH">CASH</option>
                                                    <option value="TOUS">TOUS</option>
                                                  </select>
                                              </div>
                                        </div>
                                    <div class="col-lg-3">
                                     <label>Filtrage</label>
                                     <br>
                                       <button type="submit" class="btn btn-success" > <i class="fas fa-search"></i>Filtrer</button>
                                    </div>

                                  
                                   </div>
                              </form>

                             <!-- DEUXIEME CAS POUR L'IMPRESSION -->
                             <form class="forms-sample" style="float:right;margin-top:-50px;" method="POST" action="<?php echo base_url()?>index.php/Rapport/printDate">
                                <div class="row">
                                 <div class="col-lg-2">
                                    <div class="form-group">
                                      <input type="hidden" class="form-control" name="mois">
                                   </div>
                                </div>
                                <div class="col-lg-3">
                                <button type="submit"  class="btn btn-info"><i class="ik ik-printer"></i>Imprimer</button>
                              </div>
                                </div>
                              </form>
                              <br>

                              <span id="result"></span>
                           
                    </div>
                </div>
                
       
                      