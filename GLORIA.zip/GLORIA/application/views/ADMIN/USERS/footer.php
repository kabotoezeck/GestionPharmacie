 <footer class="footer">
                    <div class="w-100 clearfix">
                        <span class="text-center text-sm-left d-md-inline-block"><?php echo $footer ?></span>
                        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Réaliser <i class="fa fa-heart text-danger"></i> par <a href="http://lavalite.org/" class="text-dark" target="_blank"><?php echo $footer1 ?></a></span>
                    </div>
                </footer>
                
            </div>
        </div>
        

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/src/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
        <script src="<?php echo base_url()?>assets/plugins/popper.js/dist/umd/popper.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/screenfull/dist/screenfull.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/jquery-jvectormap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/tests/assets/jquery-jvectormap-world-mill-en.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/moment/moment.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/d3/dist/d3.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/c3/c3.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/tables.js"></script>
        <script src="<?php echo base_url()?>assets/js/widgets.js"></script>
        <script src="<?php echo base_url()?>assets/js/charts.js"></script>
        <script src="<?php echo base_url()?>assets/dist/js/theme.min.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <!-- SweetAlert2 -->
        <script src="<?php echo base_url();?>/assets/plugins/sweetalert2/sweetalert2.min.js"></script>
        <!-- Toastr -->
        <script src="<?php echo base_url();?>/assets/plugins/toastr/toastr.min.js"></script>
        <script src="<?php echo base_url();?>/assets/sweetalert2.all.min.js"></script>
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>




<script type="text/javascript">
 $(document).ready(function(){
   show_users();
  $('#table').DataTable();
        //FONCTION QUI PERMET D'AFFICHER LES DONNEES DANS LA TABLE
    function show_users(){

        $.ajax({
            type  : 'ajax',
            url   : '<?php echo site_url('Users/showUser')?>',
            async : false,
            dataType : 'json',
            success : function(data){
                var html = '';
                var i;
                for(i=0; i<data.length; i++){
                    var a=1+i;
                    html += '<tr>'+'<td>'+a+'</td>'+
                           '<td>'+'<img class="img-circle item_picture" style="width:40px; height: 40px;" src="'+data[i].u_avatar+'"/>'+'</td>'+
                            '<td>'+data[i].u_nom+'</td>'+
                            '<td>'+data[i].u_username+'</td>'+
                            '<td>'+data[i].u_role+'</td>'+
                            '<td>'+data[i].u_glo+'</td>'+
                            '<td>'+data[i].u_sexe+'</td>'+
                            '<td>'+data[i].u_statut+'</td>'+
                          '<td style="text-align:right;">'+

              '<a href="javascript:void(0);" class="ik ik-edit f-16 text-info  item_edit" data-u_id="'+data[i].u_id+'" data-u_nom="'+data[i].u_nom+'"  data-u_username="'+data[i].u_username+ '" data-u_glo="'+data[i].u_glo+'"data-u_role="'+data[i].u_role+'"data-u_sexe="'+data[i].u_sexe+'"></a>'+' '+

               '<a href="javascript:void(0);" class=" ik ik-refresh-ccw f-16 text-dark  item_Active" data-u_id="'+data[i].u_id+'" data-u_statut="'+data[i].u_statut+'"></a>'+


                '&nbsp;<a href="javascript:void(0);" class=" ik ik-trash-2 f-16 text-red  btn-xs item_delete" data-u_id="'+data[i].u_id+'"></a>'+
                                '</td>'+
                            '</tr>';
                }
                $('#show').html(html);
                
            }
        });

       
    // FIN DE LA FONCTION
      }

// <!-- AJOUT DES UTILISATEURS-->
  $('#submit').submit(function(e){
       e.preventDefault();
      var fd = new FormData(document.getElementById("submit"));
        
          $.ajax({
                    url:'<?php echo base_url();?>Users/AddUsers',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                      success: function(data){
                      if(data.error){
                        if(data.u_name_error !=''){
                          $('#u_name_error').html(data.u_name_error);
                        }else{
                          $('#u_name_error').html('');
                        }
                       
                        if(data.u_username_error !=''){
                          $('#u_username_error').html(data.u_username_error);
                        }else{
                          $('#u_username_error').html('');
                        }

                        if(data.u_password_error !=''){
                          $('#u_password_error').html(data.u_password_error);
                        }else{
                          $('#u_password_error').html('');
                        }

                        if(data.u_role_error !=''){
                          $('#u_role_error').html(data.u_role_error);
                        }else{
                          $('#u_role_error').html('');
                        }

                        if(data.u_genre_error !=''){
                          $('#u_genre_error').html(data.u_genre_error);
                        }else{
                          $('#u_genre_error').html('');
                        }
                      
                         Swal.fire(
                          'Enregistrement Echoué!',
                          'Vérifie Bien tes données!',
                          'error'
                        )

                      }

                      if(data.exit){
                         Swal.fire(
                          'Enregistrement Echoué!',
                          'Attention! le nom Utilisateur existe déjà',
                          'error')
                      }

                      if(data.success){
                         
                          Swal.fire(
                            'Enregistrement reussi!',
                            '<a href>Merci !</a>',
                            'success')

                          $('#u_username_error').html('');
                          $('#u_password_error').html('');
                          $('#u_role_error').html('');
                          $('#u_genre_error').html('');
                          $('#submit')[0].reset();
                          $('#demoModal').modal('hide');
                          show_users(); 
                        }   
                      }
                   });
                });

        //MODAL POUR EDITER 

         $('#show').on('click','.item_edit',function(){
            var u_id = $(this).data('u_id');
            var u_nom = $(this).data('u_nom');
            var u_sexe        = $(this).data('u_sexe');
            var u_username = $(this).data('u_username');
            var u_glo = $(this).data('u_glo');
            var u_role        = $(this).data('u_role');
            
            $('#EditModal').modal('show');
            $('[name="u_id_edit"]').val(u_id);
            $('[name="u_name_edit"]').val(u_nom);
            $('[name="u_username_edit"]').val(u_username);
            $('[name="u_role_edit"]').val(u_role);
            $('[name="u_password_edit"]').val(u_glo);
            $('[name="u_genre_edit"]').val(u_sexe);
        });


   // MODAL POUR  LE STATUT
    $('#show').on('click','.item_Active',function(){
            var u_id = $(this).data('u_id');
            var u_statut = $(this).data('u_statut');
    
            $('#Modal_statut').modal('show');
            $('[name="u_id_actif"]').val(u_id);
            $('[name="u_statut_actif"]').val(u_statut);
            
        });

  // MODAL POUR CHANGER LE STATUT
    $('#activebouton').submit(function(e){   

                  e.preventDefault(); 
                  $.ajax({
                     url:'<?php echo base_url();?>Users/statut',
                     type:"post",
                     data:new FormData(this), //this is formData
                     processData:false,
                     contentType:false,
                     cache:false,
                     async:false,
                      success: function(data){
                         
                      Swal.fire(
                            'Vous avez changé le statut avec succès!',
                            '<a href>Merci !</a>',
                            'success'
                      )
                      $('[name="u_id_actif"]').val("");
                      $('[name="u_statut_actif"]').val("");
                      $('#Modal_statut').modal('hide');
                      show_users(); 
                      
                      
                   }
             });
          });

     // MODAL POUR SUPPRIMER L'UTILISATEUR 

        $('#show').on('click','.item_delete',function(){

         var u_id = $(this).data('u_id');
         $('#Modal_delete').modal('show');
         show_users();
         $('[name="u_id_delete"]').val(u_id);
        
    });

    //BOUTON POUR SUPPRIMER LES UTILISATEURS

     $('#delete').submit(function(e){ 
         
                  e.preventDefault(); 
                  $.ajax({
                      url:'<?php echo base_url();?>Users/delete',
                     type:"post",
                     data:new FormData(this), //this is formData
                     processData:false,
                     contentType:false,
                     cache:false,
                     async:false,
                      success: function(data){
                          Swal.fire(
                            'Suppression reussi avec succès!',
                            '<a href>Merci !</a>',
                            'success'
                      )
                    $('[name="u_id_delete"]').val("");
                    $('#Modal_delete').modal('hide');
                      show_users();
                   }
             });
            return false;
});

// FIN DE LA FONCTION
   });
  </script>

    </body>
</html>
