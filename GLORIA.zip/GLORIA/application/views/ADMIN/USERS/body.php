
<div class="main-content">
    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-users bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Gestion des utilisateurs</h5>
                                            <span>Cette page permet de gérer les informations relatives aux utilisateurs du logiciel</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>DashboardAdmin/index"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">Pharmacie Gloria</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Gestion des Utilisateurs</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                          <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                       <?php echo $info; ?> 
                        <div class="card col-lg-12">
                            <div class="card-header bg-dark">
                                <h3 style="color:white">Listing des Utilisateurs</h3>
                                 <span>&nbsp;&nbsp;
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#demoModal" style="margin-left:0%;"> <i class="fas fa-user-plus"></i>Nouvel utilisateur</button></span>&nbsp;&nbsp;&nbsp;
                                
                            </div>

                            </br>
                            <div style="height:500px;overflow:auto;">
                                <table id="table" class="table">
                                    <thead>
                                        <tr>
                                           
                                            <th>#</th>
                                            <th>Avatar</th>
                                            <th>Nom</th>
                                            <th>Nom d'Utilisateur</th>
                                            <th>Rôle</th>
                                            <th>Mot de passe</th>
                                            <th>Genre</th>
                                             <th>Statut</th>
                                            <th style="text-align:center;">Actions</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody id="show">
                                       
                                    </tbody>
                                </table>
                            </div>
                    </div>



                    <!-- MODAL POUR AJOUT   -->

                         <div class="modal fade" id="demoModal" tabindex="-1" role="dialog" aria-labelledby="demoModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="demoModalLabel">Ajout d'un Utilisateur</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                     <form class="forms-sample" id="submit">
                                     <div class="modal-body">
                                       
                                        <div class="row">
                                            <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1">Nom</label>
                                                <input type="text" class="form-control" id="u_name" name="u_name" placeholder="Nom">
                                            </div>
                                              <span id="u_name_error" class="text-danger"></span>
                                            </div>
                                             <div class="col-lg-6">
                                               <div class="form-group">
                                                <label for="exampleInputUsername1">Nom d'Utilisateur</label>
                                                <input type="text" class="form-control" id="u_username" name="u_username" placeholder="Nom d'Utilisteur">
                                            </div>
                                              <span id="u_username_error" class="text-danger"></span>
                                            </div>
                                        </div>

                                         <div class="row">
                                           <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleSelectGender">Rôle</label>
                                                        <select class="form-control" id="u_role"  name="u_role">
                                                           <option hidden="">Sélectionnez le rôle</option>
                                                            <option value="ADMIN">ADMIN</option>
                                                            <option value="AGENT">AGENT</option>
                                                            
                                                           
                                                        </select>
                                                    </div>
                                                      <span id="u_role_error" class="text-danger"></span>
                                                </div>

                                             <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Mot de passe</label>
                                                <input type="Password" class="form-control" id="u_password" name="u_password" placeholder="Mot de passe">
                                            </div>
                                              <span id="u_password_error" class="text-danger"></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                                 <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="exampleSelectGender">Genre</label>
                                                        <select class="form-control" id="u_genre"  name="u_genre">
                                                           <option hidden="">Sélectionnez le Genre</option>
                                                            <option value="Homme">Homme</option>
                                                            <option value="Femme">Femme</option>
                                                          
                                                        </select>
                                                    </div>
                                                      <span id="u_genre_error" class="text-danger"></span>
                                                </div>
                                        </div>    
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                         <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Enregistrer</button>
                                    </div>
                                 </form>
                                </div>
                            </div>
                        </div>
                 <!-- FIN DU MODAL   -->


                    <!-- MODAL POUR EDIT   -->

                         <div class="modal fade" id="EditModal" tabindex="-1" role="dialog" aria-labelledby="demoModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="demoModalLabel">Modifier un Utilisateur</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                     <form class="forms-sample" action="<?php echo base_url()?>Users/modifier" method="POST">
                                     <div class="modal-body">
                                       
                                        <div class="row">
                                            <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1">Nom</label>
                                                <input type="text" class="form-control" id="u_name_edit" name="u_name_edit" placeholder="Nom">
                                                <input type="hidden" class="form-control" id="u_id_edit" name="u_id_edit">
                                            </div>
                                              <span id="u_name_edit_error" class="text-danger"></span>
                                            </div>
                                             <div class="col-lg-6">
                                               <div class="form-group">
                                                <label for="exampleInputUsername1">Nom d'Utilisteur</label>
                                                <input type="text" class="form-control" id="u_username_edit" name="u_username_edit" placeholder="Nom d'Utilisteur">
                                            </div>
                                              <span id="u_username_edit_error" class="text-danger"></span>
                                            </div>
                                        </div>

                                         <div class="row">
                                           <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleSelectGender">Rôle</label>
                                                        <select class="form-control" id="u_role_edit"  name="u_role_edit">
                                                           <option hidden="">Sélectionnez le rôle</option>
                                                            <option value="ADMIN">ADMIN</option>
                                                            <option value="AGENT">AGENT</option>
                                                            
                                                           
                                                        </select>
                                                    </div>
                                                      <span id="u_role_error" class="text-danger"></span>
                                                </div>

                                             <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Mot de passe</label>
                                                <input type="text" class="form-control" id="u_password_edit" name="u_password_edit" placeholder="Mot de passe">
                                            </div>
                                              <span id="u_password_edit_error" class="text-danger"></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                                 <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="exampleSelectGender">Genre</label>
                                                        <select class="form-control" id="u_genre_edit"  name="u_genre_edit">
                                                           <option hidden="">Sélectionnez le Genre</option>
                                                            <option value="Homme">Homme</option>
                                                            <option value="Femme">Femme</option>
                                                          
                                                        </select>
                                                    </div>
                                                      <span id="u_genre_edit_error" class="text-danger"></span>
                                                </div>
                                        </div>    
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                         <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Modifier</button>
                                    </div>
                                 </form>
                                </div>
                            </div>
                        </div>
                 <!-- FIN DU MODAL   -->

        <!--MODAL POUR CHANGER LE STATUT-->
         <form  id="activebouton">
            <div class="modal fade" id="Modal_statut" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                   Changement de statut du Personnel
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                       <strong>Voulez-vous changé de statut ?</strong>
                  </div>
                  <div class="modal-footer">
                    <input type="hidden" name="u_id_actif" id="u_id_actif" value="">
                    <input type="hidden" name="u_statut_actif" id="u_statut_actif" value="">
                    
                    <button type="button" class="btn btn-xs btn-secondary" data-dismiss="modal">Non</button>
                    <button  type="submit" id="btn_actif" class="btn btn-xs btn-danger">Oui</button>
                  </div>
                </div>
              </div>
            </div>
           </form>
         <!-- FIN DU MODAL -->

       <!--  MODAL POUR LA SUPPRESSION -->
          <form  id="delete">
            <div class="modal fade" id="Modal_delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                   Suppression du Personnel
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                       <strong>Voulez-vous supprimé definitivement le personnel?</strong>
                  </div>
                  <div class="modal-footer">
                    <input type="hidden" name="u_id_delete" id="u_id_delete" value="">
                                        
                    <button type="button" class="btn btn-xs btn-secondary" data-dismiss="modal">Non</button>
                    <button  type="submit" id="btn_actif" class="btn btn-xs btn-danger">Oui</button>
                  </div>
                </div>
              </div>
            </div>
          </form>
           <!-- FIN DU MODAL -->

    </div>
</div>
