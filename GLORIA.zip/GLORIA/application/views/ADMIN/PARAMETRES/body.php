<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
<div class="main-content">
    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-settings bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Parametrage</h5>
                                            <span>Page de parametrage</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>DashboardAdmin/index"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Parametrage</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                         <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                        <?php echo $info; ?>
                  <div class="row">
                   <?php if($u_role=='ADMIN'){
                                    echo'
                      <div class="col-lg-4">
                        <div class="card ">
                            <div class="card-header bg-dark">
                                <h3 style="color: white;">Listing des Années</h3>
                                 <span>&nbsp;&nbsp;
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#demoModal" style="margin-left:0%;"> <i class="ik ik-plus-circle"></i>Nouvelle Année</button>
                           
                              </span>
                            </div>

                           
                            <div style="height:300px; overflow:auto;">
                                <table id="table" class="table">
                                    <thead>
                                        <tr>
                                           
                                            <th>#</th>
                                            <th>Années</th>
                                            <th style="text-align:center;">Actions</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody id="show">
                                       
                                    </tbody>
                                </table>
                            </div>
                    </div>
                  </div>';} ?>

              <!--DEUXIEME TABLE  -->
                   <div class="col-lg-8">
                        <div class="card ">
                            <div class="card-header bg-dark">
                                <h3 style="color: white;">Listing des Medicaments</h3>
                                 <span>&nbsp;&nbsp;
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#demoModalMed" style="margin-left:0%;"> <i class="ik ik-plus-circle"></i>Nouveau Medicament</button>
                           
                              </span>
                            </div>

                            <!-- </br> -->
                            <div style="height:300px;overflow:auto;">
                                <table id="Medicament" class="table">
                                    <thead>
                                        <tr>
                                           
                                            <th>#</th>
                                            <th>Noms des Medicaments</th>
                                            <th>Categories</th>
                                            <th style="text-align:center;">Actions</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody id="showMed">
                                       
                                    </tbody>
                                </table>
                            </div>
                    </div>
                  </div>


               <!-- FIN DE LA COLONNE -->
            </div>

              <div class="row">
                 <?php if($u_role=='ADMIN'){
                                    echo'
                      <div class="col-lg-6">
                        <div class="card ">
                            <div class="card-header bg-dark">
                                <h3 style="color: white;">Parametrage du Taux Echange</h3>
                                 <span>&nbsp;&nbsp;
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#ComptModal" style="margin-left:0%;"> <i class="ik ik-plus-circle"></i>Nouveau Parametrage</button>
                           
                              </span>
                            </div>

                           
                            <div style="height:300px; overflow:auto;">
                                <table id="tableCompt" class="table">
                                    <thead>
                                        <tr>
                                           
                                            <th>#</th>
                                            <th>Ref.en Dollars</th>
                                            <th>Equivalance en Franc</th>
                                            <th>Taux Fixe</th>
                                            <th style="text-align:center;">Actions</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody id="showCompt">
                                       
                                    </tbody>
                                </table>
                            </div>
                    </div>
                  </div>';} ?>
              </div>

                


                    <!-- MODAL POUR AJOUT   -->

                         <div class="modal fade" id="demoModal" tabindex="-1" role="dialog" aria-labelledby="demoModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="demoModalLabel">Ajout d'une nouvelle année</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                     <form class="forms-sample" id="submit">
                                     <div class="modal-body">
                                       
                                        <div class="row">
                                            <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1">Inserez l'Année</label>
                                                <input type="text" class="form-control" id="annee" name="annee" placeholder="Inserer l'Année">
                                            </div>
                                              <span id="annee_error" class="text-danger"></span>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                         <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Enregistrer</button>
                                    </div>
                                 </form>
                                </div>
                            </div>
                        </div>
                 <!-- FIN DU MODAL   -->



                  <!-- MODAL POUR AJOUT MEDICAMENT  -->

                         <div class="modal fade" id="demoModalMed" tabindex="-1" role="dialog" aria-labelledby="demoModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="demoModalLabel">Ajout d'un nouveau Medicament</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                     <form class="forms-sample" id="submitMed">
                                     <div class="modal-body">
                                       
                                        <div class="row">
                                          <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1"> Nom du Medicament</label>
                                                <input type="text" class="form-control" id="med" name="med" placeholder="Inserer le nom du Medicament">
                                            </div>
                                              <span id="med_error" class="text-danger"></span>
                                          </div>

                                        <div class="col-lg-6">
                                          <div class="form-group">
                                            <label for="exampleInputEmail1"style="color: white;">Categorie</label>
                                                <select class="form-control" id="Categorie"  name="Categorie">
                                                    <option hidden="">Selectionnez la Categorie</option>
                                                    <option value="AMPOULE">AMPOULE</option>
                                                    <option value="FLACON">FLACON</option>
                                                    <option value="BOITE">BOITE</option>
                                                    <option value="PLAQUETTE">PLAQUETTE</option>
                                                    <option value="PIECE">PIECE</option>
                                                </select>
                                            </div>
                                        </div>
                                            
                                        </div>
                                        
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                         <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Enregistrer</button>
                                    </div>
                                 </form>
                                </div>
                            </div>
                        </div>
                 <!-- FIN DU MODAL   -->

                      <!-- MODAL POUR AJOUT DU TAUX   -->

                         <div class="modal fade" id="ComptModal" tabindex="-1" role="dialog" aria-labelledby="demoModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="demoModalLabel">Ajout du Parametrage Compte</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                     <form class="forms-sample" id="Compte">
                                     <div class="modal-body">
                                       
                                        <div class="row">
                                            <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1">Reference en Dollars</label>
                                                <input type="text" class="form-control" id="dollars" name="dollars" placeholder="Reference en Dollars">
                                            </div>
                                              <span id="dollars_error" class="text-danger"></span>
                                          </div>

                                          <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1">Reference en Franc</label>
                                                <input type="text" class="form-control" id="Congo" name="Congo" placeholder="Reference en Franc">
                                            </div>
                                              <span id="Congo_error" class="text-danger"></span>
                                          </div>
                                            
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                         <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Enregistrer</button>
                                    </div>
                                 </form>
                                </div>
                            </div>
                        </div>
                 <!-- FIN DU MODAL   -->

              <!-- MODAL POUR EDIT MEDICAMEENT   -->

                          <div class="modal fade" id="demoModalEditMed" tabindex="-1" role="dialog" aria-labelledby="demoModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="demoModalLabel">Formulaire de Modification</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                     <form class="forms-sample" id='SubmitMedicament'>
                                     <div class="modal-body">
                                         <input type="hidden" class="form-control" id="m_id" name="m_id">
                                        <div class="row">
                                          <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1"> Nom du Medicament</label>
                                                <input type="text" class="form-control" id="med_edit" name="med_edit" placeholder="Inserer le nom du Medicament">
                                            </div>
                                          </div>

                                        <div class="col-lg-6">
                                          <div class="form-group">
                                            <label for="exampleInputEmail1"style="color: white;">Categorie</label>
                                                <select class="form-control" id="Categorie_edit"  name="Categorie_edit">
                                                    <option hidden="">Selectionnez la Categorie</option>
                                                    <option value="AMPOULE">AMPOULE</option>
                                                    <option value="FLACON">FLACON</option>
                                                    <option value="BOITE">BOITE</option>
                                                    <option value="PLAQUETTE">PLAQUETTE</option>
                                                    <option value="PIECE">PIECE</option>
                                                </select>
                                            </div>
                                        </div>
                                      </div>
   
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                         <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Modifier</button>
                                    </div>
                                 </form>
                                </div>
                            </div>
                        </div>
                 <!-- FIN DU MODAL   -->


                


                    <!-- MODAL POUR EDIT   -->

                          <div class="modal fade" id="demoModalEdit" tabindex="-1" role="dialog" aria-labelledby="demoModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="demoModalLabel">Modifier l'Année</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                     <form class="forms-sample" action="<?php echo base_url()?>Parametre/modify" method="POST">
                                     <div class="modal-body">
                                         <input type="hidden" class="form-control" id="y_id" name="y_id">
                                        <div class="row">
                                            <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1"> l'année</label>
                                                <input type="text" class="form-control" id="y_year_edit" name="y_year_edit" placeholder="Année">
                                            </div>
                                             
                                            </div>
                                        </div>
   
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                         <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Modifier</button>
                                    </div>
                                 </form>
                                </div>
                            </div>
                        </div>
                 <!-- FIN DU MODAL   -->


                   <!-- MODAL POUR EDIT DU TAUX  -->

                          <div class="modal fade" id="TAUXModalEdit" tabindex="-1" role="dialog" aria-labelledby="demoModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="demoModalLabel">Modifier le Taux D'Echange</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                     <form class="forms-sample" id="Taux" >
                                     <div class="modal-body">
                                         <input type="hidden" class="form-control" id="com_id" name="com_id">
                                        <div class="row">
                                            <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1">Reference en Dollars</label>
                                                <input type="text" class="form-control" id="dollars_edit" name="dollars_edit" placeholder="Reference en Dollars">
                                            </div>
                                             
                                            </div>

                                             <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="exampleInputUsername1">Reference en Franc</label>
                                                <input type="text" class="form-control" id="franc_edit" name="franc_edit" placeholder="Reference en Franc">
                                            </div>
                                            </div>

                                        </div>
   
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                         <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Modifier</button>
                                    </div>
                                 </form>
                                </div>
                            </div>
                        </div>
                 <!-- FIN DU MODAL   -->

       

       <!--  MODAL POUR LA SUPPRESSION -->
          <form  id="deleteAuthentification">
            <div class="modal fade" id="Modal_delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                   Suppression de l'Année
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                       <strong>Voulez-vous supprimé definitivement l'Année?</strong>
                  </div>
                  <div class="modal-footer">
                    <input type="hidden" name="y_id_delete" id="y_id_delete" value="">
                                        
                    <button type="button" class="btn btn-xs btn-secondary" data-dismiss="modal">Non</button>
                    <button  type="submit" id="btn_actif" class="btn btn-xs btn-danger">Oui</button>
                  </div>
                </div>
              </div>
            </div>
          </form>
           <!-- FIN DU MODAL -->

         <!--  MODAL POUR L'AUTHENTIICATION  YEAR-->
          <form  id="Reset">
            <div class="modal fade" id="Modal_auth" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <center>AUTHENTIFICATION</center>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <center> <img style="width:100px; height: 100px;" src="<?php echo base_url('assets/p2.png')?>" class="rounded-circle"></center>
                    <div class="form-group">
                    <input type="text" class="form-control" placeholder="Nom d'Utilisateur" name='username' id='username'>
                    </div>
                    <div class="form-group">
                    <input type="password" class="form-control" placeholder="Mot de passe" name="password" id='password'>
                    <input type="hidden" name="y_id_delete" id="y_id_delete" value="">
                    </div>
                               
                    <div class="sign-btn text-center">
                      <button class="btn btn-theme">Supprimer</button>
                    </div>     
                </div>
                 
                </div>
              </div>
            </div>
          </form>
           <!-- FIN DU MODAL -->


         <!--  MODAL POUR L'AUTHENTIICATION  TAUX-->
          <form  id="ResetTaux">
            <div class="modal fade" id="ModalTAUX_auth" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <center>AUTHENTIFICATION</center>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <center> <img style="width:100px; height: 100px;" src="<?php echo base_url('assets/p2.png')?>" class="rounded-circle"></center>
                    <div class="form-group">
                    <input type="text" class="form-control" placeholder="Nom d'Utilisateur" name='username' id='username'>
                    </div>
                    <div class="form-group">
                    <input type="password" class="form-control" placeholder="Mot de passe" name="password" id='password'>
                    <input type="hidden" name="comp_delete" id="comp_delete" value="">
                    </div>
                               
                    <div class="sign-btn text-center">
                      <button class="btn btn-theme">Supprimer</button>
                    </div>     
                </div>
                 
                </div>
              </div>
            </div>
          </form>
           <!-- FIN DU MODAL -->


        <!--  MODAL POUR L'AUTHENTIICATION  MED -->
          <form  id="Delete">
            <div class="modal fade" id="Modal_authMed" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <center>AUTHENTIFICATION</center>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <center> <img style="width:100px; height: 100px;" src="<?php echo base_url('assets/p2.png')?>" class="rounded-circle"></center>
                    <div class="form-group">
                    <input type="text" class="form-control" placeholder="Nom d'Utilisateur" name='username' id='username'>
                    </div>
                    <div class="form-group">
                    <input type="password" class="form-control" placeholder="Mot de passe" name="password" id='password'>
                    <input type="hidden" name="m_id_delete" id="m_id_delete" value="">
                    </div>
                               
                    <div class="sign-btn text-center">
                      <button class="btn btn-theme">Supprimer</button>
                    </div>     
                </div>
                 
                </div>
              </div>
            </div>
          </form>
           <!-- FIN DU MODAL -->


           
    </div>
</div>
