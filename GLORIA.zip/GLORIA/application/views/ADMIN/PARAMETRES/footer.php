 <footer class="footer">
                    <div class="w-100 clearfix">
                        <span class="text-center text-sm-left d-md-inline-block"><?php echo $footer ?></span>
                        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Réaliser <i class="fa fa-heart text-danger"></i> par <a href="http://lavalite.org/" class="text-dark" target="_blank"><?php echo $footer1 ?></a></span>
                    </div>
                </footer>
                
            </div>
        </div>
        

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/src/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
        <script src="<?php echo base_url()?>assets/plugins/popper.js/dist/umd/popper.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/screenfull/dist/screenfull.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/jquery-jvectormap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/tests/assets/jquery-jvectormap-world-mill-en.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/moment/moment.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/select2/dist/js/select2.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/d3/dist/d3.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/c3/c3.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/tables.js"></script>
        <script src="<?php echo base_url()?>assets/js/widgets.js"></script>
        <script src="<?php echo base_url()?>assets/js/charts.js"></script>
        <script src="<?php echo base_url()?>assets/dist/js/theme.min.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <!-- SweetAlert2 -->
        <script src="<?php echo base_url();?>/assets/plugins/sweetalert2/sweetalert2.min.js"></script>
        <!-- Toastr -->
        <script src="<?php echo base_url();?>/assets/plugins/toastr/toastr.min.js"></script>
        <script src="<?php echo base_url();?>/assets/sweetalert2.all.min.js"></script>
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>




<script type="text/javascript">
 $(document).ready(function(){
   show_year();
  $('#table').DataTable();
        //FONCTION QUI PERMET D'AFFICHER LES DONNEES DANS LA TABLE
    function show_year(){

        $.ajax({
            type  : 'ajax',
            url   : '<?php echo site_url('Parametre/showyear')?>',
            async : false,
            dataType : 'json',
            success : function(data){
                var html = '';
                var i;
                for(i=0; i<data.length; i++){
                    var a=1+i;
                    html += '<tr>'+'<td>'+a+'</td>'+
                            '<td>'+data[i].y_year+'</td>'+
                            '<td style="text-align:center;">'+

              '<a href="javascript:void(0);" class="ik ik-edit f-16 text-info  item_edit" data-y_id="'+data[i].y_id+'" data-y_year="'+data[i].y_year+'"></a>'+' '+

                '&nbsp;<a href="javascript:void(0);" class=" ik ik-trash-2 f-16 text-red  btn-xs item_delete" data-y_id="'+data[i].y_id+'"></a>'+
                                '</td>'+
                            '</tr>';
                }
                $('#show').html(html);
                
            }
        }); 
      }

// <!-- AJOUT D'ANNEES-->
  $('#submit').submit(function(e){
      e.preventDefault();
      var fd = new FormData(document.getElementById("submit"));
        
          $.ajax({
                    url:'<?php echo base_url();?>Parametre/Addyear',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                      success: function(data){
                      if(data.error){
                        if(data.annee_error !=''){
                          $('#annee_error').html(data.annee_error);
                        }else{
                          $('#annee_error').html('');
                        }
                         Swal.fire(
                          'Enregistrement Echoué!',
                          'Vérifie Bien tes données!',
                          'error'
                        )
                      }
                        if(data.success){
                          Swal.fire(
                            'Enregistrement reussi!',
                            '<a href>Merci !</a>',
                            'success'
                          )
                          $('#annee_error').html('');
                          $('#submit')[0].reset();
                          $('#demoModal').modal('hide');
                          show_year();
                        }   
                   }
             });
           });

        //MODAL POUR EDITER 

         $('#show').on('click','.item_edit',function(){
            var y_id = $(this).data('y_id');
            var y_year = $(this).data('y_year');
            
  
            $('#demoModalEdit').modal('show');
            $('[name="y_id"]').val(y_id);
            $('[name="y_year_edit"]').val(y_year);
        });

  
     // MODAL POUR SUPPRIMER l'ANNEE 

        $('#show').on('click','.item_delete',function(){
         var y_id = $(this).data('y_id');
         $('#Modal_auth').modal('show');
         $('[name="y_id_delete"]').val(y_id);
         show_year();
        
    });


    //BOUTON POUR SUPPRIMER l'ANNEE
     $('#Reset').submit(function(e){ 
                  e.preventDefault(); 
                  $.ajax({
                     url:'<?php echo base_url();?>Parametre/delete',
                     type:"post",
                     data:new FormData(this), //this is formData
                     processData:false,
                     contentType:false,
                     cache:false,
                     async:false,
                     dataType:"json",
                      success: function(data){

                         if(data.success){

                        Swal.fire(
                            'Suppression reussi avec succès!',
                            '<a href>Merci !</a>',
                            'success')

                        $('#Reset')[0].reset();
                        $('#Modal_auth').modal('hide');
                        show_year();
                   }

                    if(data.error){
                        Swal.fire(
                            'Nom utilisateur et Mot de passe Incorrect!',
                            '<a href>Merci !</a>',
                            'error')
                        $('#Modal_auth').modal('show');
                        show_year();
                   }
             }
        });
     });

     // LA FONCTION PERMETTANT DE CHERCHER L'ANEE PAR SELECTION
    $("#anne").select2({
         ajax: { 
           url:'<?php echo base_url();?>Parametre/getyear',
           type: "post",
           dataType: 'json',
           delay: 250,
           data: function (params) {
              return {
                searchTerm: params.term // search term
              };
           },
           processResults: function (response) {
              return {
                 results: response
              };
           },
           cache: true
         }
     });
// FIN DE LA PREMIERE FONCTION
   });

// DEUXIEME FONCTION
$(document).ready(function(){
  show_med();
  $('#Medicament').DataTable();
  function show_med(){

        $.ajax({
            type  : 'ajax',
            url   : '<?php echo site_url('Medicaments/showMed')?>',
            async : false,
            dataType : 'json',
            success : function(data){
                var html = '';
                var i;
                for(i=0; i<data.length; i++){

                    var a=1+i;
                    html += '<tr>'+'<td>'+a+'</td>'+
                            '<td>'+data[i].m_name+'</td>'+
                            '<td>'+data[i].m_categorie+'</td>'+
                            '<td style="text-align:center;">'+

              '<a href="javascript:void(0);" class="ik ik-edit f-16 text-info  item_edit" data-m_id="'+data[i].m_id+'" data-m_name="'+data[i].m_name+'" data-m_categorie="'+data[i].m_categorie+'"></a>'+' '+

                '&nbsp;<a href="javascript:void(0);" class=" ik ik-trash-2 f-16 text-red  btn-xs item_delete" data-m_id="'+data[i].m_id+'"></a>'+
                                '</td>'+
                            '</tr>';
                }
                $('#showMed').html(html);
                
            }
        }); 
      }

   
      // <!-- AJOUT DES MEDICAMENTS-->

  $('#submitMed').submit(function(e){
      e.preventDefault();
      var fd = new FormData(document.getElementById("submitMed"));
        
          $.ajax({
                    url:'<?php echo base_url();?>Medicaments/AddMed',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                      success: function(data){
                        //alert(data)
                      if(data.exist){
                         Swal.fire(
                          'Enregistrement Echoué!',
                          'Cette donnée existe déja!',
                          'error'
                        )
                      }else if(data.empty){

                        Swal.fire(
                          'Enregistrement Echoué!',
                          'il faut remplir tous les Champs!',
                          'error'
                        )
                      }else{ 
                          Swal.fire(
                            'Enregistrement reussi!',
                            '<a href>Merci !</a>',
                            'success'
                          )
                           show_med();
                          $('#submitMed')[0].reset();
                          $('#demoModalMed').modal('hide');
                          
                        }   
                   }
             });
           });

  // FONCTION POUR LA MODIFICATION

     $('#showMed').on('click','.item_edit',function(){
            var m_id = $(this).data('m_id');
            var m_name = $(this).data('m_name');
            var m_categorie = $(this).data('m_categorie');
            $('#demoModalEditMed').modal('show');
            $('[name="m_id"]').val(m_id);
            $('[name="med_edit"]').val(m_name);
            $('[name="Categorie_edit"]').val(m_categorie);
        });

  $('#SubmitMedicament').submit(function(e){
      e.preventDefault();
      var fd = new FormData(document.getElementById("SubmitMedicament"));
       // alert('salut')
          $.ajax({
                    url:'<?php echo base_url();?>Medicaments/EditMed',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                      success: function(data){
                      if(data.exist){
                         Swal.fire(
                          'Enregistrement Echoué!',
                          'Cette donnée existe déja!',
                          'error'
                        )
                      }else if(data.empty){

                        Swal.fire(
                          'Enregistrement Echoué!',
                          'il faut remplir tous les Champs!',
                          'error'
                        )
                      }else{ 
                          Swal.fire(
                            'Modification reussi!',
                            '<a href>Merci !</a>',
                            'success'
                          )
                           show_med();
                          $('#SubmitMedicament')[0].reset();
                          $('#demoModalEditMed').modal('hide');
                          
                        }   
                   }
             });
           });

    // MODAL POUR SUPPRIMER LE MEDICAMENT 

        $('#showMed').on('click','.item_delete',function(){
         var m_id = $(this).data('m_id');
         $('#Modal_authMed').modal('show');
         $('[name="m_id_delete"]').val(m_id);
         show_med();
    });

     //BOUTON POUR SUPPRIMER l'ANNEE
     $('#Delete').submit(function(e){ 
                  e.preventDefault(); 
                  $.ajax({
                     url:'<?php echo base_url();?>Medicaments/delete',
                     type:"post",
                     data:new FormData(this), //this is formData
                     processData:false,
                     contentType:false,
                     cache:false,
                     async:false,
                     dataType:"json",
                      success: function(data){

                         if(data.success){

                        Swal.fire(
                            'Suppression reussi avec succès!',
                            '<a href>Merci !</a>',
                            'success')

                        $('#Delete')[0].reset();
                        $('#Modal_authMed').modal('hide');
                        show_med();
                   }

                    if(data.error){
                        Swal.fire(
                            'Nom utilisateur et Mot de passe Incorrect!',
                            '<a href>Merci !</a>',
                            'error')
                        $('#Modal_authMed').modal('show');
                        show_med();
                   }
             }
        });
     });


  show_Compt();
  $('#tableCompt').DataTable();
        //FONCTION QUI PERMET D'AFFICHER LES DONNEES DANS LA TABLE
    function show_Compt(){

        $.ajax({
            type  : 'ajax',
            url   : '<?php echo site_url('Parametre/ShowCompt')?>',
            async : false,
            dataType : 'json',
            success : function(data){
                var html = '';
                var i;
                for(i=0; i<data.length; i++){
                    var a=1+i;
                    html += '<tr>'+'<td>'+a+'</td>'+
                            '<td>'+data[i].comp_dollars+'USD'+'</td>'+
                            '<td>'+data[i].comp_franc+'FC'+'</td>'+
                            '<td>'+data[i].comp_taux+'FC'+'</td>'+
                            '<td style="text-align:center;">'+

              '<a href="javascript:void(0);" class="ik ik-edit f-16 text-info  item_edit" data-com_id="'+data[i].com_id+'" data-comp_dollars="'+data[i].comp_dollars+'" data-comp_franc="'+data[i].comp_franc+'"></a>'+' '+

                '&nbsp;<a href="javascript:void(0);" class=" ik ik-trash-2 f-16 text-red  btn-xs item_delete" data-com_id="'+data[i].com_id+'"></a>'+
                                '</td>'+
                            '</tr>';
                }
                $('#showCompt').html(html);
                
            }
        }); 
      }


// <!-- AJOUT DU TAUX-->
  $('#Compte').submit(function(e){
      e.preventDefault();
      var fd = new FormData(document.getElementById("Compte"));
        
          $.ajax({
                    url:'<?php echo base_url();?>Parametre/AddCompt',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                      success: function(data){
                      if(data.error){
                        if(data.annee_error !=''){
                          $('#dollars_error').html(data.dollars_error);
                        }else{
                          $('#dollars_error').html('');
                        }
                         if(data.Congo_error !=''){
                          $('#Congo_error').html(data.Congo_error);
                        }else{
                          $('#Congo_error').html('');
                        }
                         Swal.fire(
                          'Enregistrement Echoué!',
                          'Vérifie Bien tes données!',
                          'error'
                        )
                      }
                        if(data.success){
                          Swal.fire(
                            'Enregistrement reussi!',
                            '<a href>Merci !</a>',
                            'success'
                          )
                          $('#Compte')[0].reset();
                          $('#ComptModal').modal('hide');
                           show_Compt();
                        }   
                   }
             });
           });

   //BOUTON POUR SUPPRIMER lE TAUX
     $('#ResetTaux').submit(function(e){ 
                  e.preventDefault(); 
                  $.ajax({
                     url:'<?php echo base_url();?>Parametre/ResetTaux',
                     type:"post",
                     data:new FormData(this), //this is formData
                     processData:false,
                     contentType:false,
                     cache:false,
                     async:false,
                     dataType:"json",
                      success: function(data){

                         if(data.success){

                        Swal.fire(
                            'Suppression reussi avec succès!',
                            '<a href>Merci !</a>',
                            'success')

                        $('#ResetTaux')[0].reset();
                        $('#ModalTAUX_auth').modal('hide');
                        show_Compt();
                   }

                    if(data.error){
                        Swal.fire(
                            'Nom utilisateur et Mot de passe Incorrect!',
                            '<a href>Merci !</a>',
                            'error')
                        $('#ModalTAUX_auth').modal('show');
                        show_Compt();
                   }
             }
        });
     });

   // FONCTION POUR LA MODIFICATION

     $('#showCompt').on('click','.item_edit',function(){
            var comp_dollars = $(this).data('comp_dollars');
            var comp_franc = $(this).data('comp_franc');
            var com_id = $(this).data('com_id');
            $('#TAUXModalEdit').modal('show');
            $('[name="com_id"]').val(com_id);
            $('[name="dollars_edit"]').val(comp_dollars);
            $('[name="franc_edit"]').val(comp_franc);
        });

      // FONCTION POUR LA SUPPRESSION

     $('#showCompt').on('click','.item_delete',function(){
            var com_id = $(this).data('com_id');
            $('#ModalTAUX_auth').modal('show');
            $('[name="comp_delete"]').val(com_id);
        });

     // <!-- AJOUT DU TAUX-->
  $('#Taux').submit(function(e){
      e.preventDefault();
      var fd = new FormData(document.getElementById("Taux"));
        
          $.ajax({
                    url:'<?php echo base_url();?>Parametre/EditCompt',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                      success: function(data){
                      if(data.error){
                         Swal.fire(
                          'Enregistrement Echoué!',
                          'Il faut remplir tout les champs!',
                          'error'
                        )
                      }
                        else{
                          Swal.fire(
                            'Enregistrement reussi!',
                            '<a href>Merci !</a>',
                            'success'
                          )
                          $('#Taux')[0].reset();
                          $('#TAUXModalEdit').modal('hide');
                           show_Compt();
                        }   
                   }
             });
           });
  



  
  });   
  </script>

    </body>
</html>
