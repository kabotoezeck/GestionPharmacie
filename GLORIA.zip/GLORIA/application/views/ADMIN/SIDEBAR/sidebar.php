
<?php $var=base_url();?>
<div class="page-wrap">
                <div class="app-sidebar colored">
                    <div class="sidebar-header">
                       
                   <span class="text"><?php echo $photo?></span>
                      
                        <button type="button" class="nav-toggle"><i data-toggle="expanded" class="ik ik-toggle-right toggle-icon"></i></button>
                        <button id="sidebarClose" class="nav-close"><i class="ik ik-x"></i></button>
                    </div>
                    
                    <div class="sidebar-content">
                        <div class="nav-container">
                            <nav id="main-menu-navigation" class="navigation-main">
                               
                                
                          
                                 <div class="nav-item">
                                    <a href="<?php echo base_url()?>DashboardAdmin/index"><i class="ik ik-align-justify"></i><span>Acceuil</span> </a>
                                </div>

                                <?php if($u_role=='ADMIN'){
                                    echo'
                                    <div class="nav-lavel"> Gestion des Utilisateurs</div> 
                                    <div class="nav-item">
                                    <a href="'.$var.'Users/index"><i class="ik ik-user"></i><span>Gestion Utilisateurs</span> </a>
                                    </div>';
                                   } ?>
                                 <div class="nav-lavel"> Gestion de stock</div>

                                 <div class="nav-item has-sub">
                                    <a href="javascript:void(0)"><i class="ik ik-box"></i><span>Gestion de stock</span></a>
                                    <div class="submenu-content">
                                    <a href="<?php echo base_url()?>Stock/index" class="menu-item">Ajout du Stock</a>
                                    <?php if($u_role=='ADMIN'){
                                    echo'
                                    <a href="'.$var.'Depenses/index" class="menu-item">Depenses Effectuées </a>';
                                   } ?>
                                      
                                    </div>
                                </div>

                                 <div class="nav-lavel"> Gestion de Vente </div>
                                 <div class="nav-item has-sub">
                                    <a href="javascript:void(0)"><i class="ik ik-activity"></i><span>Gestion de Vente</span></a>
                                    <div class="submenu-content">
                                       <a href="<?php echo base_url()?>Vente/index" class="menu-item">Gestion de Vente</a>
                                        <a href="<?php echo base_url()?>Vente/search" class="menu-item">Recherche de la Facture</a>

                                        <?php if($u_role=='ADMIN'){
                                                 echo'
                                                 <a href="'.$var.'Vente/ReportDay" class="menu-item">vente Journalière</span> </a>

                                                <a href="'.$var.'Vente/Rapport" class="menu-item">Rapport de Vente </a>';
                                       }?>

                                    </div>
                                </div>

                                 <div class="nav-lavel">Paramètres </div>
                                 <div class="nav-item">
                                    <a href="<?php echo base_url()?>Parametre/index"><i class="ik ik-settings"></i><span>Paramètres</span> </a>
                                </div>

                            <!--  <div class="nav-lavel">Corbeille </div> -->
                               <!--   <div class="nav-item">
                                    <a href="<?php echo base_url()?>Rapport/Corbeille"><i class="ik ik-archive"></i><span>Corbeille</span> </a>
                                </div> -->

                                 <div class="nav-lavel">Déconnexion </div>
                                 <div class="nav-item">
                                    <a href="<?php echo base_url()?>welcome/logout"><i class="ik ik-power"></i><span>Déconnexion</span> </a>
                                </div>


                               
                        </div>
                    </div>
                </div>