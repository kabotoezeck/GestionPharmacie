<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
     <div class="main-content">
                    <div class="container-fluid">
                         <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                       <i class="ik ik-bar-chart-2 bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Tableau de bord</h5>
                                            <span>Cette page permet de voir  les effectifs des données de l'application</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>welcome/DASHBOARD"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Tableau de bord </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>

                            <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>                    

                    
                         <div class="row clearfix">
                             <?php if($u_role=='ADMIN'){
                            echo'
                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="widget bg-primary">
                                    <div class="widget-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="state">
                                                <h6>Total des Utilisateurs</h6>
                                                <h2><div id="countUsers"></div></h2>
                                            </div>
                                            <div class="icon">
                                                <i class="ik ik-users"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>';} ?>

                             <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="widget bg-success">
                                    <div class="widget-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="state">
                                                <h6> Produit Disponible</h6>
                                                <h2><div id="countMed"></div></h2>
                                            </div>
                                            <div class="icon">
                                                <i class="ik ik-users"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                             <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="widget bg-danger">
                                    <div class="widget-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="state">
                                                <h6>Medicament en Alerte</h6>
                                                <h2><div id="countManque"></div></h2>
                                            </div>
                                            <div class="icon">
                                                <i class="ik ik-users"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>    
                </div>

                <div class="row">
                 <div class="col-lg-8">     
                         <div class="form-group">
                            <select   id="med" name="med" class="form-control" style="width:600px;">
                                <option value='0'>-- Rechercher un Medicament --</option>
                            </select>
                           
                        </div>
                     </div>
                    
                     <div id="result"></div>   
                </div>
            </div>
         </div>
              

         

                                              