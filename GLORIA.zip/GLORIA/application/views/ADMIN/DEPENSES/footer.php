 <footer class="footer">
                    <div class="w-100 clearfix">
                        <span class="text-center text-sm-left d-md-inline-block"><?php echo $footer ?></span>
                        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Réaliser <i class="fa fa-heart text-danger"></i> par <a href="http://lavalite.org/" class="text-dark" target="_blank"><?php echo $footer1 ?></a></span>
                    </div>
                </footer>
                
            </div>
        </div>
        

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/src/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
        <script src="<?php echo base_url()?>assets/plugins/popper.js/dist/umd/popper.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/screenfull/dist/screenfull.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/jquery-jvectormap.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/jvectormap/tests/assets/jquery-jvectormap-world-mill-en.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/moment/moment.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/select2/dist/js/select2.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/d3/dist/d3.min.js"></script>
        <script src="<?php echo base_url()?>assets/plugins/c3/c3.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/tables.js"></script>
        <script src="<?php echo base_url()?>assets/js/widgets.js"></script>
        <script src="<?php echo base_url()?>assets/js/charts.js"></script>
        <script src="<?php echo base_url()?>assets/dist/js/theme.min.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <!-- SweetAlert2 -->
        <script src="<?php echo base_url();?>/assets/plugins/sweetalert2/sweetalert2.min.js"></script>
        <!-- Toastr -->
        <script src="<?php echo base_url();?>/assets/plugins/toastr/toastr.min.js"></script>
        <script src="<?php echo base_url();?>/assets/sweetalert2.all.min.js"></script>
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>




<script type="text/javascript">
 $(document).ready(function(){
      
// <!-- AJOUT D'ANNEES-->
  $('#submitCharge').submit(function(e){
      e.preventDefault();
      var fd = new FormData(document.getElementById("submitCharge"));
        
          $.ajax({
                    url:'<?php echo base_url();?>Depenses/AddCharge',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                      success: function(data){
                      if(data.empty){
                        
                         Swal.fire(
                          'Enregistrement Echoué!',
                          'Tout les champs sont obligatoire!',
                          'error'
                        )
                      }else if(data.sup){

                         Swal.fire(
                          'Enregistrement Echoué!',
                          'Le montant doit être superieur à zero!',
                          'error'
                        )
                       }else{
                          Swal.fire(
                            'Enregistrement reussi!',
                            '<a href>Merci !</a>',
                            'success'
                          )
                          $('#submitCharge')[0].reset();
                      }    
                   }
             });
           });

    
  
// FONCTION PERMETTANT VOIR LE RAPPORT PAR MOIS

       $('#rapport').submit(function(e){
        e.preventDefault();
        var fd = new FormData(document.getElementById("rapport")); 
            $.ajax({
                    url:'<?php echo base_url();?>Depenses/rapportMonth',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                    success: function(data){ 
                    $('#result').html(data);
                   
                      }
                  });
                 
            return false;
          });

       // FONCTION PERMETTANT VOIR LES CHARGES

       $('#resultCharge').submit(function(e){
         var date = $('#date').val();
        e.preventDefault();
        var fd = new FormData(document.getElementById("resultCharge")); 
            $.ajax({
                    url:'<?php echo base_url();?>Depenses/Getdate',
                    type:"post",
                    data: fd,           // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false,       // To unable request pages to be cached
                    processData: false,
                    dataType:"json",
                    success: function(data){ 
                    $('#resultChar').html(data);
                    $('[name="dateprint"]').val(date);
                    }
                  });
                 
            return false;
          });

        




  
  });   
  </script>

  </script>
<script type="text/javascript">
  function myFunction(){
  var x = document.getElementById("form");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
} 

 function myFunction2(){
  var x = document.getElementById("second");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
} 

</script>

    </body>
</html>
