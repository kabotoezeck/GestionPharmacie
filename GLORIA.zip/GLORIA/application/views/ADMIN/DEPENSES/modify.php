<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
                           
 <div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-inbox bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Fiche de Modification</h5>
                                            <span>Cette page permet de Modiifer  les informations relatives aux Charges</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>index.php/welcome/DASHBOARD"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">Pharmacie GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Modification de Charge</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                         <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                   <!--   <?php echo $info;?> -->
 
                        <div class="col-lg-12">   
                            <div class="card">
                                <div class="card-header d-block" style="background-color:firebrick; ">
                                  <h3  style="color:white">Page de modification</h3>
                                       
                             </div>

                     <!-- MODAL POUR MODIFIER  -->
                      <?php  foreach($query->result() as  $value) :?>
                           <form class="forms-sample" action="<?php echo base_url();?>Depenses/EditCharge/<?php echo $value->ch_id;?>"  method="POST">
                                     <div class="modal-body">
                                       
                                      <div class="row">

                                        

                                          <div class="col-lg-2">
                                            <div class="form-group">
                                            <label for="exampleInputUsername1">Montant</label>
                                            <input type="text" class="form-control" name="Montant" value="<?php echo $value->ch_montant ?>">
                                            </div>
                                             
                                            </div>
                                             <div class="col-lg-2">
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">Date d'Enregistrement</label>
                                                <input type="date" class="form-control" name="date" value="<?php echo $value->ch_date?>" >
                                            </div>
                                            </div>

                                        <div class="col-md-4">
                                           <div class="form-group">
                                            <label for="exampleTextarea1">Description</label>
                                            <textarea class="form-control" id="desc"  name="desc"rows="4"><?php echo $value->ch_desc?></textarea>
                                          </div>
                                       </div>
                                        <?php endforeach; ?>
                                      </div>
                                    <div class="modal-footer">
                                        <a  href="<?php echo base_url()?>Depenses/index" type="button" class="btn btn-secondary" data-dismiss="modal">Retour</a>
                                        <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Modifier</button>
                                    </div>
                                 </form>
                                </div>
                           </div>
                                </div>
                            </div>
                            <!-- FIN DU MODAL -->
                             </div>