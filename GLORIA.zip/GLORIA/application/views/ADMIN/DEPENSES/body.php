<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
<div class="main-content">
    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-dollar-sign bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Gestion des Depenses</h5>
                                            <span>Page des Depenses permettant de voir toutes les Depenses effectuées</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>DashboardAdmin/index"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Depense</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                         <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                        <?php echo $info; ?>
                        

                <div class="col-md-12">
                  <div class="row">
                    <div class="col-lg-4">
                    <span>
                     <button type="button" class="btn btn-success"  style="margin-left:0%;"  onclick=" myFunction2()"> <i class="fas fa-plus"></i>Ajout des Charges</button>
                    </span>
                  </div>

                  <div class="col-lg-4">
                    <span>
                     <button type="button" class="btn btn-info"  style="margin-left:0%;"  onclick=" myFunction()"> <i class="fas fa-eye"></i>Voir les Depenses Effectués</button>
                    </span>
                  </div>
                </div>
              </br>
            </br>

                         <div id="form" style="display:none;" >
                                <div class="card">
                                    <div class="card-header  bg-dark"><h3 style="color:white;">Ajout des Charges</h3></div>
                                    <div class="card-body">
                                        <form class="forms-sample" id="rapport">
                                         <div class="row">

                                          <div class="col-lg-4">
                                            <label for="exampleInputEmail1 " style="color:black;">Date d'entrée</label>
                                            <div class="form-group">
                                            <input type="date" class="form-control " id="dateentré" name="dateentré">
                                           </div>
                                        </div>
                                        <div class="col-lg-4">
                                          <label for="exampleInputEmail1 " style="color:black;">Recherche</label>
                                            <div class="form-group">
                                             <button type="submit" class="btn btn-primary mr-2">Recherche</button>
                                            </div>
                                        </div>
                                          </div>
                                     <div class="row">
                                        <div class="col-lg-12">
                                       <div id="result"></div> 
                                     </div>
                                      </div>
                                           
                                          
                                    </form>
                                    </div>
                                </div>
                            </div>

                            <!-- DEUXIEME CARD -->

                             <div id="second" style="display:none;" >
                                <div class="card">
                                    <div class="card-header  bg-dark"><h3 style="color:white;">Ajout des Charges</h3></div>
                                    <div class="card-body">
                                        <form class="forms-sample" id="submitCharge">
                                         <div class="row">

                                          <div class="col-lg-2">
                                            <label for="exampleInputEmail1 " style="color:black;">Montant En USD</label>
                                            <div class="form-group">
                                            <input type="text" class="form-control " id="Montant" name="Montant">
                                           </div>
                                        </div>

                                          <div class="col-lg-2">
                                            <label for="exampleInputEmail1 " style="color:black;">Date d'entrée</label>
                                            <div class="form-group">
                                            <input type="date" class="form-control " id="depense" name="depense">
                                           </div>
                                        </div>

                                      <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="exampleTextarea1">Description</label>
                                            <textarea class="form-control" id="desc"  name="desc"rows="4"></textarea>
                                        </div>
                                      </div>
                                        <div class="col-lg-4">
                                          <label for="exampleInputEmail1 " style="color:black;">Enregistrer</label>
                                            <div class="form-group">
                                             <button type="submit" class="btn btn-primary mr-2">Enregistrer</button>
                                            </div>
                                      </div>
                                    </div>
                                  </form>

                                  <form class="forms-sample" id="resultCharge">
                                     <div class="row">

                                        <div class="col-lg-4">
                                            <label for="exampleInputEmail1 " style="color:black;">Filtrez La date</label>
                                            <div class="form-group">
                                            <input type="date" class="form-control " id="date" name="date">
                                           </div>
                                        </div>

                                         <div class="col-lg-4">
                                          <label for="exampleInputEmail1 " style="color:black;">Recherche</label>
                                            <div class="form-group">
                                             <button type="submit" class="btn btn-success mr-2">Recherche</button>
                                            </div>
                                        </div>
                                      </div>
                                  </form>
                                    <form class="forms-sample" method="POST" action="<?php echo base_url()?>Depenses/printAll">

                                         <div class="col-lg-4">
                                          <label for="exampleInputEmail1 " style="color:black;">Imprimer</label>
                                            <div class="form-group">
                                               <input type="hidden" class="form-control " id="dateprint" name="dateprint">
                                                <button type="submit" class="btn btn-info mr-2"><i class="fas fa-print"></i>Imprimer</button>
                                            </div>
                                        </div>
                                    </form>
                                      <div class="row">
                                       <div class="col-lg-12">
                                       <div id="resultChar"></div>
                                       </div> 
                                     </div>
                                  
                                  </div>
                                </div>
                                
                            </div>

                        </div>
                    <!-- FIN DU MODAL -->

                


                  


           
    </div>
</div>
