<!DOCTYPE html> 
<html> 
<head> 
    <meta charset="utf-8"> 
    <title>IMPRESSION</title>
</head> 
<body>

<h1 class="text-center bg-info">ETS GLORIA</h1>
<h3 class="text-center bg-info">PHARMACIE GLORIA</h3> 
<p>UVIRA-KALIMABENGE</p>
<b>Tél:</b> +243 812125633
+243 994931850
<b>RCCM:</b>CD/UVIRA/RCCM/19-A-577
<b>ID.Nat.</b>441/04/3666
<hr>
    <center><strong><U>DETAILS DU MEDICAMENT</U></strong></center>
<br>
<br>
<table  class="table table-bordered"> 
    <thead> 
        <tr > 
            <th>Produits</th>
            <th>Categories</th>
            <th >Qte stocké</th>
            <th >Date Entr</th>
            <th >Date Exp</th>
            <th >P.U </th> 
            <th>P.T</th>
            <th>P.V</th>
            <th>Fournisseur</th>

        </tr> 
    </thead>
    <tbody>
      <?php foreach($data->result() as $items):
             $dat=$items->s_daten;
             $date=date("d-m-Y", strtotime($dat));
             $Exp=$items->s_datex;
             $EX=date("d-m-y", strtotime($Exp));

            ?>
        <tr>
            <td><?php echo $items->m_name;?></td>
            <td><?php echo $items->m_categorie;?></td> 
            <td><?php echo $items->s_qteE;?></td> 
            <td><?php echo $date;?></td>
            <td><?php echo $EX;?></td>
            <td><?php echo $items->s_prixU;?></td> 
            <td><?php echo $items->s_prixT;?></td>
            <td><?php echo $items->s_vente;?></td> 
            <td><?php echo $items->s_fournisseur;?></td>
            
    </tr>
         <?php endforeach; ?>
    
    </tbody>
</body>
</html>
<STYLE>
* {
    font-style: italic;
    font-family: 'Times New Roman';
    width: 100%;
}

td,
th,
tr,
table {
    border-top: 1px solid black;
    border-collapse: collapse;
    padding:4px;
    text-align: center;
    font-size: 15px;
}
</STYLE>