<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
$y_year = ($this->session->userdata['logged_in']['y_year']);
$y_ID = ($this->session->userdata['logged_in']['y_id']);


} else {
//header("location: logout");
}
?>
     <div class="main-content">
                    <div class="container-fluid">
                         <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                       <i class="ik ik-bar-chart-2 bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Gestion de Stock</h5>
                                            <span>Cette page permet de voir  les effectifs des medicaments dans le stock</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>welcome/DASHBOARD"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Gestion de stock</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                        <?php echo $info; ?>
                            <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>                    
 
                    
                <div class="row clearfix">
                  

                  <!-- MODAL POUR AJOUT PROGRAMME  -->
                    
                <div class="col-md-12">

                    <span>
                     <button type="button" class="btn btn-success"  style="margin-left:0%;"  onclick=" myFunction()"> <i class="fas fa-plus"></i>Ajout des Produits dans le Stock</button>
                    </span>

                   </br>
                    </br>

                         <div id="form" style="display:none;" >
                                <div class="card">
                                    <div class="card-header  bg-dark"><h3 style="color:white;">Ajout des Produits dans le Stock</h3></div>
                                    <div class="card-body">
                                        <form class="forms-sample" action="<?php echo base_url()?>Stock/Add" method="POST">
                                         <div class="row">

                                             <div class="col-lg-4">
                                                <select   id="med" name="med" class="form-control" style="width:300px;">
                                                  <option value='0'>--  Sélectionnez le Produit --</option>
                                               </select>
                                               <span id="name_error" class="text-danger"></span>
                                            </div>
                                        
                                         <div class="col-lg-3">
                                            <div class="form-group">
                                            <input type="text" class="form-control " id="Categorie" name="Categorie" readonly="">
                                            </div>
                                        </div>

                                         <div class="col-lg-2">
                                            <div class="form-group">
                                                <input type="text" class="form-control " id="Entrant" name="Entrant" placeholder="Qte">
                                            </div>
                                         </div>

                                          <div class="col-lg-3">
                                            <div class="form-group">
                                                <input type="text" class="form-control " id="prix" name="prix" placeholder="Prix Unitaire en USD">
                                            </div>
                                         </div>
                                         </div>
                                        <div class="row">

                                          <div class="col-lg-3">
                                            <label for="exampleInputEmail1 " style="color:black;">Date d'entrée</label>
                                            <div class="form-group">
                                            <input type="date" class="form-control " id="dateentré" name="dateentré">
                                           </div>
                                         </div>
                                           
                                          <div class="col-lg-3">
                                                <label for="exampleInputEmail1 " style="color:black;">Date d'expiration</label>
                                                 <div class="form-group">
                                                <input type="date" class="form-control " id="expiration" name="expiration">
                                            </div>
                                         </div>

                                          <div class="col-lg-2">
                                            <label for="exampleInputEmail1 " style="color:black;">Qte d'Alerte</label>
                                            <div class="form-group">
                                            <input type="text" class="form-control " id="Qte" name="Qte" placeholder="Qte d'Alerte">
                                            </div>
                                         </div>

                                          <div class="col-lg-2">
                                            <label for="exampleInputEmail1 " style="color:black;">Prix de Vente</label>
                                            <div class="form-group">
                                            <input type="text" class="form-control " id="vente" name="vente" placeholder="Prix de vente">
                                            </div>
                                         </div>

                                        <div class="col-lg-2">
                                            <label for="exampleInputEmail1 " style="color:black;">Nom du Fournisseur</label>
                                            <div class="form-group">
                                            <input type="text" class="form-control " id="name" name="name" placeholder="Nom du Fournisseur">
                                            </div>
                                         </div>    
                                    </div>
                                            <button type="submit" class="btn btn-primary mr-2">Enregistrer</button>
                                            <button type="reset" class="btn btn-light">Annuler</button>
                                          </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <!-- FIN DU MODAL -->

                       <div class="col-lg-12">
                        <div class="col-lg-4">
                      <a  href="<?php echo base_url()?>Stock/printAll"class="btn btn-primary mr-2"><i class="fas fa-print"></i>Imprimer</a>
                        </div>
                      </br>
                            <div class="form-group">
                               <div class="input-group">
                               <input type="text" name="search_text" id="search_text" placeholder="Recherche des Medicaments " class="form-control"/>
                               </div>
                            </div>


                            <div id="result"></div> 
                        </div>

                      
               
                </div>
                    <!-- FIN DU CARD -->
            </div>
        </div>
         
              
<script type="text/javascript">
function myFunction(){
  var x = document.getElementById("form");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
} 

</script>
         

                                              