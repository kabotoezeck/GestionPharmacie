<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
                           
 <div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-inbox bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Fiche de Modification</h5>
                                            <span>Cette page permet de Modiifer  les informations relatives au Stock des Produits</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>index.php/welcome/DASHBOARD"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">Pharmacie GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Modification du Stock</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                         <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                   <!--   <?php echo $info;?> -->
 
                        <div class="col-lg-12">   
                            <div class="card">
                                <div class="card-header d-block" style="background-color:firebrick; ">
                                  <h3  style="color:white">Page de modification</h3>
                                       
                             </div>

                     <!-- MODAL POUR MODIFIER  -->
                      <?php  foreach($query as  $value) :?>
                            <form class="forms-sample" action="<?php echo base_url();?>Stock/EditStock/<?php echo $value->s_id;?>"  method="POST">
                                     <div class="modal-body">
                                       
                                      <div class="row">

                                         <div class="col-lg-3">
                                          <div class="form-group">
                                            <label for="exampleInputEmail1">Selectionnez Le Produit || Categorie</label>
                                            <select class="form-control" id="m_id"  name="m_id" >
                                               <option value="<?php echo$value->m_id?>"><?php echo $value->m_name?>&nbsp;||&nbsp;<?php echo $value->m_categorie?></option>
                                                  <?php  foreach($med as $row) :?>
                                                  <option value="<?php echo$row->m_id?>"><?php echo$row->m_name?>&nbsp;||&nbsp;<?php echo$row->m_categorie?></option>
                                                  <?php endforeach; ?>
                                                </select>
                                              </div>
                                          </div>

                                          <div class="col-lg-2">
                                            <div class="form-group">
                                            <label for="exampleInputUsername1">Qte Stocké</label>
                                            <input type="text" class="form-control" name="Qte" value="<?php echo $value->s_qteE?>">
                                            </div>
                                             
                                            </div>
                                             <div class="col-lg-2">
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">Prix Unitaire</label>
                                                <input type="text" class="form-control" name="unitaire" value="<?php echo $value->s_prixU?>" >
                                            </div>
                                            </div>

                                       

                                             <div class="col-lg-2">
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">Date d'Entrée</label>
                                                <input type="date" class="form-control" name='Dentrant' value="<?php echo $value->s_daten?>" >
                                            </div>
                                          </div>

                                           <div class="col-lg-2">
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">Date d'Expiration</label>
                                                <input type="date" class="form-control" name='Dexp' value="<?php echo $value->s_datex?>" >
                                            </div>
                                          </div>

                                        </div>

                                         <div class="row">
                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">Qte d'Alerte</label>
                                                <input type="text" class="form-control" name='alerte' value="<?php echo $value->s_alert?>" >
                                             </div>
                                            </div>

                                             <div class="col-lg-2">
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">Prix de Vente</label>
                                                <input type="text" class="form-control" name='vente' value="<?php echo $value->s_vente?>" >
                                             </div>
                                            </div>
                                            <input type="hidden" class="form-control" name="aleatoire"  value="<?php echo $value->s_aleatoire ?>">

                                             <div class="col-lg-3">
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">Nom du Fournisseur</label>
                                                <input type="text" class="form-control" name="Fournisseur"  value="<?php echo $value->s_fournisseur ?>">
                                            </div>
                                            </div>
                                    
                                         <?php endforeach; ?>
                                    </div>
                                    <div class="modal-footer">
                                        <a  href="<?php echo base_url()?>Stock/index" type="button" class="btn btn-secondary" data-dismiss="modal">Retour</a>
                                        <button type="submit" class="btn btn-success"><i class="ik ik-check-circle"></i>Modifier</button>
                                    </div>
                                 </form>
                                </div>
                           </div>
                                </div>
                            </div>
                            <!-- FIN DU MODAL -->
                             </div>