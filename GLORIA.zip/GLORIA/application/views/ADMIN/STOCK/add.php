<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
$y_year = ($this->session->userdata['logged_in']['y_year']);
$y_ID = ($this->session->userdata['logged_in']['y_id']);


} else {
//header("location: logout");
}
?>
     <div class="main-content">
                    <div class="container-fluid">
                         <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                       <i class="ik ik-bar-chart-2 bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Gestion de Stock</h5>
                                            <span>Cette page permet de voir  les effectifs des medicaments dans le stock</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>welcome/DASHBOARD"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Gestion de stock</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                        <?php echo $info; ?>
                            <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>                    
 
                    
                <div class="row clearfix">
                  

                  <!-- MODAL POUR AJOUT PROGRAMME  -->
        <?php  foreach($query as  $value) :?>    
                <div class="col-md-12">
                 <div class="card">
                  <div class="card-header  bg-danger"><h3 style="color:white;">Ajout des Produits dans le Stock</h3></div>
                    <div class="card-body">
                    <form class="forms-sample" action="<?php echo base_url()?>Stock/AddStockM/<?php echo $value->s_id;?>" method="POST">
                        <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <select class="form-control" id="m_id"  name="m_id" readonly="">
                                        <option value="<?php echo$value->m_id?>"><?php echo $value->m_name?></option>
                                        </select>
                                    </div>
                                </div>
                                        
                                         <div class="col-lg-3">
                                            <div class="form-group">
                                            <input type="text" class="form-control " id="Categorie" name="Categorie" readonly="" value="<?php echo $value->m_categorie?>">
                                            </div>
                                        </div>
                                        

                                         <div class="col-lg-2">
                                            <div class="form-group">
                                                <input type="text" class="form-control " id="Entrant" name="Entrant" placeholder="Qte">
                                            </div>
                                         </div>

                                          <div class="col-lg-3">
                                            <div class="form-group">
                                                <input type="text" class="form-control " id="prix" name="prix" placeholder="Prix Unitaire">
                                            </div>
                                         </div>
                                         </div>
                                        <div class="row">

                                          <div class="col-lg-3">
                                            <label for="exampleInputEmail1 " style="color:black;">Date d'entrée</label>
                                            <div class="form-group">
                                            <input type="date" class="form-control " id="dateentré" name="dateentré">
                                           </div>
                                         </div>
                                           
                                          <div class="col-lg-3">
                                                <label for="exampleInputEmail1 " style="color:black;">Date d'expiration</label>
                                                 <div class="form-group">
                                                <input type="date" class="form-control " id="expiration" name="expiration">
                                            </div>
                                         </div>

                                          <div class="col-lg-2">
                                            <label for="exampleInputEmail1 " style="color:black;">Qte d'Alerte</label>
                                            <div class="form-group">
                                            <input type="text" class="form-control " id="Qte" name="Qte" value="<?php echo $value->s_alert?>" placeholder="Qte d'Alerte">
                                            </div>
                                         </div>

                                          <div class="col-lg-2">
                                            <label for="exampleInputEmail1 " style="color:black;">Prix de Vente</label>
                                            <div class="form-group">
                                            <input type="text" class="form-control " id="vente" name="vente" placeholder="Prix de vente">
                                            </div>
                                         </div>

                                        <div class="col-lg-2">
                                            <label for="exampleInputEmail1 " style="color:black;">Nom du Fournisseur</label>
                                            <div class="form-group">
                                            <input type="text" class="form-control " id="name" name="name" placeholder="Nom du Fournisseur">
                                            </div>
                                         </div>    
                                    </div>
                                            <button type="submit" class="btn btn-primary mr-2">Enregistrer</button>
                                             <a  href="<?php echo base_url()?>Stock/index" type="button" class="btn btn-light" data-dismiss="modal">Retour</a>
                                          </form>
                                    </div>
                                </div>
                           
                        </div>
                     <?php endforeach; ?>
                    <!-- FIN DU MODAL --> 
                </div>
                    <!-- FIN DU CARD -->
            </div>
        </div>
         
