<?php
if (isset($this->session->userdata['logged_in'])) {
$u_nom = ($this->session->userdata['logged_in']['u_nom']);
$u_username = ($this->session->userdata['logged_in']['u_username']);
$u_avatar = ($this->session->userdata['logged_in']['u_avatar']);
} else {
//header("location: logout");
}
?>
<div class="main-content">
    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="ik ik-settings bg-blue"></i>
                                        <div class="d-inline">
                                            <h5>Parametrage</h5>
                                            <span>Page d'Authentification</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo base_url()?>DashboardAdmin/index"><i class="ik ik-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="#">GLORIA</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Authentification</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                         <h5><center><strong><?php  echo 'GESTION DE COMPTE ' .$y_year ;?></strong></center></h5>
                        <?php echo $info; ?>
                    <?php  foreach($query as  $value) :?>
                      <form  method="POST" action="<?php echo base_url();?>Stock/modify/<?php echo $value->s_id;?>">
                         <div class="card col-lg-6" style="margin-left: 20%">
                          <div class="card  bg-dark">
                            <div class="card-header "><h3 style="color:white;"> VEUILLEZ S'AUTHENTIFIER</h3></div>
                                <div class="card-body">
                                   <div class="modal-content">
                                   <div class="modal-header">
                                    <center>AUTHENTIFICATION</center>
                                   
                                 </div>
                             <div class="modal-body">
                            <center> <img style="width:100px; height: 100px;" src="<?php echo base_url('assets/p2.png')?>" class="rounded-circle"></center>
                              <div class="form-group">
                               <input type="text" class="form-control" placeholder="Nom d'Utilisateur" name='username' id='username'>
                             </div>
                            <div class="form-group">
                                <input type="password" class="form-control" placeholder="Mot de passe" name="password" id='password'>
                             </div>
                          <?php endforeach; ?> 

                       <div class="sign-btn text-center">
                      <button class="btn btn-theme">Connexion</button>
                        <a   href="<?php echo base_url()?>Stock/index" type="button" class="btn btn-secondary" data-dismiss="modal">Retour</a>
                    </div>     
                   </div>
                  </div>            
                    </div>
                </div>
                </div>
              </form>
                 
    </div>
</div>
